# Release history

What changed in each version, newest first. This page is generated from the project's commit history when a release is built — it is never edited by hand.

## 0.21.0 — 2026-11-12

- Hero video: the WebM / MP4 windows list every video (a file filed under another type no longer vanishes after upload); a wrong type is refused with a message that names it and how to convert a .mov
- Body editor: Quote button and a Cite button for the author or source under it (also in the HTML tab)
- TL;DR box: square corners by default (no border radius)

## 0.20.0 — 2026-11-12

- Quotes in the article text: italic text font, set in from a side line in the primary colour (Styles: Quote side line colour and width); FAQ answer quotes use the same line
- Release 0.20.0
- Article list: 'Hide from the blog list' switch per article (also skipped by automatic Keep reading); cards show the hero video poster or social image when there is no featured image; list pages 2+ get their own descri…
- Pagination: the current page uses the primary button colours and the site's box corners (square when Box corners = 0); text that is the same colour as its background is shown in white/black by the build, and the Style…
- FAQ answers are tidied into semantic HTML (loose text gets a paragraph, loose list items a list, tables scroll sideways on phones) and styled like the article text: lists, bold, links, quotes, code, tables

## 0.19.0 — 2026-11-08

- Header strip shows a hand-written right-side label without a phone number; hero video gets an optional pause button (off by default) and a shape note; social share image tucked under an optional toggle
- Buttons in article text keep their own label colour (the text-link rule no longer paints them); widev gets square buttons and a white primary label by default

## 0.18.2 — 2026-11-05

- Astro pages tell WordPress page-cache plugins not to keep a copy (DONOTCACHEPAGE), so WP Super Cache / W3TC / WP Rocket can run beside W-Blog without ever showing a stale article after a rebuild

## 0.18.1 — 2026-11-05

- Deploy tab: 'Cloudflare keeps pages for' - Astro pages tell Cloudflare how long it may keep them (Cloudflare-CDN-Cache-Control), so one Cache Rule covers every article and WordPress pages are never cached
- CI: the Cloudflare purge step belongs to the rsync job (it had landed in the Netlify job, so it never ran for rsync sites)

## 0.18.0 — 2026-11-05

- Release 0.18.0: Skin variables per component, Health check and terminal commands on the Deploy tab, smaller hero title, whole company logo, Business/Services wording, clean heading outline, Cloudflare purge after a build
- Deploy tab: fix the health-check address, wrap long commands
- Deploy tab: Health check (GitHub access, last request, build folder, flagged pages, live page) and Check it yourself (copy-ready terminal commands for this site)
- CI: the rsync build clears the Cloudflare cache after the files are in place (optional: needs CLOUDFLARE_API_TOKEN and CLOUDFLARE_ZONE_ID in the Environment)
- Skin variables grouped per component (buttons, chips, callouts, tables, header/footer, hero); smaller default hero title; whole logo in the company card; Business/Services wording; clean heading outline
- CI: deploy.yml deploys only widev.pro (rsync-only key); drop the dayo-staging and Blyss jobs of other projects. Docs: the GitHub token needs Contents: Read and write
- CI: rsync to the widev.pro server now sets group-writable permissions (-p with --chmod), so WordPress's own updater can replace the plugin folder without leaving it half-removed

## 0.17.0 — 2026-11-04

- Content rhythm and cleaning, table scroll cue, logo width and hero button variables
- Hero video: per-article looping video in the hero (WebM + MP4, poster, autoplay/loop/muted/preload), poster-first and phones keep the poster; uploaded videos in the text load lazily

## 0.16.10 — 2026-11-04

- TL;DR summary: bold and bulleted lists, Enter makes a new paragraph or bullet
- CI: publish a site's build by rsync when no Netlify site is set, and add an rsync-only plugin deploy for widev.pro
- New site folder frontend/src/sites/widev (Widev Remote Team: logo, Inter, near-black buttons, light hero); the hero's category chip and meta follow the hero text colour so light and dark heroes both work
- Deploy workflow runs in widevpro/wp-astro (the working repository); docs no longer list the old webimdeveloper copy

## 0.16.9 — 2026-10-26

- more air in the article header (smaller h1 with a looser line, bigger gaps and padding), taller tap area for the top menu, roomier sidebar CTA

## 0.16.8 — 2026-10-26

- hosted images, CSS and fonts are copied into uploads/wp-astro-assets (plain static files on every host) right after a page is printed, and the page links to them there

## 0.16.7 — 2026-10-26

- hosted images, CSS and fonts are saved into the site's /_astro/ folder (works with hosts that redirect missing files to index.php); Netlify's helper script is also removed from pages cached by an older version

## 0.16.6 — 2026-10-26

- images, CSS and fonts load from the WordPress address (one connection, faster first paint); hero image decodes normally; the headings font is preloaded; sidebar CTA title centred; phone aligned left on phones; more sp…

## 0.16.5 — 2026-10-26

- social profile links in the footer on their own left-aligned row
- Footer: the social links get their own left-aligned row under the copyright and legal links (a wrapping row on phones)
- Social profile links are shown in the footer as plain text links (Facebook, X, LinkedIn …), with a switch under Content → Footer; they are always sent to Google as structured data

## 0.16.4 — 2026-10-26

- Netlify's helper script is removed from printed pages; card images lighter
- Pages printed from Netlify no longer carry Netlify's helper script (a 404 request and a console error on the WordPress address); card images use quality 60

## 0.16.3 — 2026-10-26

- hero picture never cropped; header without a picture centred
- Header without a featured image is centred again (as before); only the two byline lines stay left-aligned to each other
- Hero picture is never cropped: the box follows the picture's own shape (height capped at --hero-media-max, shown whole inside the cap); featured-image hint and guide updated

## 0.16.2 — 2026-10-26

- Guide pages: padding around the card, a gap under the version line and between the title and text
- Guide: five new pages (development flow, Netlify, how deploy works, how the plugin works, basic functions) built from the README, DEVELOPER.md and CLAUDE.md; the running plugin version is shown on every page ({{versio…
- Layout: sidebar and text columns sit on the page edges (space-between); plain header text starts on the sidebar edge (sidebar pages) or the centred text column (full width), whatever the title length; dead name separa…
- Services / products / treatments block: generic name in the admin, up to three cards in a count-aware grid (picture + title only, no heading unless typed); guide and a11y fixes (labelled inputs, no 'Reviewed by' in th…
- Share bar under the text: no extra top margin (the section child-spacing rule no longer reaches widgets)
- Full width layout: one table-of-contents block (can be switched off, full width only), no CTA box, share under the text, header aligned left with the text column
- Edit article → Company card: restyled with the admin kit (bordered list, status tags, one button per row, soft panel); panels stay closed unless a value is needed; shows what the site uses
- Company card per article: one on/off switch per part starting at the site's setting, and every part can get its own value for this page (same fields and validation as the Content tab); the card lays the page's values…
- Company card switches: quick clicks no longer overwrite each other; help text explains that a switch only hides or shows what is filled in
- Company card: the description is its own full-width row under the picture/name row
- Company card address: one block line per part instead of <br>
- Article text headings only (not block titles) use the text font; company card: address uses the full width when there are no hours; Dayo placeholder hours removed
- Company card: title can be set per article (Edit article → Company card → Title on this page); empty = the site title, then no heading
- empty values are never printed (header strip, phone, CTA, sidebar box, author, footer, company card, structured data); company title has no built-in text; Articles list: Tags hidden, fixed Category width, one-line tit…

## 0.16.1 — 2026-10-26

- Dayo link/outline colour #FF8433, white button text, pill buttons weight 500; one page width for header, hero and content (82rem); block-editor lists keep their marks; box padding gap-lg/gap-md

## 0.16.0 — 2026-10-26

- phone numbers use non-breaking hyphens, docs for buttons and article headings, version bump
- Frontend cleanup: two-button CTA (primary/secondary, equal padding, black/white default, smooth hover), headings inside the article use the text font and a smaller aligned scale, dead services/nav config, unused CSS a…
- Remove 'Reviewed by' / 'Last reviewed' from the edit screen, the REST API, the byline and the structured data

## 0.15.4 — 2026-10-26

- Styles field shows the client's own skin values as defaults (build publishes /wa-skin.json); byline without a cropped logo
- Byline: no cropped logo avatar for an organisation author

## 0.15.3 — 2026-10-26

- Dayo skin matches the main site (font weights, letter spacing, line heights, text colour, buttons, card boxes); body text colour variable; unused variables removed

## 0.15.2 — 2026-10-26

- SEO import reports articles that already had values and lists only published articles as missing; fonts from WordPress
- Styles: Google font name and weights for headings and text set from WordPress (build reads them); validated server-side

## 0.15.1 — 2026-10-26

- import SEO titles and descriptions from the old site
- Import SEO titles and descriptions from the old site (Yoast data) into the SEO card; only empty fields are filled

## 0.15.0 — 2026-10-25

- company card, skins and the Styles variables field, image hints, audit fixes
- Docs: skins and the Styles tab (DEVELOPER.md); CI checks the generated variable list is up to date
- Audit fixes: titles from WordPress printed as safe text (a stray tag could swallow the page); admin fields linked to their labels (a11y)
- Admin: image requirement hints (featured image with live width warning, company picture, author photo)
- Frontend: header logo served at displayed size (260/400 w srcset); author Gravatar photo downloaded and resized at build
- Styles tab: one pre-filled CSS field with every variable and its default (brand colours included), only changed lines are stored; brand colours follow into the lighter shades
- Styles tab: skin variables as one highlighted CSS field (WordPress CodeMirror) instead of a field per variable; custom CSS uses the same editor
- Styles tab: generated Design variables list (search, groups, reset, paste CSS, copy as CSS/JSON); server-side per-type validation; token registry generated from tokens.css + tokens.meta.json
- Skins: neutral defaults in the lowest CSS layer, skin tokens (theme.json + WordPress), skin variables for headings, links, buttons, boxes and hero; Blyss keeps today's look, Dayo gets its own skin
- Company card: standalone block with per-part switches (site-wide in Content, per article in the edit screen), editable title, picture and description; reviews fields no longer hidden

## 0.14.0 — 2026-10-24

- Import missing images; developer guide
- Import missing images: copy the pictures articles use from the old site, fix links and featured images (General tab)
- Developer guide [skip netlify]

## 0.13.0 — 2026-10-24

- guide for the Body editor, summary vs meta description, templates and menu [skip netlify]
- Body editor: headings H2-H6, B/I/U, lists, links and an insert-table button (no alignment, quote or line); tables scroll sideways on phones; H6 style
- Meta description and TL;DR are separate: description = own text, else the Content mask with variables, else nothing; score and admin preview no longer use the summary
- No page description at all when nothing is written and WordPress has no text to give
- TL;DR block only shows a written summary; WordPress's automatic excerpt is no longer used
- Byline text always left-aligned, also inside the centred header
- Fix FAQ and other meta values being saved empty when they contain quotes; Full width template; build assets served locally; dev server notices new articles
- Fix image picker: 'close' fires before 'select', so every picked image was discarded
- Header menu only from the Content tab; no menu and no empty container when empty
- Top bar: HTML on the right, spaces kept while typing, shorter copy with a Content tab link; fix meta values with quotes being saved empty
- Dev server re-reads WordPress Content/Styles on change (dev only)

## 0.12.0 — 2026-10-24

- top bar per page, draggable categories, no-hero header, idle publishing from admin screens
- Categories as draggable chips; the first one is shown above the title
- Top bar editable per page: text and phone, defaults from Content
- Idle publishing starts from open admin screens; no-hero header layout

## 0.11.0 — 2026-10-24

- batched publishing (Publish now, pending bar, publish modes); show last built copy from the old address after a rename

## 0.10.0 — 2026-10-23

- one admin kit — tokens and shared styles, General and Styles screens, Guide and navigation in the same look

## 0.9.0 — 2026-10-23

- Content tab as a grouped Vue screen, pill tabs, phone derived from display

## 0.8.0 — 2026-10-23

- Live page status shows whether the last save is on the public page

## 0.7.2 — 2026-10-23

- Purge page cache and Rebuild buttons sent GET to POST-only routes

## 0.7.1 — 2026-10-23

- clear cached pages when a build succeeds; shorter edge-cache lifetime

## 0.7.0 — 2026-10-23

- Treatments mentioned as article cards; header top bar text
- Header top bar: free left text (site-wide + per article) and phone on the right

## 0.6.0 — 2026-10-23

- live page panel, structured-data viewer, Not-updated-in-12-months filter

## 0.5.1 — 2026-10-23

- empty FAQ / Sources / TL;DR show as off and switch on with the first content

## 0.5.0 — 2026-10-23

- Fix ServicesMentioned image typing
- Edit article phase 2 — author, review, treatments, page elements, schema type
- CI: the plugin rsync deploy only runs in the original repository

## 0.4.0 — 2026-10-23

- Edit article screen (phase 1)

## 0.3.6 — 2026-10-23

- search block with popular searches (no FAQ, content score below 90)

## 0.3.5 — 2026-10-23

- table fits the screen (eye column was cut off), search box focus, W-Blog naming

## 0.3.4 — 2026-10-23

- FAQ is its own list with an on/off switch

## 0.3.3 — 2026-10-23

- compact Articles table, FAQ editor, short dates

## 0.3.2 — 2026-10-23

- W-Blog menu title and logo icon in the admin sidebar
- Docs: full README (setup, Netlify modes, workflows, releases, troubleshooting)

## 0.3.1 — 2026-10-23

- call the static pages "HTML" in the admin (menu, boxes, notices, guide)
- updates from GitHub releases (Update now), release workflow
- CI: build-blog workflow (WordPress content -> Astro -> Netlify) and docs
- Plugin: Astro menu, Content/Styles/Google/Guide tabs, Articles API, PageSpeed, Netlify connect
- Admin UI: Vue 3 + Naive UI app for the Astro screens
- Frontend: WordPress-editable site content, styles and {variable} descriptions
- Plugin: record and show build status (building/success/failed) via /build-status callback
- Frontend: skip WP data memoisation in astro dev so edits show on refresh
- Plugin: full-width article role, Astro template picker, settings link and copy tweaks
- Add repo CLAUDE.md; refresh README for the multi-site setup
- wp-astro v0.2.0: Blog front role, remote serve mode, multi-site frontend
- Header: Our Services → /service-page-overview/; report: staging Lighthouse 100/100 results
- Perf: hero AVIF preload, quality 60, upright-only fonts, self-hosted YouTube thumb
- Perf/a11y: text-only CTA token (4.5:1), YouTube facade, body images via astro:assets, asset cache headers
- CTA colour token: #40ae96 -> #0ba282
- Article template redesign + staging deploy workflow
- Article page: layout rhythm, byline, header, FAQ, references, related
- Fix body text colour: --font-color-base-100 typo -> --color-base-100
- Article body: reading-width column, carded TL;DR, tighter heading scale
- Phase 2: TOC number inherits link colour (matches label, transitions on hover)
- Phase 2: TOC numbered via CSS counter (works with grid; number in --color-base-100, label muted); 1.5em number column
- Phase 2: TOC styles scoped to .wa-widget ol / .wa-widget ol a (no .wa-toc class)
- Phase 2: TOC list styles (.wa-toc ol grid gap, .wa-toc a small muted + colour hover); disable stylelint no-descending-specificity (false positives with layered component CSS)
- Phase 2: CTA arrow — static vertical nudge via margin-block-start (translate stays hover-only, no jump)
- Phase 2: fix CTA arrow — recreate public/icons/arrow-icon-cta-button-hover.svg, absolute mask URL, add -webkit-mask
- Phase 2: CTA buttons — .wa-btn shell + --primary/--secondary variants (colours only differ); sliding hover fill via ::before, arrow via ::after mask(/icons/arrow.svg), reduced-motion; CTA + --ease-out tokens
- Phase 2: swap in real Stars + GoogleG SVGs; aligned component structure (both: {...Astro.props}, viewBox, aria-hidden, no fixed size); stars DRY via translated map
- Phase 2: add public/icons/arrow.svg (placeholder) for CSS mask use on CTA hover
- Phase 2: inline icon components (Stars, GoogleG) in src/components/icons/; add Google-reviews link above the sidebar CTA h3 (one flex line, SVGs inlined in HTML)
- Phase 2: cap running text at --measure (68ch) on .wa-tldr/.wa-prose; drop dead justify-content:space-between (no-op with 1fr main track)
- Phase 2: category + tags back to plain MOCK_ consts in article.ts (markup-only mode — no WP term logic); drop _embed=wp:term + Term type
- Phase 2: real category + tags from WP (_embed=wp:term) — replaces mock; term.name + /resources/{category,tag}/{slug}/ hrefs
- Phase 2: taxonomy — category + tags render as identical pills (inline-flex), single --space-2 gap between category, taglist, and each tag; tidy longhands to shorthand
- Phase 2: align hero sizes breakpoint to 54rem (matches the layout switch)
- Phase 2: header image sizing — flex longhands instead of shorthand (nested clamp(var,%,var) is rejected in the flex: basis slot)
- CI: workflow_dispatch only — stop auto-running (and failing) the build on every push until Phase 4 deploy is wired
- Phase 2: header row — raise 2-col breakpoint 46rem->54rem (avoid cramped column), image ideal 34%->40%
- Phase 2: header row — flex-direction column↔row via container query (no flex:999 trick); text flex:1 min-width:0, image flex:0 0 clamp(--media-col-min,34%,--media-col-max), full-width when stacked for free
- Phase 2: real hero image via <Picture> (astro:assets) — AVIF/WebP/JPEG, srcset 360-770w, sizes, eager+fetchpriority; remotePatterns for WP origins; fallbackFormat jpg
- Phase 2: header image full-width when stacked — main flex-grow 999 (text hogs free space beside image), image flex 1 1 --media-col-max fills its line when wrapped, max-width:100% guard
- Phase 2: header row back to flex — text flex:1 1 26rem; image bounded via min-width min(--media-col-min,100%) + max-width --media-col-max
- Phase 2: header row — container query + asymmetric grid (minmax(0,1fr) \| minmax(--media-col-min,--media-col-max)); one breakpoint, bounds tokenised, no flex magic numbers
- Phase 2: header row — real minimums via min-width: min(X,100%); image bounded 18-28rem (never tiny, never dominant); smaller gap (--gap-2xl)
- Phase 2: article header row — fluid column-gap (--gap-6xl) + smaller row-gap; flex 3:2 grow (text dominant side-by-side, each full-width when wrapped); media img width 100%
- Phase 2: taxonomy as its own full-bleed band (grey) under the navy header — __taxonomy (bg) + __taxonomy-inner.wa-wrapper (content)
- Phase 2: full-bleed article header — .wa-article-head (bg edge-to-edge) + .__inner.wa-wrapper (constrained content); placeholder navy bg + light heading colour override
- Phase 2: fix sidebar — wrap .wa-article-layout in .wa-wrapper-content so @container wrapper2 has a container ancestor; inlineStylesheets: always (keep CSS out of render-blocking link)
- Phase 2: html-validate — disable require-sri (self-hosted assets don't need integrity hashes; font preloads carry crossorigin)
- Phase 2: move Breadcrumbs outside <article> (nav chrome, not article content); .wa-wrapper now wraps breadcrumbs + article as siblings
- Phase 2: wire Header/Footer placeholders into ArticleLayout (banner + contentinfo landmarks); add the missing imports
- Phase 2: Breadcrumbs — fix import path after move, back to <ol> (ordered path, matches BreadcrumbList schema), __list/__item classes, CSS '/' separator
- Phase 2: move Breadcrumbs to src/components/ (shared — used by article + list/category pages)
- Phase 2: drop Google Fonts preconnect from SeoHead — fonts are self-hosted now
- Phase 2: self-hosted fonts via Astro Fonts API (Playfair Display 600/700, Roboto 400/500/700) — subset, metric-adjusted fallbacks for zero CLS; preload body font only; tokens alias --font-headings/--font-content
- Phase 2: typography — drop .h1-.h5 classes; per-level line-height (1.05->1.4, inverse to size), negative letter-spacing on display sizes, font-weight 700, text-wrap: balance
- Phase 2: reset — drop -webkit-font-smoothing (macOS-only, thins text, a11y), 100vh -> 100dvh
- Phase 2: CSS cascade layers — app.css entry (reset/base/components/prose/utilities), base.css + typography.css (h1..h5 element+class from tokens), color-scheme:light; stylelint stops fighting prettier on whitespace
- Phase 2: keep font-family name casing (stylelint), restore Georgia/Helvetica/Arial
- Phase 2: tokens.css — font families, sizes, text colors (primitives, not yet wired)
- Phase 2: SEO head boilerplate (SeoHead.astro + site.ts), <main> landmark, hero fetchpriority=high, speakable-summary class + JSON-LD selector
- Phase 2: dev QA toolchain — prettier, eslint (astro+ts), stylelint, astro check, html-validate, lighthouse CI, linkinator; simple-git-hooks pre-commit
- Phase 2: name the layout query container (wrapper / inline-size)
- Phase 2: article layout — modern reset.css, container query (not media), DOM ordered for zero-CSS mobile
- Phase 2: single-article template — semantic markup, named CSS grid (aside/tldr/main), wrapper vars, all sections (breadcrumbs, header, sidebar, TL;DR, prose, services, author, sources, related)
- Phase 3: rebuild trigger — debounced dispatch (github repository_dispatch / webhook), Rebuild-now button, admin notice
- Phase 3: serve static Astro file for flagged posts (template_redirect), graceful WP fallback
- Phase 2: Astro frontend core — REST client, minimal layout, placeholder chrome, article + list (bare)
- Phase 1: REST endpoints — manifest, config, menus + render_engine field
- Phase 1: settings page + get() accessor (constant overrides, post-types filter)
- Phase 1: per-post Render Engine toggle (meta + REST + editor meta box)
- Phase 0: CI skeleton — build frontend on Node 22, upload artifact (no deploy yet)
- Phase 0: scaffold Astro frontend (v7, TS strict, flat trailing-slash static build)
- Tighten plugin description wording
- Phase 0: plugin skeleton — bootstrap + 5 stub classes, loads and activates clean
