<?php
/**
 * Articles — data layer for the Astro → Articles screen: list the posts that are
 * rendered by Astro, and edit them in place (tags, categories, status, engine).
 * Every write goes through core functions, so the usual hooks fire (and the rebuild
 * trigger queues a build when a published Astro post changes).
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Articles {

	/** @param array{page?:int,per_page?:int,search?:string,status?:string,category?:int} $a */
	public static function query( array $a ): array {
		$per    = min( 100, max( 5, (int) ( $a['per_page'] ?? 20 ) ) );
		$page   = max( 1, (int) ( $a['page'] ?? 1 ) );
		$status = (string) ( $a['status'] ?? 'all' );

		$base = [
			'post_type'     => Meta::post_types(),
			'meta_key'      => Meta::KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'    => Meta::ASTRO, // phpcs:ignore WordPress.DB.SlowDBQuery
			'fields'        => 'ids',
			'no_found_rows' => false,
		];

		$q = new \WP_Query(
			array_merge(
				$base,
				[
					'post_status'    => in_array( $status, [ 'publish', 'draft', 'pending', 'private', 'future' ], true ) ? $status : 'any',
					'posts_per_page' => $per,
					'paged'          => $page,
					'orderby'        => in_array( $a['orderby'] ?? '', [ 'title', 'date', 'modified' ], true ) ? $a['orderby'] : 'modified',
					'order'          => 'asc' === strtolower( (string) ( $a['order'] ?? '' ) ) ? 'ASC' : 'DESC',
					's'              => (string) ( $a['search'] ?? '' ),
					'post__in'       => ! empty( $a['include'] ) ? [ (int) $a['include'] ] : [],
					'cat'            => (int) ( $a['category'] ?? 0 ),
				]
			)
		);

		$counts = [ 'all' => 0 ];
		foreach ( [ 'publish', 'draft' ] as $s ) {
			$c            = new \WP_Query( array_merge( $base, [ 'post_status' => $s, 'posts_per_page' => 1 ] ) );
			$counts[ $s ] = (int) $c->found_posts;
		}
		$all           = new \WP_Query( array_merge( $base, [ 'post_status' => 'any', 'posts_per_page' => 1 ] ) );
		$counts['all'] = (int) $all->found_posts;

		return [
			'items'      => array_map( [ __CLASS__, 'item' ], array_map( 'get_post', $q->posts ) ),
			'total'      => (int) $q->found_posts,
			'page'       => $page,
			'per_page'   => $per,
			'counts'     => $counts,
			'tags'       => array_map(
				static fn( $t ) => $t->name,
				get_tags(
					[
						'hide_empty' => false,
						'number'     => 500,
					]
				) ?: []
			),
			'categories' => array_map(
				static fn( $t ) => [
					'id'   => (int) $t->term_id,
					'name' => $t->name,
				],
				get_categories( [ 'hide_empty' => false ] )
			),
		];
	}

	/** @return array{count:int,source:string,enabled:bool} */
	public static function faq_summary( \WP_Post $p ): array {
		$f = Faq::effective( $p );
		return [
			'count'   => count( $f['items'] ),
			'source'  => $f['source'],
			'enabled' => $f['enabled'],
		];
	}

	public static function item( \WP_Post $p ): array {
		$has_cat = is_object_in_taxonomy( $p->post_type, 'category' );
		$has_tag = is_object_in_taxonomy( $p->post_type, 'post_tag' );

		return [
			'id'           => $p->ID,
			'title'        => html_entity_decode( get_the_title( $p ), ENT_QUOTES ),
			'slug'         => $p->post_name,
			'type'         => $p->post_type,
			'status'       => $p->post_status,
			'role'         => Meta::get_role( $p->ID ),
			'edit_url'     => (string) get_edit_post_link( $p->ID, 'raw' ),
			'view_url'     => 'publish' === $p->post_status ? (string) get_permalink( $p ) : (string) get_preview_post_link( $p ),
			'has_category' => $has_cat,
			'has_tags'     => $has_tag,
			'categories'   => $has_cat ? array_map( 'intval', wp_get_post_categories( $p->ID ) ) : [],
			'tags'         => $has_tag ? array_values( (array) wp_get_post_tags( $p->ID, [ 'fields' => 'names' ] ) ) : [],
			'faq'          => self::faq_summary( $p ),
			'psi'          => Psi::get( $p->ID ),
			'quality'      => Quality::score( $p ),
			'modified'     => get_post_modified_time( 'c', true, $p ),
			'ago'          => human_time_diff( (int) get_post_modified_time( 'U', true, $p ) ),
		];
	}

	/**
	 * Apply any of: tags (string[]), categories (int[]), status (publish|draft), engine (wordpress).
	 *
	 * @return array|\WP_Error the fresh item, or [ 'removed' => true, 'id' => … ] when it left Astro.
	 */
	public static function update( int $id, array $d ) {
		$p = get_post( $id );
		if ( ! $p instanceof \WP_Post || ! in_array( $p->post_type, Meta::post_types(), true ) ) {
			return new \WP_Error( 'wp_astro_not_found', __( 'Article not found.', 'wp-astro' ), [ 'status' => 404 ] );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new \WP_Error( 'wp_astro_forbidden', __( 'You cannot edit this article.', 'wp-astro' ), [ 'status' => 403 ] );
		}

		if ( isset( $d['tags'] ) && is_array( $d['tags'] ) && is_object_in_taxonomy( $p->post_type, 'post_tag' ) ) {
			$names = array_values( array_filter( array_map( 'sanitize_text_field', $d['tags'] ) ) );
			wp_set_post_tags( $id, $names, false );
		}
		if ( isset( $d['categories'] ) && is_array( $d['categories'] ) && is_object_in_taxonomy( $p->post_type, 'category' ) ) {
			wp_set_post_categories( $id, array_map( 'absint', $d['categories'] ) ); // empty → the default category
		}
		if ( isset( $d['status'] ) && in_array( $d['status'], [ 'publish', 'draft' ], true ) && $d['status'] !== $p->post_status ) {
			if ( 'publish' === $d['status'] && ! current_user_can( 'publish_post', $id ) ) {
				return new \WP_Error( 'wp_astro_forbidden', __( 'You cannot publish this article.', 'wp-astro' ), [ 'status' => 403 ] );
			}
			wp_update_post(
				[
					'ID'          => $id,
					'post_status' => $d['status'],
				]
			);
		}
		// Template: with sidebar / full width. The article list is chosen in Settings, not here.
		if ( isset( $d['role'] ) && in_array( $d['role'], [ Meta::ROLE_ARTICLE, Meta::ROLE_FULL_WIDTH ], true ) && Meta::ROLE_FRONT !== Meta::get_role( $id ) ) {
			Meta::set( $id, Meta::get( $id ), $d['role'] );
		}
		if ( isset( $d['engine'] ) && Meta::WORDPRESS === $d['engine'] ) {
			Meta::set( $id, Meta::WORDPRESS, null );
			return [
				'removed' => true,
				'id'      => $id,
			];
		}

		return self::item( get_post( $id ) );
	}

	/** Move an article to the trash (recoverable from Posts → Trash). */
	public static function trash( int $id ) {
		$p = get_post( $id );
		if ( ! $p instanceof \WP_Post || ! in_array( $p->post_type, Meta::post_types(), true ) ) {
			return new \WP_Error( 'wp_astro_not_found', __( 'Article not found.', 'wp-astro' ), [ 'status' => 404 ] );
		}
		if ( ! current_user_can( 'delete_post', $id ) ) {
			return new \WP_Error( 'wp_astro_forbidden', __( 'You cannot delete this article.', 'wp-astro' ), [ 'status' => 403 ] );
		}
		return wp_trash_post( $id ) ? true : new \WP_Error( 'wp_astro_trash_failed', __( 'Could not move it to the trash.', 'wp-astro' ), [ 'status' => 500 ] );
	}

	/**
	 * @param int[] $ids
	 * @return array{done:int[],failed:array<int,string>}
	 */
	public static function bulk( array $ids, string $action, string $value = '' ): array {
		$done   = [];
		$failed = [];
		foreach ( array_unique( array_map( 'absint', $ids ) ) as $id ) {
			$data = [];
			switch ( $action ) {
				case 'draft':
					$data = [ 'status' => 'draft' ];
					break;
				case 'publish':
					$data = [ 'status' => 'publish' ];
					break;
				case 'wordpress':
					$data = [ 'engine' => Meta::WORDPRESS ];
					break;
				case 'template_article':
					$data = [ 'role' => Meta::ROLE_ARTICLE ];
					break;
				case 'template_full_width':
					$data = [ 'role' => Meta::ROLE_FULL_WIDTH ];
					break;
				case 'trash':
					$res = self::trash( $id );
					if ( is_wp_error( $res ) ) {
						$failed[ $id ] = $res->get_error_message();
					} else {
						$done[] = $id;
					}
					continue 2;
				case 'add_category':
					$cat  = absint( $value );
					$data = $cat ? [ 'categories' => array_unique( array_merge( wp_get_post_categories( $id ), [ $cat ] ) ) ] : [];
					break;
			}
			$res = self::update( $id, $data );
			if ( is_wp_error( $res ) ) {
				$failed[ $id ] = $res->get_error_message();
			} else {
				$done[] = $id;
			}
		}
		return [
			'done'   => $done,
			'failed' => $failed,
		];
	}
}
