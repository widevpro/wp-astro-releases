<?php
/**
 * Docs — the "Guide" settings tab. Renders the Markdown files in plugin/docs/ (so the
 * documentation lives in the repo, reviewable like code) above a live "Current setup"
 * box that shows server-level values the other tabs hide. Add more .md files to
 * plugin/docs/ and they appear as sub-pages, ordered by file name.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Docs {

	/** slug => [ 'title' => …, 'file' => … ] for every plugin/docs/*.md */
	private static function pages(): array {
		$pages = [];
		foreach ( glob( WP_ASTRO_DIR . 'docs/*.md' ) ?: [] as $file ) {
			$slug = sanitize_key( basename( $file, '.md' ) );
			$md   = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			preg_match( '/^#\s+(.+)$/m', $md, $m );
			$pages[ $slug ] = [
				'title' => $m[1] ?? ucfirst( $slug ),
				'file'  => $file,
			];
		}
		ksort( $pages );
		return $pages;
	}

	public static function render(): void {
		$pages = self::pages();
		$slug  = isset( $_GET['doc'] ) ? sanitize_key( wp_unslash( $_GET['doc'] ) ) : (string) array_key_first( $pages ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $pages[ $slug ] ) ) {
			$slug = (string) array_key_first( $pages );
		}
		?>
		<style>
			.wpa-doc{max-width:60em;background:#fff;border:1px solid #dcdcde;padding:1px 24px 16px;margin-top:16px}
			.wpa-doc h1,.wpa-doc h2,.wpa-doc h3{margin-top:1.4em}
			.wpa-doc pre{background:#f6f7f7;padding:12px;overflow:auto}
			.wpa-doc code{background:#f6f7f7;padding:1px 4px}
			.wpa-doc pre code{padding:0}
			.wpa-doc table{border-collapse:collapse;width:100%}
			.wpa-doc th,.wpa-doc td{border:1px solid #dcdcde;padding:6px 10px;text-align:left;vertical-align:top}
			.wpa-doc blockquote{border-left:4px solid #dcdcde;margin-left:0;padding-left:12px;color:#50575e}
		</style>
		<?php self::render_environment(); ?>
		<?php if ( count( $pages ) > 1 ) : ?>
			<p>
				<?php foreach ( $pages as $s => $p ) : ?>
					<a href="<?php echo esc_url( Settings::page_url( [ 'tab' => 'guide', 'doc' => $s ] ) ); ?>"
						<?php echo $s === $slug ? 'style="font-weight:600"' : ''; ?>><?php echo esc_html( $p['title'] ); ?></a>
					&nbsp;
				<?php endforeach; ?>
			</p>
		<?php endif; ?>
		<div class="wpa-doc">
			<?php
			if ( $pages ) {
				echo wp_kses_post( self::markdown( (string) file_get_contents( $pages[ $slug ]['file'] ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			} else {
				echo '<p>' . esc_html__( 'No guide files found in plugin/docs/.', 'wp-astro' ) . '</p>';
			}
			?>
		</div>
		<?php
	}

	/** Server-level values that are fixed in wp-config.php and therefore hidden on the other tabs. */
	private static function render_environment(): void {
		$path    = (string) Settings::get( 'output_path' );
		$locked  = Settings::is_locked( 'output_path' );
		$mode    = (string) Settings::get( 'serve_mode' );
		$origin  = (string) Settings::get( 'remote_origin' );
		$readable = '' !== $path && is_dir( $path ) && is_readable( $path );
		$up      = Updater::status();
		$rows    = [
			__( 'Plugin version', 'wp-astro' ) => $up['current'] . ( null === $up['latest'] ? '' : ( $up['available'] ? sprintf( /* translators: %s: version */ __( ' — %s is available (Plugins page → Update now)', 'wp-astro' ), $up['latest'] ) : __( ' — up to date', 'wp-astro' ) ) ),
			__( 'Mode', 'wp-astro' ) => 'remote' === $mode ? __( 'Netlify', 'wp-astro' ) : __( 'Self-hosted', 'wp-astro' ),
		];
		if ( ! Settings::get( 'serve_enabled' ) ) {
			$rows[ __( 'Warning', 'wp-astro' ) ] = __( 'Serving is switched off — visitors see normal WordPress pages.', 'wp-astro' );
		}
		if ( 'remote' === $mode ) {
			$rows[ __( 'Netlify address', 'wp-astro' ) ] = '' !== $origin ? $origin : __( 'not set', 'wp-astro' );
		} else {
			$rows[ __( 'Build folder', 'wp-astro' ) ] = ( '' !== $path ? $path : __( 'not set', 'wp-astro' ) )
				. ( $locked ? ' — ' . __( 'set by WP_ASTRO_OUTPUT_PATH in wp-config.php', 'wp-astro' ) : '' )
				. ( '' !== $path ? ' — ' . ( $readable ? __( 'folder found', 'wp-astro' ) : __( 'folder NOT found or not readable', 'wp-astro' ) ) : '' );
		}
		?>
		<h2><?php esc_html_e( 'Current setup', 'wp-astro' ); ?></h2>
		<table class="widefat striped" style="max-width:60em">
			<?php foreach ( $rows as $label => $value ) : ?>
				<tr><th scope="row" style="width:14em"><?php echo esc_html( $label ); ?></th><td><?php echo esc_html( $value ); ?></td></tr>
			<?php endforeach; ?>
		</table>
		<?php
	}

	/* ------------------------------------------------------- tiny Markdown */

	/**
	 * Minimal, safe Markdown → HTML: headings, paragraphs, bullet / numbered lists, fenced
	 * code, blockquotes, pipe tables, `code`, **bold**, [links](url). All text is escaped.
	 */
	public static function markdown( string $md ): string {
		$lines = preg_split( '/\R/', $md ) ?: [];
		$n     = count( $lines );
		$html  = '';
		$para  = [];
		$flush = static function () use ( &$para, &$html ) {
			if ( $para ) {
				$html .= '<p>' . self::inline( implode( ' ', $para ) ) . '</p>';
				$para  = [];
			}
		};

		for ( $i = 0; $i < $n; $i++ ) {
			$line = $lines[ $i ];

			if ( preg_match( '/^```/', $line ) ) {
				$flush();
				$code = [];
				for ( $i++; $i < $n && ! preg_match( '/^```/', $lines[ $i ] ); $i++ ) {
					$code[] = $lines[ $i ];
				}
				$html .= '<pre><code>' . esc_html( implode( "\n", $code ) ) . '</code></pre>';
				continue;
			}
			if ( preg_match( '/^(#{1,4})\s+(.*)$/', $line, $m ) ) {
				$flush();
				$level = min( strlen( $m[1] ) + 1, 5 ); // # → h2: the page already has an h1
				$html .= "<h{$level}>" . self::inline( $m[2] ) . "</h{$level}>";
				continue;
			}
			if ( preg_match( '/^\s*([-*]|\d+\.)\s+/', $line ) ) {
				$flush();
				$tag   = preg_match( '/^\s*\d+\./', $line ) ? 'ol' : 'ul';
				$html .= "<$tag>";
				for ( ; $i < $n && preg_match( '/^\s*([-*]|\d+\.)\s+(.*)$/', $lines[ $i ], $m ); $i++ ) {
					$html .= '<li>' . self::inline( $m[2] ) . '</li>';
				}
				$i--;
				$html .= "</$tag>";
				continue;
			}
			if ( preg_match( '/^>\s?/', $line ) ) {
				$flush();
				$quote = [];
				for ( ; $i < $n && preg_match( '/^>\s?(.*)$/', $lines[ $i ], $m ); $i++ ) {
					$quote[] = $m[1];
				}
				$i--;
				$html .= '<blockquote><p>' . self::inline( implode( ' ', $quote ) ) . '</p></blockquote>';
				continue;
			}
			if ( preg_match( '/^\|/', $line ) && isset( $lines[ $i + 1 ] ) && preg_match( '/^\|[\s:|-]+\|?\s*$/', $lines[ $i + 1 ] ) ) {
				$flush();
				$cells = static fn( string $l ): array => array_map( 'trim', explode( '|', trim( trim( $l ), '|' ) ) );
				$html .= '<table><thead><tr>';
				foreach ( $cells( $line ) as $c ) {
					$html .= '<th>' . self::inline( $c ) . '</th>';
				}
				$html .= '</tr></thead><tbody>';
				for ( $i += 2; $i < $n && preg_match( '/^\|/', $lines[ $i ] ); $i++ ) {
					$html .= '<tr>';
					foreach ( $cells( $lines[ $i ] ) as $c ) {
						$html .= '<td>' . self::inline( $c ) . '</td>';
					}
					$html .= '</tr>';
				}
				$i--;
				$html .= '</tbody></table>';
				continue;
			}
			if ( '' === trim( $line ) ) {
				$flush();
				continue;
			}
			$para[] = trim( $line );
		}
		$flush();

		return $html;
	}

	private static function inline( string $text ): string {
		$parts = preg_split( '/(`[^`]+`)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE ) ?: [];
		$out   = '';
		foreach ( $parts as $k => $part ) {
			if ( 1 === $k % 2 ) {
				$out .= '<code>' . esc_html( trim( $part, '`' ) ) . '</code>';
				continue;
			}
			$t   = esc_html( $part );
			$t   = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', $t ) ?? $t;
			$t   = preg_replace_callback(
				'/\[([^\]]+)\]\(([^)\s]+)\)/',
				static function ( $m ) {
					$url = wp_specialchars_decode( $m[2] );
					if ( ! preg_match( '#^(https?://|mailto:|/|\#)#i', $url ) ) {
						return $m[0];
					}
					return '<a href="' . esc_url( $url ) . '">' . $m[1] . '</a>';
				},
				$t
			) ?? $t;
			$out .= $t;
		}
		return $out;
	}
}
