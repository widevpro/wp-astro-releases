<?php
/**
 * Rest — the API surface the Astro build reads at build time.
 *
 *   GET  /wp-json/wp-astro/v1/manifest   published posts flagged "astro" (+ which one is the Blog front)
 *   GET  /wp-json/wp-astro/v1/config     site name/url + shared head/body markup
 *   GET  /wp-json/wp-astro/v1/menus      registered nav menus as nested items
 *   POST /wp-json/wp-astro/v1/purge      ?token=…  drop cached remote pages (Netlify deploy webhook)
 *
 * Plus top-level `render_engine` and `astro_role` fields on wp/v2/<type> (read + write).
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rest {

	public const NS = 'wp-astro/v1';

	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'register' ] );
	}

	public static function register(): void {
		foreach ( Meta::post_types() as $type ) {
			register_rest_field(
				$type,
				'render_engine',
				[
					'get_callback'    => static fn( $arr ) => Meta::get( (int) $arr['id'] ),
					'update_callback' => static function ( $value, $post ) {
						if ( ! current_user_can( 'edit_post', $post->ID ) ) {
							return new \WP_Error( 'wp_astro_forbidden', __( 'Cannot edit this post.', 'wp-astro' ), [ 'status' => 403 ] );
						}
						update_post_meta( $post->ID, Meta::KEY, Meta::sanitize( $value ) );
						return true;
					},
					'schema'          => [
						'type'    => 'string',
						'enum'    => [ Meta::WORDPRESS, Meta::ASTRO ],
						'context' => [ 'view', 'edit' ],
					],
				]
			);
			register_rest_field(
				$type,
				'astro_role',
				[
					'get_callback'    => static fn( $arr ) => Meta::get_role( (int) $arr['id'] ),
					'update_callback' => static function ( $value, $post ) {
						if ( ! current_user_can( 'edit_post', $post->ID ) ) {
							return new \WP_Error( 'wp_astro_forbidden', __( 'Cannot edit this post.', 'wp-astro' ), [ 'status' => 403 ] );
						}
						Meta::set( $post->ID, Meta::get( $post->ID ), (string) $value );
						return true;
					},
					'schema'          => [
						'type'    => 'string',
						'enum'    => [ Meta::ROLE_ARTICLE, Meta::ROLE_FRONT, Meta::ROLE_FULL_WIDTH ],
						'context' => [ 'view', 'edit' ],
					],
				]
			);
		}

		register_rest_route(
			self::NS,
			'/manifest',
			[
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => '__return_true',
				'callback'            => [ __CLASS__, 'manifest' ],
			]
		);

		register_rest_route(
			self::NS,
			'/config',
			[
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => [ __CLASS__, 'can_read_config' ],
				'callback'            => [ __CLASS__, 'config' ],
			]
		);

		register_rest_route(
			self::NS,
			'/menus',
			[
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => '__return_true',
				'callback'            => [ __CLASS__, 'menus' ],
			]
		);

		register_rest_route(
			self::NS,
			'/purge',
			[
				'methods'             => [ 'POST', 'GET' ],
				'permission_callback' => [ __CLASS__, 'can_purge' ],
				'callback'            => [ __CLASS__, 'purge' ],
			]
		);

		register_rest_route(
			self::NS,
			'/build-status',
			[
				'methods'             => 'POST',
				'permission_callback' => [ __CLASS__, 'can_purge' ],
				'callback'            => [ __CLASS__, 'build_status' ],
			]
		);
	}

	/**
	 * Build result callback. Accepts Netlify's deploy webhook payload ("state":
	 * building|ready|error, error_message, ssl_url) or a plain {"state": "success|failed"}.
	 */
	public static function build_status( \WP_REST_Request $req ): \WP_REST_Response {
		$map   = [
			'building' => 'building',
			'enqueued' => 'building',
			'ready'    => 'success',
			'success'  => 'success',
			'error'    => 'failed',
			'failed'   => 'failed',
		];
		$raw   = strtolower( (string) $req->get_param( 'state' ) );
		$state = $map[ $raw ] ?? '';
		if ( '' === $state ) {
			return new \WP_REST_Response( [ 'error' => 'unknown state' ], 400 );
		}
		Trigger::set_status(
			$state,
			sanitize_text_field( (string) $req->get_param( 'error_message' ) ),
			(string) ( $req->get_param( 'ssl_url' ) ?: $req->get_param( 'url' ) )
		);
		return new \WP_REST_Response( [ 'state' => $state, 'at' => gmdate( 'c' ) ] );
	}

	/** Token from ?token= or X-WP-Astro-Token must match the purge_token setting (or a logged-in admin). */
	public static function can_purge( \WP_REST_Request $req ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$expected = (string) Settings::get( 'purge_token' );
		$sent     = (string) ( $req->get_header( 'x-wp-astro-token' ) ?: $req->get_param( 'token' ) );
		return '' !== $expected && hash_equals( $expected, $sent );
	}

	public static function purge(): \WP_REST_Response {
		return new \WP_REST_Response( [ 'purged' => Serve::purge_all(), 'at' => gmdate( 'c' ) ] );
	}

	public static function manifest(): \WP_REST_Response {
		$posts = get_posts(
			[
				'post_type'        => Meta::post_types(),
				'post_status'      => 'publish',
				'numberposts'      => -1,
				'meta_key'         => Meta::KEY,
				'meta_value'       => Meta::ASTRO,
				'orderby'          => 'modified',
				'order'            => 'DESC',
				'suppress_filters' => false,
			]
		);

		$items = array_map(
			static function ( $p ) {
				return [
					'id'           => $p->ID,
					'type'         => $p->post_type,
					'slug'         => $p->post_name,
					'role'         => Meta::get_role( $p->ID ),
					'title'        => get_the_title( $p ),
					'link'         => get_permalink( $p ),
					'path'         => wp_make_link_relative( get_permalink( $p ) ),
					'date_gmt'     => get_post_time( 'c', true, $p ),
					'modified_gmt' => get_post_modified_time( 'c', true, $p ),
				];
			},
			$posts
		);

		$front = null;
		foreach ( $items as $it ) {
			if ( Meta::ROLE_FRONT === $it['role'] ) {
				$front = $it;
				break;
			}
		}

		return new \WP_REST_Response(
			[
				'generated' => gmdate( 'c' ),
				'count'     => count( $items ),
				'front'     => $front,
				'items'     => $items,
			]
		);
	}

	public static function config(): \WP_REST_Response {
		return new \WP_REST_Response(
			[
				'site_name'   => get_bloginfo( 'name' ),
				'site_url'    => home_url( '/' ),
				'shared_head' => (string) Settings::get( 'shared_head' ),
				'shared_body' => (string) Settings::get( 'shared_body' ),
				// Editable in Settings → WP-Astro → Content / Styles; the build merges them over config.ts / theme.json.
				'content'     => (object) Content::stored(),
				'style'       => (object) Style::stored(),
			]
		);
	}

	/** /config is open unless WP_ASTRO_CONFIG_TOKEN is defined, then it must match. */
	public static function can_read_config(): bool {
		if ( ! defined( 'WP_ASTRO_CONFIG_TOKEN' ) || '' === (string) constant( 'WP_ASTRO_CONFIG_TOKEN' ) ) {
			return true;
		}
		$sent = $_SERVER['HTTP_X_WP_ASTRO_TOKEN'] ?? ( $_GET['token'] ?? '' );
		return hash_equals( (string) constant( 'WP_ASTRO_CONFIG_TOKEN' ), (string) $sent );
	}

	public static function menus(): \WP_REST_Response {
		$out       = [];
		$locations = get_nav_menu_locations();

		foreach ( get_registered_nav_menus() as $loc => $label ) {
			$menu_id     = $locations[ $loc ] ?? 0;
			$menu_items  = $menu_id ? ( wp_get_nav_menu_items( $menu_id ) ?: [] ) : [];
			$out[ $loc ] = [
				'label' => $label,
				'items' => self::menu_tree( $menu_items, 0 ),
			];
		}

		return new \WP_REST_Response( $out );
	}

	private static function menu_tree( array $items, int $parent ): array {
		$branch = [];
		foreach ( $items as $it ) {
			if ( (int) $it->menu_item_parent === $parent ) {
				$branch[] = [
					'id'       => (int) $it->ID,
					'label'    => $it->title,
					'url'      => $it->url,
					'path'     => wp_make_link_relative( $it->url ),
					'target'   => $it->target,
					'children' => self::menu_tree( $items, (int) $it->ID ),
				];
			}
		}
		return $branch;
	}
}
