<?php
/**
 * Content — the "Content" settings tab: site-wide values that every Astro page
 * shares (name, phone, address, hours, nav, CTA…). They mirror `SiteConfig` in
 * the frontend 1:1 (same keys), are served inside GET /wp-astro/v1/config as
 * `content`, and the build deep-merges them over `src/sites/<name>/config.ts`.
 * A blank field means "keep the default from config.ts". Nothing here runs when
 * a visitor loads a page — the values are baked into the static HTML at build time.
 *
 * Not editable here (they need build-time assets or are technical): logo, favicons,
 * photos, author, "Treatments mentioned", schema type, locale.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Content {

	public const OPTION = 'wp_astro_content';
	public const GROUP  = 'wp_astro_content_group';

	private const DAYS = [ 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ];

	public static function init(): void {
		add_action( 'admin_init', [ __CLASS__, 'register' ] );
	}

	/**
	 * {variables} usable in descriptions (Content tab and each post's SEO description).
	 * The build fills them in — keep in sync with frontend/src/lib/template.ts.
	 * The last three exist only for articles.
	 */
	public static function variables(): array {
		return [
			'site_name'     => __( 'Site name', 'wp-astro' ),
			'short_name'    => __( 'Short name', 'wp-astro' ),
			'practice_name' => __( 'Practice name', 'wp-astro' ),
			'tagline'       => __( 'Tagline', 'wp-astro' ),
			'phone'         => __( 'Phone (as displayed)', 'wp-astro' ),
			'address'       => __( 'Full address, one line', 'wp-astro' ),
			'city'          => __( 'City', 'wp-astro' ),
			'state'         => __( 'State / region', 'wp-astro' ),
			'postal_code'   => __( 'Postal code', 'wp-astro' ),
			'country'       => __( 'Country', 'wp-astro' ),
			'hours'         => __( 'Working hours, e.g. Mon–Fri 8:00 AM–5:00 PM', 'wp-astro' ),
			'year'          => __( 'Current year', 'wp-astro' ),
			'title'         => __( 'Article title (articles only)', 'wp-astro' ),
			'category'      => __( 'Article category (articles only)', 'wp-astro' ),
			'updated'       => __( 'Article updated date (articles only)', 'wp-astro' ),
		];
	}

	/** "{site_name} {phone} …" for hints. */
	public static function variables_hint(): string {
		return implode( ' ', array_map( static fn( $k ) => '{' . $k . '}', array_keys( self::variables() ) ) );
	}

	public static function register(): void {
		register_setting(
			self::GROUP,
			self::OPTION,
			[
				'sanitize_callback' => [ __CLASS__, 'sanitize' ],
				'default'           => [],
			]
		);
	}

	/** The saved values, nested exactly like SiteConfig (blank fields already dropped). */
	public static function stored(): array {
		$v = get_option( self::OPTION, [] );
		return is_array( $v ) ? $v : [];
	}

	/* ---------------------------------------------------------------- schema */

	private static function f( string $type, string $label, array $extra = [] ): array {
		return array_merge(
			[
				'type'  => $type,
				'label' => $label,
			],
			$extra
		);
	}

	/** section title => [ dotted SiteConfig path => field spec ] */
	private static function schema(): array {
		$f = [ __CLASS__, 'f' ];

		return [
			__( 'Site', 'wp-astro' )           => [
				'name'         => $f( 'text', __( 'Site name', 'wp-astro' ) ),
				'shortName'    => $f( 'text', __( 'Short name', 'wp-astro' ) ),
				'description'  => $f(
					'textarea',
					__( 'Site description', 'wp-astro' ),
					[ 'hint' => __( 'Used in Google structured data (WebSite) and as the fallback when a page has no description. Variables work here too.', 'wp-astro' ) ]
				),
				'articleDescription' => $f(
					'textarea',
					__( 'Default article description', 'wp-astro' ),
					[ 'hint' => '__VARS__' ]
				),
				'sameAs'       => $f( 'lines', __( 'Social profile URLs', 'wp-astro' ), [ 'hint' => __( 'One URL per line. Used for Google structured data; the X / Twitter handle for link cards is taken from the x.com or twitter.com URL.', 'wp-astro' ) ] ),
				'postsPerPage' => $f( 'number', __( 'Articles per page (list)', 'wp-astro' ) ),
			],
			__( 'Header, footer & CTA', 'wp-astro' ) => [
				'nav'          => $f(
					'repeater',
					__( 'Header menu', 'wp-astro' ),
					[
						'hint' => __( 'Use @front as the link to the article list.', 'wp-astro' ),
						'cols' => [
							'label' => $f( 'text', __( 'Label', 'wp-astro' ) ),
							'href'  => $f( 'href', __( 'Link', 'wp-astro' ) ),
						],
					]
				),
				'footerLinks'  => $f(
					'repeater',
					__( 'Footer links', 'wp-astro' ),
					[
						'cols' => [
							'label' => $f( 'text', __( 'Label', 'wp-astro' ) ),
							'href'  => $f( 'href', __( 'Link', 'wp-astro' ) ),
						],
					]
				),
				'cta.label'    => $f( 'text', __( 'CTA button label', 'wp-astro' ) ),
				'cta.href'     => $f( 'href', __( 'CTA button link', 'wp-astro' ) ),
				'sidebarTitle' => $f( 'text', __( 'Sidebar heading', 'wp-astro' ) ),
			],
			__( 'Practice', 'wp-astro' )       => [
				'practice.name'             => $f( 'text', __( 'Practice name', 'wp-astro' ) ),
				'practice.tagline'          => $f( 'text', __( 'Tagline', 'wp-astro' ) ),
				'practice.serviceAreaLabel' => $f( 'text', __( 'Header strap line', 'wp-astro' ) ),
				'practice.imageAlt'         => $f( 'text', __( 'Practice photo alt text', 'wp-astro' ) ),
				'practice.telephone.display' => $f( 'text', __( 'Phone (as displayed)', 'wp-astro' ), [ 'placeholder' => '1-877-987-3296' ] ),
				'practice.telephone.e164'   => $f( 'e164', __( 'Phone (international)', 'wp-astro' ), [ 'placeholder' => '+18779873296' ] ),
				'practice.bookingUrl'       => $f( 'href', __( 'Booking link', 'wp-astro' ) ),
				'practice.reviews.rating'   => $f( 'text', __( 'Review rating', 'wp-astro' ), [ 'placeholder' => '4.9' ] ),
				'practice.reviews.href'     => $f( 'url', __( 'Reviews link', 'wp-astro' ) ),
			],
			__( 'Address & map', 'wp-astro' )  => [
				'practice.address.streetAddress'   => $f( 'text', __( 'Street address', 'wp-astro' ) ),
				'practice.address.addressLocality' => $f( 'text', __( 'City', 'wp-astro' ) ),
				'practice.address.addressRegion'   => $f( 'text', __( 'State / region', 'wp-astro' ) ),
				'practice.address.postalCode'      => $f( 'text', __( 'Postal code', 'wp-astro' ) ),
				'practice.address.addressCountry'  => $f( 'country', __( 'Country code', 'wp-astro' ), [ 'placeholder' => 'US' ] ),
				'practice.address.countryLabel'    => $f( 'text', __( 'Country (as printed)', 'wp-astro' ), [ 'placeholder' => 'United States' ] ),
				'practice.geo.latitude'            => $f( 'decimal', __( 'Latitude', 'wp-astro' ) ),
				'practice.geo.longitude'           => $f( 'decimal', __( 'Longitude', 'wp-astro' ) ),
				'practice.mapEmbedUrl'             => $f( 'url', __( 'Map embed URL', 'wp-astro' ), [ 'hint' => __( 'Leave the three map links blank to build them from the address.', 'wp-astro' ) ] ),
				'practice.directionsUrl'           => $f( 'url', __( 'Directions URL', 'wp-astro' ) ),
				'practice.hasMapUrl'               => $f( 'url', __( 'Map page URL', 'wp-astro' ) ),
			],
			__( 'Hours & areas', 'wp-astro' )  => [
				'practice.hours'      => $f(
					'repeater',
					__( 'Working hours', 'wp-astro' ),
					[
						'cols' => [
							'days'   => $f( 'days', __( 'Days', 'wp-astro' ) ),
							'opens'  => $f( 'time', __( 'Opens', 'wp-astro' ) ),
							'closes' => $f( 'time', __( 'Closes', 'wp-astro' ) ),
						],
					]
				),
				'practice.areaServed' => $f(
					'repeater',
					__( 'Areas served', 'wp-astro' ),
					[
						'cols' => [
							'name'       => $f( 'text', __( 'Area', 'wp-astro' ) ),
							'postalCode' => $f( 'text', __( 'Postal code', 'wp-astro' ), [ 'optional' => true ] ),
						],
					]
				),
			],
		];
	}

	/** Every field spec keyed by its dotted path. */
	private static function flat(): array {
		$out = [];
		foreach ( self::schema() as $fields ) {
			$out += $fields;
		}
		return $out;
	}

	/* ------------------------------------------------------------- sanitize */

	public static function sanitize( $input ): array {
		$in  = is_array( $input ) ? wp_unslash( $input ) : [];
		$out = [];

		foreach ( self::flat() as $path => $spec ) {
			$val = self::clean( self::get_path( $in, $path ), $spec );
			if ( null !== $val && '' !== $val && [] !== $val ) {
				self::set_path( $out, $path, $val );
			}
		}

		// Coordinates only make sense as a pair.
		if ( ! isset( $out['practice']['geo']['latitude'], $out['practice']['geo']['longitude'] ) ) {
			unset( $out['practice']['geo'] );
		}
		// A half-filled address would print blanks; keep it all-or-nothing (country label may stay blank).
		$addr = $out['practice']['address'] ?? null;
		if ( is_array( $addr ) ) {
			foreach ( [ 'streetAddress', 'addressLocality', 'addressRegion', 'postalCode', 'addressCountry' ] as $k ) {
				if ( empty( $addr[ $k ] ) ) {
					add_settings_error(
						self::OPTION,
						'wp_astro_address',
						__( 'Address ignored: fill street, city, state, postal code and country code together, or leave all blank to keep the config.ts address.', 'wp-astro' ),
						'warning'
					);
					unset( $out['practice']['address'] );
					break;
				}
			}
		}

		return $out;
	}

	private static function clean( $raw, array $spec ) {
		switch ( $spec['type'] ) {
			case 'text':
				return sanitize_text_field( (string) $raw );
			case 'textarea':
				return sanitize_textarea_field( (string) $raw );
			case 'url':
				return esc_url_raw( trim( (string) $raw ) );
			case 'href':
				return self::clean_href( (string) $raw );
			case 'number':
				$n = absint( $raw );
				return $n >= 1 ? min( $n, 100 ) : '';
			case 'decimal':
				$raw = trim( (string) $raw );
				return is_numeric( $raw ) ? (float) $raw : '';
			case 'e164':
				$p = preg_replace( '/[^\d+]/', '', (string) $raw );
				return preg_match( '/^\+\d{6,15}$/', (string) $p ) ? $p : '';
			case 'country':
				$c = strtoupper( trim( (string) $raw ) );
				return preg_match( '/^[A-Z]{2}$/', $c ) ? $c : '';
			case 'time':
				$t = trim( (string) $raw );
				return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $t ) ? $t : '';
			case 'days':
				return array_values( array_intersect( self::DAYS, array_map( 'strval', (array) $raw ) ) );
			case 'lines':
				$urls = array_map( 'esc_url_raw', array_map( 'trim', preg_split( '/\R/', (string) $raw ) ?: [] ) );
				return array_values( array_filter( $urls ) );
			case 'repeater':
				$rows = [];
				foreach ( array_values( (array) $raw ) as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					$clean = [];
					$keep  = true;
					foreach ( $spec['cols'] as $key => $col ) {
						$v = self::clean( $row[ $key ] ?? '', $col );
						if ( ( '' === $v || [] === $v ) && empty( $col['optional'] ) ) {
							$keep = false;
							break;
						}
						if ( '' !== $v && [] !== $v ) {
							$clean[ $key ] = $v;
						}
					}
					if ( $keep ) {
						$rows[] = $clean;
					}
				}
				return $rows;
		}
		return '';
	}

	/** A link: site path, #anchor, the @front token, or a full URL. */
	private static function clean_href( string $raw ): string {
		$v = trim( $raw );
		if ( '' === $v ) {
			return '';
		}
		if ( '@front' === $v || preg_match( '#^[/\#?]#', $v ) ) {
			return sanitize_text_field( $v );
		}
		return esc_url_raw( $v );
	}

	/* ---------------------------------------------------------------- paths */

	private static function get_path( array $arr, string $path ) {
		foreach ( explode( '.', $path ) as $k ) {
			if ( ! is_array( $arr ) || ! array_key_exists( $k, $arr ) ) {
				return null;
			}
			$arr = $arr[ $k ];
		}
		return $arr;
	}

	private static function set_path( array &$arr, string $path, $value ): void {
		$ref = &$arr;
		foreach ( explode( '.', $path ) as $k ) {
			if ( ! isset( $ref[ $k ] ) || ! is_array( $ref[ $k ] ) ) {
				$ref[ $k ] = [];
			}
			$ref = &$ref[ $k ];
		}
		$ref = $value;
	}

	/* --------------------------------------------------------------- render */

	private static function name_for( string $path ): string {
		return self::OPTION . '[' . implode( '][', explode( '.', $path ) ) . ']';
	}

	public static function render(): void {
		$saved = self::stored();
		?>
		<form method="post" action="options.php">
			<?php settings_fields( self::GROUP ); ?>
			<p class="description" style="max-width:60em">
				<?php esc_html_e( 'Site-wide values shown on every HTML page. A blank field keeps the default from the site’s config.ts. Saving triggers a rebuild; visitors never wait on these values — they are baked into the static HTML.', 'wp-astro' ); ?>
			</p>
			<?php foreach ( self::schema() as $title => $fields ) : ?>
				<h2><?php echo esc_html( $title ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $fields as $path => $spec ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( $spec['label'] ); ?></th>
							<td>
								<?php self::render_field( $path, $spec, self::get_path( $saved, $path ) ); ?>
								<?php if ( '__VARS__' === ( $spec['hint'] ?? '' ) ) : ?>
									<p class="description">
										<?php esc_html_e( 'Meta description for every article that has no description of its own (set per article in its Render Engine box, or by Yoast). Leave blank to use each article’s excerpt. Example: Dental tourism in Mexico - {site_name}. Call us - {phone}.', 'wp-astro' ); ?>
									</p>
									<details style="margin-top:6px"><summary><?php esc_html_e( 'Available variables', 'wp-astro' ); ?></summary>
										<table class="widefat striped" style="max-width:34em;margin-top:6px">
											<?php foreach ( self::variables() as $var => $label ) : ?>
												<tr><td><code>{<?php echo esc_html( $var ); ?>}</code></td><td><?php echo esc_html( $label ); ?></td></tr>
											<?php endforeach; ?>
										</table>
									</details>
								<?php elseif ( ! empty( $spec['hint'] ) ) : ?>
									<p class="description"><?php echo esc_html( $spec['hint'] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button(); ?>
		</form>
		<?php self::render_script(); ?>
		<?php
	}

	private static function render_field( string $path, array $spec, $value ): void {
		self::render_input( self::name_for( $path ), $spec, $value );
	}

	/** One input for any field type (also used for repeater cells). */
	private static function render_input( string $name, array $spec, $value, bool $in_row = false ): void {
		$ph = isset( $spec['placeholder'] ) ? ' placeholder="' . esc_attr( $spec['placeholder'] ) . '"' : '';
		$n  = esc_attr( $name );

		switch ( $spec['type'] ) {
			case 'textarea':
				printf( '<textarea class="large-text" rows="3" name="%s">%s</textarea>', $n, esc_textarea( (string) $value ) );
				break;
			case 'lines':
				printf( '<textarea class="large-text code" rows="3" name="%s">%s</textarea>', $n, esc_textarea( implode( "\n", (array) $value ) ) );
				break;
			case 'days':
				foreach ( self::DAYS as $day ) {
					printf(
						'<label style="margin-right:.6em;white-space:nowrap"><input type="checkbox" name="%s[]" value="%s"%s> %s</label>',
						$n,
						esc_attr( $day ),
						checked( in_array( $day, (array) $value, true ), true, false ),
						esc_html( substr( $day, 0, 3 ) )
					);
				}
				break;
			case 'time':
				printf( '<input type="time" name="%s" value="%s">', $n, esc_attr( (string) $value ) );
				break;
			case 'number':
				printf( '<input type="number" min="1" max="100" class="small-text" name="%s" value="%s">', $n, esc_attr( (string) $value ) );
				break;
			case 'repeater':
				self::render_repeater( $name, $spec, is_array( $value ) ? $value : [] );
				break;
			default:
				printf(
					'<input type="text" class="%s" name="%s" value="%s"%s>',
					$in_row ? 'regular-text' : 'regular-text code',
					$n,
					esc_attr( (string) $value ),
					$ph // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr above.
				);
		}
	}

	private static function render_repeater( string $name, array $spec, array $rows ): void {
		$id = 'wpa-' . substr( md5( $name ), 0, 8 );
		printf( '<div class="wpa-repeater" id="%s" data-next="%d">', esc_attr( $id ), count( $rows ) );
		foreach ( $rows as $i => $row ) {
			self::render_row( $name, $spec, (string) $i, (array) $row );
		}
		echo '</div>';
		echo '<template id="' . esc_attr( $id ) . '-tpl">';
		self::render_row( $name, $spec, '__i__', [] );
		echo '</template>';
		printf(
			'<button type="button" class="button wpa-add" data-target="#%1$s" data-tpl="#%1$s-tpl">%2$s</button>',
			esc_attr( $id ),
			esc_html__( 'Add row', 'wp-astro' )
		);
	}

	private static function render_row( string $name, array $spec, string $i, array $row ): void {
		echo '<div class="wpa-row" style="display:flex;flex-wrap:wrap;gap:.5em;align-items:center;margin-bottom:.5em">';
		foreach ( $spec['cols'] as $key => $col ) {
			printf( '<span class="wpa-col"><em style="display:block;font-size:11px">%s</em>', esc_html( $col['label'] ) );
			self::render_input( $name . '[' . $i . '][' . $key . ']', $col, $row[ $key ] ?? '', true );
			echo '</span>';
		}
		printf( '<button type="button" class="button-link-delete wpa-remove">%s</button>', esc_html__( 'Remove', 'wp-astro' ) );
		echo '</div>';
	}

	private static function render_script(): void {
		?>
		<script>
		document.querySelectorAll('.wpa-add').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var wrap = document.querySelector(btn.dataset.target);
				var tpl = document.querySelector(btn.dataset.tpl);
				var n = parseInt(wrap.dataset.next, 10) || 0;
				wrap.insertAdjacentHTML('beforeend', tpl.innerHTML.split('__i__').join(String(n)));
				wrap.dataset.next = String(n + 1);
			});
		});
		document.addEventListener('click', function (e) {
			if (e.target.classList && e.target.classList.contains('wpa-remove')) {
				e.target.closest('.wpa-row').remove();
			}
		});
		</script>
		<?php
	}
}
