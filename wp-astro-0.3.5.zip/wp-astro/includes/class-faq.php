<?php
/**
 * Faq — the FAQ of an article (FAQ section + schema.org FAQPage on the built page).
 *
 * Where it comes from, in order:
 *   1. "custom"  — a list saved with the article (post meta _wp_astro_faq, edited in W-Blog → Articles).
 *                  An empty list means "no FAQ" and hides the text section too.
 *   2. "content" — no custom list: the build reads the FAQ out of the article text, exactly like
 *                  the frontend does: an H2 containing "FAQ" / "Frequently Asked Questions", with each
 *                  question as an H3/H4 followed by its answer.
 *   3. "none"    — neither exists, so the page has no FAQ block and no FAQPage markup.
 * A separate on/off switch (_wp_astro_faq_on) hides the FAQ without losing the list.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Faq {

	public const META    = '_wp_astro_faq';
	public const META_ON = '_wp_astro_faq_on'; // '0' = switched off (list kept); absent = on

	private const MAX_ITEMS = 30;

	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'register' ] );
	}

	public static function register(): void {
		foreach ( Meta::post_types() as $type ) {
			register_post_meta(
				$type,
				self::META,
				[
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true, // the Astro build reads it from the post's REST meta
					'sanitize_callback' => [ __CLASS__, 'sanitize_meta' ],
					'auth_callback'     => static fn( $allowed, $key, $post_id ) => current_user_can( 'edit_post', $post_id ),
				]
			);
			register_post_meta(
				$type,
				self::META_ON,
				[
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => static fn( $v ) => '0' === (string) $v ? '0' : '',
					'auth_callback'     => static fn( $allowed, $key, $post_id ) => current_user_can( 'edit_post', $post_id ),
				]
			);
		}
	}

	/** Re-validate whatever is written to the meta (REST or code) so the page can trust it. */
	public static function sanitize_meta( $value ): string {
		$data = json_decode( (string) $value, true );
		return is_array( $data ) ? (string) wp_json_encode( self::clean( $data ) ) : '';
	}

	/** @return array<int,array{q:string,a:string}>|null null = no custom list saved */
	public static function stored( int $post_id ): ?array {
		$raw = (string) get_post_meta( $post_id, self::META, true );
		if ( '' === $raw ) {
			return null;
		}
		$data = json_decode( $raw, true );
		return is_array( $data ) ? self::clean( $data ) : null;
	}

	/** Same detection as frontend/src/lib/article.ts (extractReferences + extractFaq). */
	public static function from_content( string $html ): array {
		// The trailing "Sources Cited From" list is not part of the last answer.
		$html = preg_replace( '/<(?:p|h[23])>\s*(?:<(?:strong|b)>\s*)?(?:Sources Cited From|Sources|References)\s*:?\s*(?:<\/(?:strong|b)>\s*)?<\/(?:p|h[23])>\s*(<(ol|ul)\b[\s\S]*?<\/\2>)/i', '', $html ) ?? $html;
		if ( ! preg_match( '/<h2\b[^>]*>(?:(?!<\/h2>)[\s\S])*?(?:FAQ|Frequently Asked Questions)[\s\S]*?<\/h2>([\s\S]*?)(?=<h2\b|$)/i', $html, $m ) ) {
			return [];
		}
		$items = [];
		if ( preg_match_all( '/<h[34]\b[^>]*>([\s\S]*?)<\/h[34]>([\s\S]*?)(?=<h[34]\b|$)/', $m[1], $rows, PREG_SET_ORDER ) ) {
			foreach ( $rows as $row ) {
				$q = trim( wp_strip_all_tags( $row[1] ) );
				$a = trim( $row[2] );
				if ( '' !== $q && '' !== trim( wp_strip_all_tags( $a ) ) ) {
					$items[] = [
						'q' => $q,
						'a' => $a,
					];
				}
			}
		}
		return self::clean( $items );
	}

	/** Is the FAQ shown on the page? (The list is kept when it is switched off.) */
	public static function enabled( int $post_id ): bool {
		return '0' !== (string) get_post_meta( $post_id, self::META_ON, true );
	}

	public static function set_enabled( int $post_id, bool $on ): void {
		if ( $on ) {
			delete_post_meta( $post_id, self::META_ON );
		} else {
			update_post_meta( $post_id, self::META_ON, '0' );
		}
	}

	/** @return array{source:string,enabled:bool,items:array<int,array{q:string,a:string}>} */
	public static function effective( \WP_Post $p ): array {
		$enabled = self::enabled( $p->ID );
		$stored  = self::stored( $p->ID );
		if ( null !== $stored ) {
			return [
				'source'  => 'custom',
				'enabled' => $enabled,
				'items'   => $stored,
			];
		}
		$items = self::from_content( (string) $p->post_content );
		return [
			'source'  => $items ? 'content' : 'none',
			'enabled' => $enabled,
			'items'   => $items,
		];
	}

	/** Save a custom list (an empty list switches the FAQ off). */
	public static function save( int $post_id, array $items ): array {
		update_post_meta( $post_id, self::META, wp_json_encode( self::clean( $items ) ) );
		return self::effective( get_post( $post_id ) );
	}

	/** Back to automatic: read the FAQ from the article text again. */
	public static function reset( int $post_id ): array {
		delete_post_meta( $post_id, self::META );
		return self::effective( get_post( $post_id ) );
	}

	/** Trim, drop empty or incomplete rows, allow basic formatting only in answers. */
	private static function clean( array $items ): array {
		$allowed = [
			'p'      => [],
			'br'     => [],
			'ul'     => [],
			'ol'     => [],
			'li'     => [],
			'strong' => [],
			'b'      => [],
			'em'     => [],
			'i'      => [],
			'a'      => [
				'href'   => [],
				'title'  => [],
				'rel'    => [],
				'target' => [],
			],
		];
		$out = [];
		foreach ( array_slice( array_values( $items ), 0, self::MAX_ITEMS ) as $it ) {
			if ( ! is_array( $it ) ) {
				continue;
			}
			$q = sanitize_text_field( (string) ( $it['q'] ?? '' ) );
			$a = trim( wp_kses( (string) ( $it['a'] ?? '' ), $allowed ) );
			if ( '' === $q || '' === trim( wp_strip_all_tags( $a ) ) ) {
				continue;
			}
			if ( ! preg_match( '/<\w+/', $a ) ) {
				$a = trim( wpautop( $a ) ); // plain text → paragraphs
			}
			$out[] = [
				'q' => mb_substr( $q, 0, 300 ),
				'a' => force_balance_tags( mb_substr( $a, 0, 8000 ) ),
			];
		}
		return $out;
	}
}
