# Basic functions

A tour of what W-Blog does and where to find it. Detailed steps are in the **W-Blog guide** page.

## What an editor can do

| I want to… | Go to |
| --- | --- |
| see all articles, search, filter, sort, bulk-edit | **W-Blog → Articles** |
| edit one article | Click its title in the Articles list |
| change the site name, phone, address, menu, footer, button | **Settings → Content** |
| change colours, fonts, sizes, corners | **Settings → Styles** |
| choose the blog front page, shared head/body code, import from an old site | **Settings → General** |
| choose how pages are served, how changes go live, rebuild now | **Settings → Deploy** |
| check page speed | **Settings → Google** and the PageSpeed column in Articles |
| update the plugin | **Settings → Check for updates** |

## The Articles list

- Columns: title and address, status, template, category, FAQ, PageSpeed, content score, updated.
- Search, status filter, category filter, and quick filters (no FAQ, low score, stale).
- Change the template (with sidebar or full width) and the category in the row.
- Bulk actions: set to draft, publish, change template, add a category, run a PageSpeed check, switch back to WordPress, move to the trash.

## The edit screen

Top to bottom:

- **Top bar and Header:** the header text, phone line, title, address, category, tags, template and featured image with alt text.
- **Summary (TL;DR):** the short answer at the top, with a switch.
- **Body, FAQ and Sources:** the body editor (visual and HTML), FAQ question-and-answer pairs, and a sources list.
- **Author:** a WordPress user with a public profile, with a switch for the "About the author" block.
- **Services / products / treatments:** up to three cards (picture and title) in one row, automatic or hand-picked.
- **Company card:** one switch per part (picture, name, description, phone, address, hours, areas, buttons, map, rating). Each part can show the site's value or its own value for this page only.
- **Page elements:** contents list (full-width pages), breadcrumbs, share buttons, reading time, the call-to-action button and related articles.
- **SEO:** the page title and description (with variables), index and follow switches, canonical address, social title, description and picture, and the schema type.
- **The side column:** the live page and its build state, publishing, the structured data Google reads, and the content score with tips.

## Two layouts

- **With sidebar:** contents list, share buttons and a call-to-action box beside the text.
- **Full width:** one centred text column. The contents list sits above the text (it can be switched off), the share buttons sit under the text, and there is no sidebar box.

## Content and Styles

- **Content** holds what is shown on every page. A blank field keeps the default from the site's design; a field that has nothing anywhere prints nothing.
- **Styles** is one CSS block listing every variable with its default: colours, heading sizes, text, buttons, boxes, hero and layout, plus the Google font name and weights for headings and text. Only the lines you change are saved. A separate field holds optional custom CSS.

## Rules that apply everywhere

- Saving is instant; the public pages change after a rebuild (about 2–3 minutes).
- A part that is switched on but has nothing in it is not shown.
- Visitors never wait on any of this: the values are baked into the static pages.
- If something fails, the normal WordPress page is shown instead.

## Descriptions with variables

A description can use `{variables}`, for example `Dental tourism in Mexico - {site_name}. Call us - {phone}.` The build fills them in. For the site: `site_name`, `short_name`, `practice_name`, `tagline`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `hours`, `year`. For an article also `title`, `category` and `updated`. An unknown name is left as typed, so a typo is easy to spot. The full list is under the **Default article description** field.

## Google PageSpeed

1. In Google Cloud Console create or choose a project, then APIs & Services → Library → enable **PageSpeed Insights API**.
2. Credentials → Create credentials → API key. Restrict it to the PageSpeed Insights API and leave the application restriction **None** (the calls come from the server). The API is free with a daily quota.
3. In W-Blog → Settings → **Google** paste the key, click **Test connection**, then save.
4. In **Articles** click **Check** on a row, or use the bulk action. Google can only test public addresses, so run it on staging or production, not on localhost.

You are running W-Blog {{version}}; see **Release history** for what changed in each version.
