<?php
/**
 * Authors — real WordPress users as the article's author and reviewer.
 *
 * Each user gets a "W-Blog author profile" on their profile page (job title, credential, photo,
 * links, author page) and a tick "Show as a public author". The Astro build receives the card as
 * `astro_author` / `astro_reviewer` on every post (REST). A user who is not ticked is never shown,
 * so ordinary editors do not suddenly appear on the site as "the author".
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Authors {

	private const FIELDS = [
		'wpa_public'     => 'flag',
		'wpa_job_title'  => 'text',
		'wpa_cred_abbr'  => 'text',
		'wpa_cred_name'  => 'text',
		'wpa_photo'      => 'int',
		'wpa_author_url' => 'url',
		'wpa_links'      => 'lines',
	];

	public static function init(): void {
		add_action( 'show_user_profile', [ __CLASS__, 'render_fields' ] );
		add_action( 'edit_user_profile', [ __CLASS__, 'render_fields' ] );
		add_action( 'personal_options_update', [ __CLASS__, 'save_fields' ] );
		add_action( 'edit_user_profile_update', [ __CLASS__, 'save_fields' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_action( 'rest_api_init', [ __CLASS__, 'rest_fields' ] );
	}

	public static function enqueue( string $hook ): void {
		if ( in_array( $hook, [ 'profile.php', 'user-edit.php' ], true ) ) {
			wp_enqueue_media();
		}
	}

	/* --------------------------------------------------------- the card */

	/** @return array<string,mixed>|null */
	public static function card( int $user_id ): ?array {
		$u = get_userdata( $user_id );
		if ( ! $u ) {
			return null;
		}
		$meta     = static fn( string $k ): string => (string) get_user_meta( $user_id, $k, true );
		$photo_id = (int) $meta( 'wpa_photo' );
		$photo    = $photo_id ? wp_get_attachment_image_src( $photo_id, 'medium' ) : false;
		$links    = array_values( array_filter( array_map( 'esc_url_raw', array_map( 'trim', preg_split( '/\R/', $meta( 'wpa_links' ) ) ?: [] ) ) ) );

		return [
			'id'         => $user_id,
			'public'     => '1' === $meta( 'wpa_public' ),
			'name'       => $u->display_name,
			'job_title'  => $meta( 'wpa_job_title' ),
			'credential' => [
				'abbr' => $meta( 'wpa_cred_abbr' ),
				'name' => $meta( 'wpa_cred_name' ),
			],
			'bio'        => (string) $u->description,
			'photo'      => $photo ? [
				'id'     => $photo_id,
				'url'    => $photo[0],
				'width'  => (int) $photo[1],
				'height' => (int) $photo[2],
			] : [
				'id'     => 0,
				'url'    => (string) get_avatar_url( $user_id, [ 'size' => 192 ] ),
				'width'  => 192,
				'height' => 192,
			],
			'url'        => $meta( 'wpa_author_url' ) ?: (string) get_author_posts_url( $user_id ),
			'links'      => $links,
		];
	}

	/** Users that can be picked as author / reviewer. */
	public static function options(): array {
		$out = [];
		foreach ( get_users( [ 'capability__in' => [ 'edit_posts' ], 'orderby' => 'display_name' ] ) as $u ) {
			$c     = self::card( $u->ID );
			$out[] = [
				'id'     => $u->ID,
				'name'   => $u->display_name,
				'public' => (bool) ( $c['public'] ?? false ),
				'photo'  => $c['photo']['url'] ?? '',
				'role'   => (string) ( $c['job_title'] ?? '' ),
			];
		}
		return $out;
	}

	public static function rest_fields(): void {
		foreach ( Meta::post_types() as $type ) {
			register_rest_field(
				$type,
				'astro_author',
				[
					'get_callback' => static function ( $arr ) {
						$c = self::card( (int) get_post_field( 'post_author', (int) $arr['id'] ) );
						return $c && $c['public'] ? $c : null;
					},
					'schema'       => [ 'type' => [ 'object', 'null' ] ],
				]
			);
			register_rest_field(
				$type,
				'astro_reviewer',
				[
					'get_callback' => static function ( $arr ) {
						$r  = Article_Edit::review( (int) $arr['id'] );
						$c  = $r['by'] ? self::card( $r['by'] ) : null;
						return $c ? $c + [ 'reviewed' => $r['date'] ] : null;
					},
					'schema'       => [ 'type' => [ 'object', 'null' ] ],
				]
			);
		}
	}

	/* ----------------------------------------------------- profile page */

	public static function render_fields( \WP_User $user ): void {
		$v     = static fn( string $k ): string => (string) get_user_meta( $user->ID, $k, true );
		$photo = (int) $v( 'wpa_photo' );
		$thumb = $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '';
		wp_nonce_field( 'wpa_author_profile', 'wpa_author_nonce' );
		?>
		<h2><?php esc_html_e( 'W-Blog author profile', 'wp-astro' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Shown in the “About the author” block and the byline of articles that use this person as author or reviewer.', 'wp-astro' ); ?></p>
		<table class="form-table" role="presentation">
			<tr>
				<th><?php esc_html_e( 'Public author', 'wp-astro' ); ?></th>
				<td><label><input type="checkbox" name="wpa_public" value="1" <?php checked( '1', $v( 'wpa_public' ) ); ?>> <?php esc_html_e( 'Show this person as the author of their articles', 'wp-astro' ); ?></label></td>
			</tr>
			<tr>
				<th><label for="wpa_job_title"><?php esc_html_e( 'Job title', 'wp-astro' ); ?></label></th>
				<td><input type="text" class="regular-text" id="wpa_job_title" name="wpa_job_title" value="<?php echo esc_attr( $v( 'wpa_job_title' ) ); ?>" placeholder="Prosthodontist"></td>
			</tr>
			<tr>
				<th><label for="wpa_cred_abbr"><?php esc_html_e( 'Credential', 'wp-astro' ); ?></label></th>
				<td>
					<input type="text" class="small-text" id="wpa_cred_abbr" name="wpa_cred_abbr" value="<?php echo esc_attr( $v( 'wpa_cred_abbr' ) ); ?>" placeholder="DDS">
					<input type="text" class="regular-text" name="wpa_cred_name" value="<?php echo esc_attr( $v( 'wpa_cred_name' ) ); ?>" placeholder="Doctor of Dental Surgery">
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Photo', 'wp-astro' ); ?></th>
				<td>
					<input type="hidden" id="wpa_photo" name="wpa_photo" value="<?php echo (int) $photo; ?>">
					<img id="wpa_photo_preview" src="<?php echo esc_url( (string) $thumb ); ?>" alt="" style="width:96px;height:96px;object-fit:cover;border-radius:50%;<?php echo $thumb ? '' : 'display:none;'; ?>">
					<p><button type="button" class="button" id="wpa_photo_pick"><?php esc_html_e( 'Choose photo', 'wp-astro' ); ?></button>
					<button type="button" class="button-link" id="wpa_photo_clear" style="margin-left:8px"><?php esc_html_e( 'Remove', 'wp-astro' ); ?></button></p>
					<p class="description"><?php esc_html_e( 'A square photo, about 400 × 400 px, JPG or WebP, under 100 KB. Without one, the Gravatar picture is used.', 'wp-astro' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="wpa_author_url"><?php esc_html_e( 'Author page', 'wp-astro' ); ?></label></th>
				<td><input type="url" class="regular-text" id="wpa_author_url" name="wpa_author_url" value="<?php echo esc_attr( $v( 'wpa_author_url' ) ); ?>" placeholder="https://example.com/team/dr-name/"></td>
			</tr>
			<tr>
				<th><label for="wpa_links"><?php esc_html_e( 'Profile links', 'wp-astro' ); ?></label></th>
				<td>
					<textarea class="large-text code" rows="3" id="wpa_links" name="wpa_links" placeholder="https://www.linkedin.com/in/…"><?php echo esc_textarea( $v( 'wpa_links' ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One URL per line (LinkedIn, medical board, social). Used in the author block and as schema.org sameAs.', 'wp-astro' ); ?></p>
				</td>
			</tr>
		</table>
		<script>
		(function () {
			var pick = document.getElementById('wpa_photo_pick'), clear = document.getElementById('wpa_photo_clear');
			var field = document.getElementById('wpa_photo'), img = document.getElementById('wpa_photo_preview');
			if (!pick || !window.wp || !wp.media) return;
			pick.addEventListener('click', function () {
				var frame = wp.media({ title: 'Author photo', library: { type: 'image' }, multiple: false });
				frame.on('select', function () {
					var a = frame.state().get('selection').first().toJSON();
					field.value = a.id; img.src = (a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url); img.style.display = '';
				});
				frame.open();
			});
			clear.addEventListener('click', function () { field.value = ''; img.style.display = 'none'; });
		})();
		</script>
		<?php
	}

	public static function save_fields( int $user_id ): void {
		if ( ! current_user_can( 'edit_user', $user_id ) || ! isset( $_POST['wpa_author_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['wpa_author_nonce'] ), 'wpa_author_profile' ) ) {
			return;
		}
		foreach ( self::FIELDS as $key => $type ) {
			$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised below by type
			switch ( $type ) {
				case 'flag':
					$val = ! empty( $raw ) ? '1' : '';
					break;
				case 'int':
					$val = (string) absint( $raw );
					$val = '0' === $val ? '' : $val;
					break;
				case 'url':
					$val = esc_url_raw( (string) $raw );
					break;
				case 'lines':
					$val = implode( "\n", array_filter( array_map( 'esc_url_raw', array_map( 'trim', preg_split( '/\R/', (string) $raw ) ?: [] ) ) ) );
					break;
				default:
					$val = sanitize_text_field( (string) $raw );
			}
			if ( '' === $val ) {
				delete_user_meta( $user_id, $key );
			} else {
				update_user_meta( $user_id, $key, $val );
			}
		}
	}
}
