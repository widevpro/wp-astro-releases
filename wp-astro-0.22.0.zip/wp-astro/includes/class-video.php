<?php
/**
 * The [video] shortcode in an article, with the switches WordPress leaves out.
 *
 * WordPress's own [video] already takes webm="", mp4="", poster="", autoplay="on", loop="on",
 * muted="on" and preload="none|metadata|auto". This adds:
 *   controls="off"   no play / volume / fullscreen bar (a silent loop that works like a GIF)
 *   mobile="off"     not shown on phones (screens up to 36rem / 576px wide)
 * and makes autoplay work on phones: browsers only autoplay a muted video that plays inline,
 * so autoplay="on" always adds muted and playsinline.
 *
 * With both files, the WebM is listed first (smaller; the MP4 stays for Safari / older iPhones).
 * Otherwise a [video] without these attributes is untouched.
 *
 * @package Wp_Astro
 */

namespace Wp_Astro;

defined( 'ABSPATH' ) || exit;

final class Video {

	public static function init(): void {
		add_filter( 'shortcode_atts_video', [ __CLASS__, 'keep_atts' ], 10, 3 );
		add_filter( 'wp_video_shortcode', [ __CLASS__, 'tag' ], 10, 2 );
	}

	/** WordPress drops attributes it does not know; keep ours so tag() can read them. */
	public static function keep_atts( array $out, array $pairs, array $atts ): array {
		foreach ( [ 'controls', 'mobile' ] as $key ) {
			$out[ $key ] = isset( $atts[ $key ] ) ? strtolower( trim( (string) $atts[ $key ] ) ) : '';
		}
		return $out;
	}

	/** The switches applied to the <video> tag WordPress built. */
	public static function tag( string $html, array $atts ): string {
		$off      = static fn( string $key ): bool => in_array( $atts[ $key ] ?? '', [ 'off', 'no', 'false', '0' ], true );
		$autoplay = wp_validate_boolean( $atts['autoplay'] ?? false );

		// WordPress lists the MP4 first; browsers take the first file they can play, so put the
		// smaller WebM first and keep the MP4 for Safari / older iPhones.
		if ( preg_match( '/<source\b[^>]*type="video\/webm"[^>]*>/', $html, $webm ) ) {
			$html = str_replace( $webm[0], '', $html );
			$html = (string) preg_replace( '/(<video\b[^>]*>)/', '$1' . str_replace( '$', '\$', $webm[0] ), $html, 1 );
		}

		return (string) preg_replace_callback(
			'/<video\b[^>]*>/',
			static function ( array $m ) use ( $off, $autoplay ): string {
				$tag = $m[0];
				if ( $off( 'controls' ) ) {
					$tag = (string) preg_replace( '/\s+controls(="[^"]*")?/', '', $tag );
				}
				if ( $autoplay && ! preg_match( '/\smuted\b/', $tag ) ) {
					$tag = str_replace( '<video', '<video muted', $tag );
				}
				if ( $autoplay && ! preg_match( '/\splaysinline\b/', $tag ) ) {
					$tag = str_replace( '<video', '<video playsinline', $tag );
				}
				if ( $off( 'mobile' ) ) {
					$tag = (string) preg_replace( '/\bclass="/', 'class="wa-no-mobile ', $tag, 1 );
				}
				return $tag;
			},
			$html,
			1
		);
	}
}
