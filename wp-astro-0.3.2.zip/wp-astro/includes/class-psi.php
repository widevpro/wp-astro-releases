<?php
/**
 * Psi — Google PageSpeed Insights (API v5) checks for Astro articles. One check runs
 * both strategies (mobile + desktop) against the article's public URL and stores the
 * scores and Core Web Vitals-style metrics in post meta, so the Articles table can show
 * them without calling Google again. Needs the API key from Astro → Settings → Google.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Psi {

	public const META = '_wp_astro_psi';

	private const ENDPOINT = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';

	/** The stored result for a post, or null if it was never checked. */
	public static function get( int $post_id ): ?array {
		$d = get_post_meta( $post_id, self::META, true );
		if ( ! is_array( $d ) || empty( $d['mobile'] ) || empty( $d['desktop'] ) ) {
			return null;
		}
		$d['ago'] = human_time_diff( (int) ( $d['checked'] ?? time() ) );
		return $d;
	}

	/**
	 * The address Google is asked to test: the post's permalink. Google cannot reach
	 * localhost, so that is refused early with an explanation.
	 *
	 * @return string|\WP_Error
	 */
	public static function target_url( \WP_Post $p ) {
		$url  = (string) get_permalink( $p );
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		if ( '' === $host || in_array( $host, [ 'localhost', '127.0.0.1', '::1' ], true ) || preg_match( '/\.(local|test|localhost)$/', $host ) ) {
			return new \WP_Error(
				'wp_astro_psi_local',
				sprintf(
					/* translators: %s: host name */
					__( 'Google cannot reach “%s”. PageSpeed checks only work on a public site — run it where the article is published.', 'wp-astro' ),
					$host
				),
				[ 'status' => 400 ]
			);
		}
		return $url;
	}

	/** Run mobile + desktop, store and return the result. */
	public static function run( int $post_id ) {
		$p = get_post( $post_id );
		if ( ! $p instanceof \WP_Post || ! in_array( $p->post_type, Meta::post_types(), true ) ) {
			return new \WP_Error( 'wp_astro_not_found', __( 'Article not found.', 'wp-astro' ), [ 'status' => 404 ] );
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error( 'wp_astro_forbidden', __( 'You cannot check this article.', 'wp-astro' ), [ 'status' => 403 ] );
		}
		$key = (string) Settings::get( 'google_api_key' );
		if ( '' === $key ) {
			return new \WP_Error( 'wp_astro_psi_nokey', __( 'Add a Google API key under HTML → Settings → Google first.', 'wp-astro' ), [ 'status' => 400 ] );
		}
		$url = self::target_url( $p );
		if ( is_wp_error( $url ) ) {
			return $url;
		}

		// Do not score an error page: make sure the address really answers before asking Google.
		$probe = wp_remote_get(
			$url,
			[
				'timeout'     => 15,
				'redirection' => 5,
			]
		);
		if ( ! is_wp_error( $probe ) && (int) wp_remote_retrieve_response_code( $probe ) >= 400 ) {
			return new \WP_Error(
				'wp_astro_psi_missing',
				sprintf(
					/* translators: 1: tested address, 2: HTTP status */
					__( '%1$s answers with HTTP %2$d — that page does not exist, so any score would be for an error page. Check that the article is published and its address opens.', 'wp-astro' ),
					$url,
					(int) wp_remote_retrieve_response_code( $probe )
				),
				[ 'status' => 400 ]
			);
		}

		@set_time_limit( 180 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- each call takes 5–20 s
		$result = [
			'url'     => $url,
			'checked' => time(),
		];
		foreach ( [ 'mobile', 'desktop' ] as $strategy ) {
			$r = self::check( $url, $strategy, $key );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$result[ $strategy ] = $r;
		}
		update_post_meta( $post_id, self::META, $result );
		return self::get( $post_id );
	}

	/**
	 * "Test connection": one small mobile run against a public page with the given key
	 * (or the saved one). Always returns a result the screen can show — never throws.
	 *
	 * @return array{ok:bool,message:string,score?:int,seconds?:float}
	 */
	public static function test( string $typed_key = '' ): array {
		$key = '' !== trim( $typed_key ) ? trim( $typed_key ) : (string) Settings::get( 'google_api_key' );
		if ( '' === $key ) {
			return [
				'ok'      => false,
				'message' => __( 'No API key yet — paste one above first.', 'wp-astro' ),
			];
		}
		@set_time_limit( 90 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$t0 = microtime( true );
		$r  = self::check( 'https://example.com/', 'mobile', $key, 60 );
		if ( is_wp_error( $r ) ) {
			return [
				'ok'      => false,
				'message' => self::explain( $r->get_error_message() ),
			];
		}
		return [
			'ok'      => true,
			'message' => sprintf(
				/* translators: %d: PageSpeed score */
				__( 'Connected. Google answered with a PageSpeed score of %d for a test page.', 'wp-astro' ),
				$r['score']
			),
			'score'   => $r['score'],
			'seconds' => round( microtime( true ) - $t0, 1 ),
		];
	}

	/** Turn Google's error text into what to do about it. */
	private static function explain( string $msg ): string {
		$m = strtolower( $msg );
		if ( str_contains( $m, 'api key not valid' ) || str_contains( $m, 'api_key_invalid' ) ) {
			return __( 'Google says the key is not valid. Copy it again from APIs & Services → Credentials (it starts with “AIza”).', 'wp-astro' );
		}
		if ( str_contains( $m, 'has not been used' ) || str_contains( $m, 'is disabled' ) || str_contains( $m, 'service_disabled' ) ) {
			return __( 'The PageSpeed Insights API is not enabled in this key’s Google Cloud project. Open APIs & Services → Library → PageSpeed Insights API → Enable, wait a minute, and test again.', 'wp-astro' );
		}
		if ( str_contains( $m, 'referer' ) || str_contains( $m, 'ip address' ) || str_contains( $m, 'ip_address' ) ) {
			return __( 'The key has an application restriction that blocks this server. In the key’s settings set “Application restrictions” to None (or allow this server’s IP).', 'wp-astro' );
		}
		if ( str_contains( $m, 'blocked' ) || str_contains( $m, 'not authorized' ) || str_contains( $m, 'permission' ) ) {
			return __( 'The key is restricted to other APIs. Edit the key → API restrictions → add “PageSpeed Insights API”.', 'wp-astro' );
		}
		if ( str_contains( $m, 'quota' ) || str_contains( $m, 'rate' ) ) {
			return __( 'Google’s request limit was reached. Wait a few minutes (or until tomorrow for the daily limit) and try again.', 'wp-astro' );
		}
		return sprintf( /* translators: %s: Google's message */ __( 'Google answered: %s', 'wp-astro' ), $msg );
	}

	/** @return array{score:int,lcp:string,tbt:string,cls:string,fcp:string,si:string}|\WP_Error */
	private static function check( string $url, string $strategy, string $key, int $timeout = 70 ) {
		$res = wp_remote_get(
			add_query_arg(
				[
					'url'      => $url,
					'strategy' => $strategy,
					'category' => 'performance',
					'key'      => $key,
				],
				self::ENDPOINT
			),
			[
				'timeout'     => $timeout,
				'redirection' => 3,
			]
		);
		if ( is_wp_error( $res ) ) {
			return new \WP_Error( 'wp_astro_psi_http', $res->get_error_message(), [ 'status' => 502 ] );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( 200 !== $code ) {
			$msg = is_array( $data ) && isset( $data['error']['message'] ) ? (string) $data['error']['message'] : "HTTP $code";
			return new \WP_Error( 'wp_astro_psi_api', $msg, [ 'status' => 502 ] );
		}
		$score = $data['lighthouseResult']['categories']['performance']['score'] ?? null;
		if ( null === $score ) {
			return new \WP_Error( 'wp_astro_psi_parse', __( 'Google returned no performance score.', 'wp-astro' ), [ 'status' => 502 ] );
		}
		$audits = $data['lighthouseResult']['audits'] ?? [];
		if ( isset( $audits['http-status-code']['score'] ) && 0 === (int) $audits['http-status-code']['score'] ) {
			return new \WP_Error(
				'wp_astro_psi_errorpage',
				sprintf( /* translators: %s: HTTP status */ __( 'Google received an error page (HTTP %s) for this address, so the score was discarded.', 'wp-astro' ), (string) ( $audits['http-status-code']['displayValue'] ?? '?' ) ),
				[ 'status' => 400 ]
			);
		}
		$val    = static fn( string $k ): string => (string) ( $audits[ $k ]['displayValue'] ?? '—' );

		return [
			'score' => (int) round( (float) $score * 100 ),
			'lcp'   => $val( 'largest-contentful-paint' ),
			'tbt'   => $val( 'total-blocking-time' ),
			'cls'   => $val( 'cumulative-layout-shift' ),
			'fcp'   => $val( 'first-contentful-paint' ),
			'si'    => $val( 'speed-index' ),
		];
	}
}
