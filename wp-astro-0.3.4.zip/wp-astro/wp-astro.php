<?php
/**
 * Plugin Name: WP-Astro
 * Description: Hand off posts (and one "Blog front" list page) to a static Astro build; rebuild on change; serve the built pages from disk or a remote host (Netlify) in place of WordPress rendering.
 * Version:     0.3.4
 * Author:      webim
 * License:     GPL-2.0-or-later
 * Requires PHP: 8.1
 * Requires at least: 6.4
 * Text Domain: wp-astro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WP_ASTRO_VERSION', '0.3.4' );
define( 'WP_ASTRO_FILE', __FILE__ );
define( 'WP_ASTRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'WP_ASTRO_URL', plugin_dir_url( __FILE__ ) );

require_once WP_ASTRO_DIR . 'includes/class-settings.php';
require_once WP_ASTRO_DIR . 'includes/class-content.php';
require_once WP_ASTRO_DIR . 'includes/class-style.php';
require_once WP_ASTRO_DIR . 'includes/class-docs.php';
require_once WP_ASTRO_DIR . 'includes/class-netlify.php';
require_once WP_ASTRO_DIR . 'includes/class-updater.php';
require_once WP_ASTRO_DIR . 'includes/class-psi.php';
require_once WP_ASTRO_DIR . 'includes/class-quality.php';
require_once WP_ASTRO_DIR . 'includes/class-faq.php';
require_once WP_ASTRO_DIR . 'includes/class-articles.php';
require_once WP_ASTRO_DIR . 'includes/class-admin-api.php';
require_once WP_ASTRO_DIR . 'includes/class-meta.php';
require_once WP_ASTRO_DIR . 'includes/class-admin-list.php';
require_once WP_ASTRO_DIR . 'includes/class-rest.php';
require_once WP_ASTRO_DIR . 'includes/class-trigger.php';
require_once WP_ASTRO_DIR . 'includes/class-serve.php';

add_action( 'plugins_loaded', function () {
	Wp_Astro\Settings::init();
	Wp_Astro\Content::init();
	Wp_Astro\Style::init();
	Wp_Astro\Faq::init();
	Wp_Astro\Admin_Api::init();
	Wp_Astro\Updater::init();
	Wp_Astro\Meta::init();
	Wp_Astro\Admin_List::init();
	Wp_Astro\Rest::init();
	Wp_Astro\Trigger::init();
	Wp_Astro\Serve::init();
} );