<?php
/**
 * Meta — the per-post "Render Engine: WordPress | Astro" toggle and, for Astro
 * posts, the "Astro Template: Article with sidebar | Article list | Article
 * full-width" choice.
 *
 *   _wp_astro_engine  wordpress (default) | astro
 *   _wp_astro_role    article (default) | front | full_width
 *                     — "front" is the ONE post/page whose URL becomes the
 *                     article list; "full_width" is an Article rendered
 *                     without the sidebar.
 *
 * Both are REST-exposed; the editor gets a meta box; the posts list gets a column
 * and bulk actions (see Admin_List).
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Meta {

	public const KEY       = '_wp_astro_engine';
	public const WORDPRESS = 'wordpress';
	public const ASTRO     = 'astro';

	public const DESC_KEY        = '_wp_astro_description';
	public const ROLE_KEY        = '_wp_astro_role';
	public const ROLE_ARTICLE    = 'article';
	public const ROLE_FRONT      = 'front';
	public const ROLE_FULL_WIDTH = 'full_width';

	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'add_meta_boxes', [ __CLASS__, 'add_box' ] );
		add_action( 'save_post', [ __CLASS__, 'save' ], 10, 2 );
	}

	/** Post types that get the toggle. Filterable; the settings page hooks this. */
	public static function post_types(): array {
		return (array) apply_filters( 'wp_astro_post_types', [ 'post' ] );
	}

	public static function register(): void {
		$auth = static function ( $allowed, $meta_key, $post_id ) {
			return current_user_can( 'edit_post', $post_id );
		};
		foreach ( self::post_types() as $type ) {
			register_post_meta(
				$type,
				self::KEY,
				[
					'type'              => 'string',
					'single'            => true,
					'default'           => self::WORDPRESS,
					'show_in_rest'      => true,
					'sanitize_callback' => [ __CLASS__, 'sanitize' ],
					'auth_callback'     => $auth,
				]
			);
			register_post_meta(
				$type,
				self::ROLE_KEY,
				[
					'type'              => 'string',
					'single'            => true,
					'default'           => self::ROLE_ARTICLE,
					'show_in_rest'      => true,
					'sanitize_callback' => [ __CLASS__, 'sanitize_role' ],
					'auth_callback'     => $auth,
				]
			);
			register_post_meta(
				$type,
				self::DESC_KEY,
				[
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => 'sanitize_text_field',
					'auth_callback'     => $auth,
				]
			);
		}
	}

	public static function sanitize( $value ): string {
		return self::ASTRO === $value ? self::ASTRO : self::WORDPRESS;
	}

	public static function sanitize_role( $value ): string {
		if ( self::ROLE_FRONT === $value ) {
			return self::ROLE_FRONT;
		}
		if ( self::ROLE_FULL_WIDTH === $value ) {
			return self::ROLE_FULL_WIDTH;
		}
		return self::ROLE_ARTICLE;
	}

	/** Effective engine for a post ('' / unset -> wordpress). */
	public static function get( int $post_id ): string {
		return self::ASTRO === get_post_meta( $post_id, self::KEY, true ) ? self::ASTRO : self::WORDPRESS;
	}

	/** Effective role for a post ('' / unset -> article). Only meaningful when engine = astro. */
	public static function get_role( int $post_id ): string {
		return self::sanitize_role( get_post_meta( $post_id, self::ROLE_KEY, true ) );
	}

	public static function is_front( int $post_id ): bool {
		return self::ASTRO === self::get( $post_id ) && self::ROLE_FRONT === self::get_role( $post_id );
	}

	/** Set engine (+ optional role) on a post from code (bulk actions, WP-CLI). */
	public static function set( int $post_id, string $engine, ?string $role = null ): void {
		update_post_meta( $post_id, self::KEY, self::sanitize( $engine ) );
		if ( null !== $role ) {
			$role = self::sanitize_role( $role );
			if ( self::ROLE_FRONT === $role ) {
				self::demote_other_fronts( $post_id );
			}
			update_post_meta( $post_id, self::ROLE_KEY, $role );
		}
	}

	/**
	 * The published post/page that is the article list ("Blog front"), or null.
	 * Cached per request; any of the configured post types qualifies.
	 */
	public static function front_post(): ?\WP_Post {
		static $cached = false;
		if ( false !== $cached ) {
			return $cached;
		}
		$found  = get_posts(
			[
				'post_type'        => self::post_types(),
				'post_status'      => 'publish',
				'numberposts'      => 1,
				'meta_query'       => [ // phpcs:ignore WordPress.DB.SlowDBQuery
					[ 'key' => self::KEY, 'value' => self::ASTRO ],
					[ 'key' => self::ROLE_KEY, 'value' => self::ROLE_FRONT ],
				],
				'suppress_filters' => false,
			]
		);
		$cached = $found ? $found[0] : null;
		return $cached;
	}

	/** Only one Blog front per site: everything else flagged "front" goes back to "article". */
	public static function demote_other_fronts( int $keep_id ): void {
		$others = get_posts(
			[
				'post_type'        => self::post_types(),
				'post_status'      => 'any',
				'numberposts'      => -1,
				'exclude'          => [ $keep_id ],
				'meta_key'         => self::ROLE_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => self::ROLE_FRONT, // phpcs:ignore WordPress.DB.SlowDBQuery
				'fields'           => 'ids',
				'suppress_filters' => false,
			]
		);
		foreach ( $others as $id ) {
			update_post_meta( $id, self::ROLE_KEY, self::ROLE_ARTICLE );
		}
	}

	public static function add_box(): void {
		add_meta_box(
			'wp-astro-engine',
			__( 'Render Engine', 'wp-astro' ),
			[ __CLASS__, 'render_box' ],
			self::post_types(),
			'side',
			'high'
		);
	}

	public static function render_box( \WP_Post $post ): void {
		$engine = self::get( $post->ID );
		$role   = self::get_role( $post->ID );
		wp_nonce_field( 'wp_astro_engine', 'wp_astro_engine_nonce' );
		?>
		<p style="margin:.2em 0 .6em;"><?php esc_html_e( 'How is this post rendered on the front end?', 'wp-astro' ); ?></p>
		<label style="display:block;margin:.35em 0;">
			<input type="radio" name="wp_astro_engine" value="wordpress" <?php checked( $engine, self::WORDPRESS ); ?> />
			<?php esc_html_e( 'WordPress (default)', 'wp-astro' ); ?>
		</label>
		<label style="display:block;margin:.35em 0;">
			<input type="radio" name="wp_astro_engine" value="astro" <?php checked( $engine, self::ASTRO ); ?> />
			<?php esc_html_e( 'HTML (static build)', 'wp-astro' ); ?>
		</label>

		<fieldset id="wp-astro-role" style="margin:.8em 0 0;padding:.6em .8em;border:1px solid #dcdcde;border-radius:4px;" <?php disabled( $engine, self::WORDPRESS ); ?>>
			<legend style="font-weight:600;"><?php esc_html_e( 'HTML Template', 'wp-astro' ); ?></legend>
			<?php if ( self::ROLE_FRONT === $role ) : ?>
				<p style="margin:.35em 0;">
					<?php esc_html_e( 'This page is the article list.', 'wp-astro' ); ?>
					<a href="<?php echo esc_url( Settings::page_url( [ 'tab' => 'general' ] ) ); ?>"><?php esc_html_e( 'Change it in HTML → Settings.', 'wp-astro' ); ?></a>
				</p>
			<?php else : ?>
				<label style="display:block;margin:.35em 0;">
					<input type="radio" name="wp_astro_role" value="article" <?php checked( $role, self::ROLE_ARTICLE ); ?> />
					<?php esc_html_e( 'With sidebar', 'wp-astro' ); ?>
				</label>
				<label style="display:block;margin:.35em 0;">
					<input type="radio" name="wp_astro_role" value="full_width" <?php checked( $role, self::ROLE_FULL_WIDTH ); ?> />
					<?php esc_html_e( 'Full width', 'wp-astro' ); ?>
				</label>
			<?php endif; ?>
		</fieldset>

		<?php
		$faq = Faq::effective( $post );
		$url = add_query_arg( [ 'page' => Settings::ARTICLES_PAGE, 'faq' => $post->ID ], admin_url( 'admin.php' ) );
		?>
		<p style="margin:.9em 0 .2em;"><strong><?php esc_html_e( 'FAQ', 'wp-astro' ); ?></strong>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: number of questions, 2: on/off */
					_n( '%1$d question · %2$s', '%1$d questions · %2$s', count( $faq['items'] ), 'wp-astro' ),
					count( $faq['items'] ),
					$faq['enabled'] ? __( 'on', 'wp-astro' ) : __( 'off', 'wp-astro' )
				)
			);
			?>
			· <a href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Edit FAQ', 'wp-astro' ); ?></a></p>

		<p style="margin:.9em 0 .2em;"><label for="wp-astro-description" style="font-weight:600;"><?php esc_html_e( 'SEO description (optional)', 'wp-astro' ); ?></label></p>
		<textarea id="wp-astro-description" name="wp_astro_description" rows="4" style="width:100%;" maxlength="300"><?php echo esc_textarea( (string) get_post_meta( $post->ID, self::DESC_KEY, true ) ); ?></textarea>
		<p class="description" style="margin:.3em 0 0;">
			<?php esc_html_e( 'Leave blank to use the default. Plain text, or with variables:', 'wp-astro' ); ?>
			<code style="word-break:break-word;"><?php echo esc_html( Content::variables_hint() ); ?></code>
		</p>
		<script>
		(function () {
			var radios = document.querySelectorAll('input[name="wp_astro_engine"]');
			var fs = document.getElementById('wp-astro-role');
			radios.forEach(function (r) {
				r.addEventListener('change', function () { fs.disabled = (this.value !== 'astro'); });
			});
		})();
		</script>
		<?php
	}

	public static function save( int $post_id, \WP_Post $post ): void {
		if ( ! in_array( $post->post_type, self::post_types(), true ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if (
			! isset( $_POST['wp_astro_engine_nonce'] )
			|| ! wp_verify_nonce( sanitize_key( $_POST['wp_astro_engine_nonce'] ), 'wp_astro_engine' )
		) {
			return; // not our form submission (e.g. a REST/block-editor save) — leave the values alone
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$engine = isset( $_POST['wp_astro_engine'] )
			? self::sanitize( sanitize_key( wp_unslash( $_POST['wp_astro_engine'] ) ) )
			: self::WORDPRESS;
		// A disabled fieldset is not submitted: keep the stored role in that case.
		$role = isset( $_POST['wp_astro_role'] )
			? self::sanitize_role( sanitize_key( wp_unslash( $_POST['wp_astro_role'] ) ) )
			: null;

		self::set( $post_id, $engine, $role );

		if ( isset( $_POST['wp_astro_description'] ) ) {
			$desc = sanitize_text_field( wp_unslash( $_POST['wp_astro_description'] ) );
			if ( '' === $desc ) {
				delete_post_meta( $post_id, self::DESC_KEY );
			} else {
				update_post_meta( $post_id, self::DESC_KEY, $desc );
			}
		}
	}
}
