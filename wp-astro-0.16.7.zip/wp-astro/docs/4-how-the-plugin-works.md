# How the plugin works

W-Blog lets an editor choose which WordPress posts are delivered as fast, pre-built pages. WordPress stays the place where everything is edited and stored; the build only reads it.

## The idea in four steps

1. An editor flags a post: **Render Engine → HTML**.
2. The plugin publishes the list of flagged posts and all the site settings through its REST API.
3. A build (Astro) reads that, writes static HTML, and hosts it (Netlify, or a folder on the server).
4. When a visitor opens a flagged post, the plugin prints the built page instead of rendering the theme. If anything is missing, the normal WordPress page is shown.

## What lives where

| Data | Lives in |
| --- | --- |
| Articles, categories, authors, every per-article field | The WordPress database (post meta starting with `_wp_astro_`) |
| Site-wide settings (General, Deploy, Content, Styles) | WordPress options |
| Original images | The WordPress media library |
| Built HTML, optimised images, CSS | Netlify, or the build folder (disposable: it can always be rebuilt) |
| A client's design defaults (logo, colours, fonts, address, phone) | The client's folder in the repository |

## The public endpoints

| Address | What it gives the build |
| --- | --- |
| `/wp-json/wp-astro/v1/manifest` | Which posts are flagged, their address and template |
| `/wp-json/wp-astro/v1/config` | The Content and Styles settings, shaped like the design defaults |
| `/wp-json/wp-astro/v1/menus` | The menus |
| `/wp-json/wp-astro/v1/purge` and `build-status` | Called by the build when it finishes; they need the secret token in the URL |

The Vue admin screens use private routes under `/wp-json/wp-astro/v1/admin/`. They need a logged-in administrator and the admin nonce, and every save is cleaned again on the server.

## Showing a page to a visitor

On each front page request the plugin checks whether the post is flagged. If so it takes the built page in one of two ways.

| Mode | Where the page comes from |
| --- | --- |
| Netlify (remote) | Fetched from the Netlify address and kept in a cache (one day by default) |
| Self-hosted (disk) | Read from a folder on the server |

If the page cannot be found, the plugin first tries the last built copy of the old address, and then lets WordPress render normally. In Netlify mode the page's images, CSS and fonts (`/_astro/…`) are printed with your WordPress address and served from there: the plugin copies each file from Netlify once into the site's own `/_astro/` folder (or `wp-content/uploads/wp-astro-assets/` when that is not writable), so the web server hands it out without starting PHP, and sends it with a one-year cache header. The browser then needs only one connection, which makes the first image and the fonts arrive sooner. The files have hashed names, so they never go stale. A developer can switch this off with the `wp_astro_local_assets` filter.

## How a page gets its look: three layers

1. **Neutral defaults** in the front end's `tokens.css`.
2. **The client's skin** in its folder (`theme.json`): colours, fonts, sizes, radius.
3. **The Styles tab**: one CSS field listing every variable. Only the lines the editor changes are saved, and the plugin shows the client's own values as the defaults.

Structure and alignment never change with a skin; only values do.

## Rebuilds

Saving queues a change. The plugin starts a build according to **Changes go live** (10 minutes after the last edit, on click, or after a minute) and the **Rebuild trigger** (webhook, GitHub Actions, or both). See "How deploy works".

## Safety

- Every admin route checks that the user may manage options; public routes only return what the build needs.
- Secrets (the GitHub token, the Netlify token, the purge token) are never sent to the browser. They can also be fixed in `wp-config.php` as constants.
- Values saved from the admin are cleaned for their type; in the Styles tab, anything that could break the page (`;`, braces, `url()`, `@import`) is rejected.
- Empty values are never printed, so an empty field leaves no empty element or stray punctuation on the page.

## The classes

| Class | Job |
| --- | --- |
| `Meta` | The Render Engine box and the per-post template |
| `Rest` | The public routes |
| `Admin_Api` | The private routes and the screen mounts |
| `Article_Edit` | Reading and saving everything on the edit screen |
| `Content`, `Style` | The Content and Styles tabs: fields, cleaning, and what the build receives |
| `Settings` | General and Deploy options |
| `Trigger` | Pending changes, the publish rules, sending the rebuild |
| `Serve` | Printing built pages: remote or disk, cache, fallbacks |
| `Preview`, `Quality`, `Faq`, `Psi`, `Authors` | Live page status, the content score, FAQ storage, PageSpeed checks, author profiles |
| `Updater` | Updates from the releases repository |
| `Image_Import` | One-off helpers for moving articles from another site: images and SEO text |

## The version

The plugin's version is set in two places in `plugin/wp-astro.php` (the `Version:` header and `WP_ASTRO_VERSION`) and must match the release tag. This installation runs {{version}}. Updates come from the public releases repository; the **Release history** page lists what changed in each one.
