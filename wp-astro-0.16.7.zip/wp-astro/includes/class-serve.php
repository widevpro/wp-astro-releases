<?php
/**
 * Serve — on the front end, hand an Astro-flagged post its pre-built page
 * instead of letting WordPress/the theme render it.
 *
 *   disk    read {output_path}/{path}/index.html from this server (build rsynced here)
 *   remote  fetch {remote_origin}{path} (e.g. the Netlify site), cache it in a
 *           transient for remote_ttl seconds, stream it. WordPress keeps the domain.
 *
 * Falls straight through to normal WordPress if serving is disabled, the post isn't
 * flagged, the file/URL is missing, or the request isn't a plain GET of the post URL.
 * The "Blog front" post additionally serves its paginated URLs {path}page/N/.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Serve {

	private const T_PREFIX = 'wp_astro_page_';
	private const MISS_TTL = 120; // how long to remember "remote has no such page"

	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'maybe_serve_asset' ], 1 );
		add_action( 'template_redirect', [ __CLASS__, 'maybe_serve' ], 1 );
		add_action( 'admin_post_wp_astro_purge', [ __CLASS__, 'handle_manual_purge' ] );
		add_action( 'update_option_' . Settings::OPTION, [ __CLASS__, 'purge_all' ] );
	}

	/* ---------------------------------------------------------------- serving */

	/** File types the asset route may hand out (anything else is left to WordPress). */
	private const ASSET_TYPES = [
		'avif'  => 'image/avif',
		'webp'  => 'image/webp',
		'jpg'   => 'image/jpeg',
		'jpeg'  => 'image/jpeg',
		'png'   => 'image/png',
		'gif'   => 'image/gif',
		'svg'   => 'image/svg+xml',
		'css'   => 'text/css; charset=utf-8',
		'js'    => 'text/javascript; charset=utf-8',
		'woff2' => 'font/woff2',
		'woff'  => 'font/woff',
		'ico'   => 'image/x-icon',
	];

	/**
	 * The built pages point at /_astro/… (images, CSS, fonts) and /icons/… on the same domain.
	 *   disk    serve those files from the build folder when the web server does not (e.g. the build folder is
	 *           not the web root).
	 *   remote  the hosted build keeps the files on its own address; the page printed here points them at
	 *           this domain (see localise_assets) and this route copies each one over once, then serves it from
	 *           a local cache — one connection instead of two, so the first image and font arrive sooner.
	 */
	public static function maybe_serve_asset(): void {
		if ( ! Settings::get( 'serve_enabled' ) || ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', [ 'GET', 'HEAD' ], true ) ) {
			return;
		}
		$mode = (string) Settings::get( 'serve_mode' );
		$uri  = (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
		if ( isset( $_GET['dynamic_asset'] ) && is_string( $_GET['dynamic_asset'] ) ) {
			$uri = (string) wp_unslash( $_GET['dynamic_asset'] ); // some hosts send a missing static file to /index.php?dynamic_asset=/path
		}
		if ( 'remote' === $mode ? ! preg_match( '#^/_astro/[A-Za-z0-9._~\-]+(?:/[A-Za-z0-9._~\-]+)*$#', $uri ) : ! preg_match( '#^/(?:_astro|icons|fonts)/[^?]+$#', $uri ) ) {
			return;
		}
		$ext = strtolower( pathinfo( $uri, PATHINFO_EXTENSION ) );
		if ( ! isset( self::ASSET_TYPES[ $ext ] ) || str_contains( $uri, '..' ) ) {
			return;
		}
		$file = 'remote' === $mode ? self::cached_asset( $uri ) : self::build_file( $uri );
		if ( null === $file ) {
			return; // not in the build: WordPress answers as usual
		}
		status_header( 200 );
		header( 'Content-Type: ' . self::ASSET_TYPES[ $ext ] );
		header( 'Content-Length: ' . (string) filesize( $file ) );
		header( 'Cache-Control: public, max-age=31536000, immutable' ); // hashed file names: safe to keep forever
		header( 'X-WP-Astro-Asset: ' . $mode );
		if ( 'HEAD' !== $_SERVER['REQUEST_METHOD'] ) {
			readfile( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		exit;
	}

	private static function build_file( string $uri ): ?string {
		$configured = (string) Settings::get( 'output_path' );
		$root       = '' === $configured ? false : realpath( $configured );
		$file       = false === $root ? false : realpath( $root . rawurldecode( $uri ) );
		if ( false === $file || ! str_starts_with( $file, $root . DIRECTORY_SEPARATOR ) || ! is_file( $file ) ) {
			return null;
		}
		return $file;
	}

	/**
	 * Local copy of one hosted asset; fetched from the hosted build the first time it is asked for.
	 * Kept in the site's own /_astro/ folder when WordPress lives at the domain root and the folder is writable, so the
	 * web server (and the CDN in front of it) hands the file out without starting PHP; otherwise under uploads/.
	 */
	private static function cached_asset( string $uri ): ?string {
		$origin = rtrim( (string) Settings::get( 'remote_origin' ), '/' );
		if ( '' === $origin ) {
			return null;
		}
		$dirs = [];
		if ( '' === rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' ) ) {
			$dirs[] = untrailingslashit( ABSPATH ); // $uri already starts with /_astro/
		}
		$dirs[] = trailingslashit( wp_upload_dir( null, false )['basedir'] ) . 'wp-astro-assets';
		foreach ( $dirs as $dir ) {
			if ( is_file( $dir . $uri ) ) {
				return $dir . $uri;
			}
		}
		$res = wp_remote_get( $origin . $uri, [ 'timeout' => 15, 'redirection' => 2 ] );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return null;
		}
		$body = (string) wp_remote_retrieve_body( $res );
		if ( '' === $body || strlen( $body ) > 8 * MB_IN_BYTES ) {
			return null;
		}
		foreach ( $dirs as $dir ) {
			$file = $dir . $uri; // $uri is limited to safe characters, no ".."
			if ( ! wp_mkdir_p( dirname( $file ) ) ) {
				continue;
			}
			$tmp = $file . '.' . wp_generate_password( 6, false ) . '.tmp';
			if ( false !== @file_put_contents( $tmp, $body ) && @rename( $tmp, $file ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
				return $file;
			}
			wp_delete_file( $tmp );
		}
		return null;
	}

	/**
	 * Hosted build: point the page's own files (`https://<origin>/_astro/…`) at this domain, so the browser reuses
	 * the connection it already has instead of opening a second one. Turn off with the `wp_astro_local_assets` filter.
	 */
	public static function localise_assets( string $html ): string {
		$origin = rtrim( (string) Settings::get( 'remote_origin' ), '/' );
		if ( '' === $origin || ! apply_filters( 'wp_astro_local_assets', true ) ) {
			return $html;
		}
		return str_replace( $origin . '/_astro/', untrailingslashit( home_url() ) . '/_astro/', $html );
	}

	public static function maybe_serve(): void {
		if ( is_admin() || is_preview() || is_embed() || is_feed() || is_404() || is_trackback() || is_robots() ) {
			return;
		}
		if ( ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', [ 'GET', 'HEAD' ], true ) ) {
			return;
		}
		if ( ! Settings::get( 'serve_enabled' ) ) {
			return;
		}
		if ( ! is_singular( Meta::post_types() ) ) {
			return;
		}

		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) {
			return;
		}
		if ( Meta::ASTRO !== Meta::get( $post->ID ) ) {
			return;
		}

		$path = self::request_path();
		if ( null === $path || ! self::path_belongs_to( $path, $post ) ) {
			return; // /slug/feed/, /slug/2/, odd URLs: let WordPress decide
		}

		$mode = (string) Settings::get( 'serve_mode' );
		$html = 'remote' === $mode ? self::from_remote( $path, $source ) : self::from_disk( $path, $source );
		if ( null === $html ) {
			// Renamed and not rebuilt yet: show the last built copy from the old address (right design,
			// a little out of date) instead of falling back to the theme.
			$html = self::from_previous_address( $post, $path, $mode, $source );
		}
		if ( null === $html ) {
			return; // nothing built (yet) for this URL — WordPress renders it
		}

		if ( 'remote' === $mode ) {
			$html = self::localise_assets( self::clean_origin_html( $html ) ); // also for copies cached by an older version
		}

		header_remove( 'X-Pingback' );
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
		header( 'X-WP-Astro: ' . $source );
		header( 'Cache-Control: public, max-age=60' );
		header( 'ec-cdn-cache-control: public, max-age=60, s-maxage=300' ); // hosts with an edge cache (Elementor Cloud): keep copies short so edits show within minutes
		header( 'Vary: Accept-Encoding' );

		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- complete pre-built document
		exit;
	}

	/** Request path relative to the WP home, normalised to /a/b/ form. Null if unsafe. */
	public static function request_path(): ?string {
		$uri  = (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
		$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( '' !== $home && str_starts_with( $uri, $home ) ) {
			$uri = substr( $uri, strlen( $home ) );
		}
		$uri = '/' . trim( rawurldecode( $uri ), '/' );
		$uri = '/' === $uri ? '/' : $uri . '/';
		if ( str_contains( $uri, '..' ) || ! preg_match( '#^[A-Za-z0-9._~%/\-]*$#', $uri ) ) {
			return null;
		}
		return $uri;
	}

	/**
	 * The exact post URL, plus {url}page/N/ for the Blog front's pagination.
	 * No custom rewrite rule is needed for that second form: every WordPress
	 * permalink structure already adds a `page/(\d+)/` "old-style pagination"
	 * endpoint (the one `<!--nextpage-->` uses) to every singular post/page,
	 * so `/blog/page/2/` already resolves to the front post with is_singular()
	 * true — we only need to recognise the URL shape below.
	 */
	private static function path_belongs_to( string $path, \WP_Post $post ): bool {
		$own = wp_make_link_relative( get_permalink( $post ) );
		$own = '/' . trim( (string) wp_parse_url( $own, PHP_URL_PATH ), '/' );
		$own = '/' === $own ? '/' : $own . '/';
		if ( $path === $own ) {
			return true;
		}
		return Meta::is_front( $post->ID ) && (bool) preg_match( '#^' . preg_quote( $own, '#' ) . 'page/[1-9][0-9]*/$#', $path );
	}

	/**
	 * The page as the build currently has it — straight from the build folder or the hosted origin,
	 * never from the page cache. Used to tell whether an edit has gone live. Null = not there.
	 */
	public static function fresh_html( \WP_Post $post ): ?string {
		$path = '/' . trim( (string) wp_parse_url( wp_make_link_relative( (string) get_permalink( $post ) ), PHP_URL_PATH ), '/' ) . '/';
		$path = '//' === $path ? '/' : $path;
		if ( 'remote' !== (string) Settings::get( 'serve_mode' ) ) {
			$src = null;
			return self::from_disk( $path, $src, false );
		}
		return self::fetch_origin( $path, '?wa_fresh=' . time() );
	}

	/** Built copy of this post under an address it used to have (WordPress remembers old slugs). */
	private static function from_previous_address( \WP_Post $post, string $path, string $mode, ?string &$source ): ?string {
		$olds = array_unique( array_filter( array_map( 'strval', (array) get_post_meta( $post->ID, '_wp_old_slug' ) ) ) );
		if ( ! $olds ) {
			return null;
		}
		$key    = self::T_PREFIX . 'prev_' . md5( $path );
		$cached = get_transient( $key );
		if ( is_string( $cached ) ) {
			$source = 'previous-address';
			return '' === $cached ? null : $cached;
		}
		foreach ( array_slice( $olds, -3 ) as $old ) {
			$old_path = (string) preg_replace( '#[^/]+/$#', $old . '/', $path );
			if ( $old_path === $path ) {
				continue;
			}
			$src  = null;
			$html = 'remote' === $mode ? self::fetch_origin( $old_path ) : self::from_disk( $old_path, $src, false );
			if ( null !== $html && '' !== $html ) {
				set_transient( $key, $html, MINUTE_IN_SECONDS ); // short: the real page replaces it after the next build
				$source = 'previous-address';
				return $html;
			}
		}
		set_transient( $key, '', MINUTE_IN_SECONDS );
		return null;
	}

	/** GET a page from the hosted build, no caching. */
	private static function fetch_origin( string $path, string $query = '' ): ?string {
		$origin = rtrim( (string) Settings::get( 'remote_origin' ), '/' );
		if ( '' === $origin ) {
			return null;
		}
		$res = wp_remote_get(
			$origin . $path . $query,
			[
				'timeout'     => 10,
				'redirection' => 2,
				'headers'     => [
					'Accept'        => 'text/html',
					'Cache-Control' => 'no-cache',
					'User-Agent'    => 'wp-astro/' . WP_ASTRO_VERSION . ' (+' . home_url( '/' ) . ')',
				],
			]
		);
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return null;
		}
		return self::clean_origin_html( (string) wp_remote_retrieve_body( $res ) );
	}

	/**
	 * Netlify adds its own helper script (`<script src="/.netlify/scripts/hud…">`) to every page. On Netlify's own
	 * address it works; on the WordPress address the path does not exist, so it costs a slow 404 request and a red
	 * error in the browser console. It is only a toolbar for Netlify's own users: leave it out of the printed page.
	 */
	public static function clean_origin_html( string $html ): string {
		$clean = preg_replace( '#<script\b[^>]*\bsrc=(["\'])/\.netlify/[^"\']*\1[^>]*>\s*</script>#i', '', $html );
		return is_string( $clean ) ? $clean : $html;
	}

	private static function from_disk( string $path, ?string &$source, bool $headers = true ): ?string {
		$configured = (string) Settings::get( 'output_path' );
		if ( '' === $configured ) {
			return null;
		}
		$root = realpath( $configured );
		if ( false === $root ) {
			return null;
		}
		$real = realpath( $root . $path . 'index.html' );
		if ( false === $real || ! str_starts_with( $real, $root . DIRECTORY_SEPARATOR ) ) {
			return null; // missing, or resolved outside the output directory
		}
		$source = 'disk';
		if ( $headers ) {
			header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', (int) filemtime( $real ) ) . ' GMT' );
		}
		$html = file_get_contents( $real ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return false === $html ? null : $html;
	}

	private static function from_remote( string $path, ?string &$source ): ?string {
		$origin = rtrim( (string) Settings::get( 'remote_origin' ), '/' );
		if ( '' === $origin ) {
			return null;
		}
		$key    = self::T_PREFIX . md5( $path );
		$cached = get_transient( $key );
		if ( is_string( $cached ) ) {
			if ( '' === $cached ) {
				return null; // remembered miss
			}
			$source = 'remote-cache';
			return $cached;
		}

		$res = wp_remote_get(
			$origin . $path,
			[
				'timeout'     => 10,
				'redirection' => 2,
				'headers'     => [
					'Accept'           => 'text/html',
					'User-Agent'       => 'wp-astro/' . WP_ASTRO_VERSION . ' (+' . home_url( '/' ) . ')',
					'X-WP-Astro-Proxy' => '1',
				],
			]
		);
		if ( is_wp_error( $res ) ) {
			return null; // don't cache network errors — try again next request
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = (string) wp_remote_retrieve_body( $res );
		if ( 200 !== $code || '' === $body ) {
			set_transient( $key, '', self::MISS_TTL );
			return null;
		}
		set_transient( $key, $body, max( 60, (int) Settings::get( 'remote_ttl' ) ) );
		$source = 'remote';
		return $body;
	}

	/* ------------------------------------------------------------------ cache */

	/** Drop every cached remote page. Called on settings save, bulk actions, and the /purge endpoint. */
	public static function purge_all(): int {
		global $wpdb;
		$like = $wpdb->esc_like( '_transient_' . self::T_PREFIX ) . '%';
		$tout = $wpdb->esc_like( '_transient_timeout_' . self::T_PREFIX ) . '%';
		$n    = (int) $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $like, $tout )
		);
		if ( wp_using_ext_object_cache() ) {
			wp_cache_flush();
		}
		return (int) floor( $n / 2 );
	}

	public static function handle_manual_purge(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wp_astro_purge' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wp-astro' ) );
		}
		$n = self::purge_all();
		wp_safe_redirect(
			add_query_arg( 'wp_astro_purged', $n, wp_get_referer() ?: Settings::page_url( [ 'tab' => 'deploy' ] ) )
		);
		exit;
	}

}
