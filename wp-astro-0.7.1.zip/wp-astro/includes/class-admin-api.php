<?php
/**
 * Admin_Api — backend for the Vue settings screen (admin-ui/ → assets/admin/app.js).
 *
 * The page itself only prints <div id="wpa-app">; the app reads its first state from
 * window.wpAstroAdmin and saves through the routes below (admin-only, REST nonce).
 * Saving goes through the same Settings::sanitize() as the classic form, so locks,
 * constants and warnings behave identically. If the bundle is not built, or the URL has
 * ?legacy=1, Settings falls back to the PHP forms.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Admin_Api {

	/** Tabs the Vue app renders (the rest still use the PHP forms). */
	private const TABS = [ 'deploy', 'google', 'articles', 'edit' ];

	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
	}

	public static function available(): bool {
		return is_readable( WP_ASTRO_DIR . 'assets/admin/app.js' );
	}

	/** The Vue tab for the screen that is open: 'articles' or a settings tab. */
	public static function current_tab(): string {
		$screen = Settings::screen();
		return in_array( $screen, [ 'articles', 'edit' ], true ) ? $screen : Settings::current_tab();
	}

	/** Should this tab be drawn by the Vue app? */
	public static function handles( string $tab ): bool {
		return in_array( $tab, self::TABS, true ) && self::available() && ! isset( $_GET['legacy'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	public static function render_mount(): void {
		echo '<div id="wpa-app"></div>';
		echo '<noscript><p>' . esc_html__( 'This screen needs JavaScript. Add &legacy=1 to the address for the basic form.', 'wp-astro' ) . '</p></noscript>';
	}

	/** Astro → Articles (a Vue-only screen). */
	public static function render_articles(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap"><h1>' . esc_html__( 'W-Blog — Articles', 'wp-astro' ) . '</h1>';
		if ( self::available() ) {
			self::render_mount();
		} else {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'The admin app is not built. Run “npm install && npm run build” in the admin-ui folder.', 'wp-astro' ) . '</p></div>';
		}
		echo '</div>';
	}

	/** Astro → Edit article (a Vue-only screen, opened from a title in the Articles list). */
	public static function render_edit(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap wpa-edit-wrap">';
		if ( self::available() ) {
			self::render_mount();
		} else {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'The admin app is not built. Run “npm install && npm run build” in the admin-ui folder.', 'wp-astro' ) . '</p></div>';
		}
		echo '</div>';
	}

	public static function enqueue(): void {
		$tab = self::current_tab();
		if ( null === Settings::screen() || ! self::handles( $tab ) ) {
			return;
		}
		$dir = WP_ASTRO_DIR . 'assets/admin/';
		$url = WP_ASTRO_URL . 'assets/admin/';
		if ( is_readable( $dir . 'app.css' ) ) {
			wp_enqueue_style( 'wp-astro-admin', $url . 'app.css', [], (string) filemtime( $dir . 'app.css' ) );
		}
		$deps = [];
		if ( 'edit' === $tab ) {
			// The body and Sources use WordPress's own editor (Visual + HTML) and media library.
			$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			wp_enqueue_editor();
			wp_enqueue_media( $post_id ? [ 'post' => $post_id ] : [] );
			$deps = [ 'jquery', 'editor', 'media-editor' ];
		}
		wp_enqueue_script( 'wp-astro-admin', $url . 'app.js', $deps, (string) filemtime( $dir . 'app.js' ), true );
		wp_add_inline_script(
			'wp-astro-admin',
			'window.wpAstroAdmin = ' . wp_json_encode(
				[
					'restUrl' => rest_url( Rest::NS . '/admin/' ),
					'nonce'   => wp_create_nonce( 'wp_rest' ),
					'tab'     => $tab,
					'postId'  => 'edit' === $tab && isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0, // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					'state'   => 'google' === $tab ? self::google_state() : ( 'deploy' === $tab ? self::deploy_state() : (object) [] ),
				]
			) . ';',
			'before'
		);
	}

	/* ----------------------------------------------------------------- REST */

	public static function routes(): void {
		$perm = static fn(): bool => current_user_can( 'manage_options' );

		register_rest_route(
			Rest::NS,
			'/admin/deploy',
			[
				[
					'methods'             => \WP_REST_Server::READABLE,
					'permission_callback' => $perm,
					'callback'            => static fn() => new \WP_REST_Response( [ 'state' => self::deploy_state() ] ),
				],
				[
					'methods'             => \WP_REST_Server::CREATABLE,
					'permission_callback' => $perm,
					'callback'            => [ __CLASS__, 'save_deploy' ],
				],
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/google',
			[
				[
					'methods'             => \WP_REST_Server::READABLE,
					'permission_callback' => $perm,
					'callback'            => static fn() => new \WP_REST_Response( [ 'state' => self::google_state() ] ),
				],
				[
					'methods'             => \WP_REST_Server::CREATABLE,
					'permission_callback' => $perm,
					'callback'            => [ __CLASS__, 'save_google' ],
				],
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/update',
			[
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => $perm,
				'callback'            => static fn() => new \WP_REST_Response( Updater::status() ),
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/update/check',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => static fn() => new \WP_REST_Response( Updater::refresh() ),
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/update/run',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => static function () {
					$res = Updater::run();
					return is_wp_error( $res ) ? $res : new \WP_REST_Response( $res );
				},
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/netlify/connect',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => [ __CLASS__, 'connect_netlify' ],
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/google/test',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => static function ( \WP_REST_Request $r ) {
					$p = (array) $r->get_json_params();
					return new \WP_REST_Response( Psi::test( (string) ( $p['api_key'] ?? '' ) ) );
				},
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/articles',
			[
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => $perm,
				'callback'            => static fn( \WP_REST_Request $r ) => new \WP_REST_Response(
					Articles::query(
						[
							'page'     => $r->get_param( 'page' ),
							'per_page' => $r->get_param( 'per_page' ),
							'search'   => sanitize_text_field( (string) $r->get_param( 'search' ) ),
							'status'   => sanitize_key( (string) $r->get_param( 'status' ) ),
							'category' => $r->get_param( 'category' ),
							'include'  => $r->get_param( 'include' ),
							'faq'      => sanitize_key( (string) $r->get_param( 'faq' ) ),
							'score'    => sanitize_key( (string) $r->get_param( 'score' ) ),
							'stale'    => (bool) $r->get_param( 'stale' ),
							'orderby'  => sanitize_key( (string) $r->get_param( 'orderby' ) ),
							'order'    => sanitize_key( (string) $r->get_param( 'order' ) ),
						]
					)
				),
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/articles/bulk',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => static function ( \WP_REST_Request $r ) {
					$p = (array) $r->get_json_params();
					return new \WP_REST_Response(
						Articles::bulk( (array) ( $p['ids'] ?? [] ), sanitize_key( (string) ( $p['action'] ?? '' ) ), sanitize_text_field( (string) ( $p['value'] ?? '' ) ) )
					);
				},
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/articles/(?P<id>\d+)/edit',
			[
				[
					'methods'             => \WP_REST_Server::READABLE,
					'permission_callback' => $perm,
					'callback'            => [ __CLASS__, 'get_edit' ],
				],
				[
					'methods'             => \WP_REST_Server::CREATABLE,
					'permission_callback' => $perm,
					'callback'            => [ __CLASS__, 'save_edit' ],
				],
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/articles/(?P<id>\d+)/faq',
			[
				[
					'methods'             => \WP_REST_Server::READABLE,
					'permission_callback' => $perm,
					'callback'            => [ __CLASS__, 'get_faq' ],
				],
				[
					'methods'             => \WP_REST_Server::CREATABLE,
					'permission_callback' => $perm,
					'callback'            => [ __CLASS__, 'save_faq' ],
				],
			]
		);
		foreach ( [ 'preview' => 'preview_info', 'schema' => 'preview_schema' ] as $path => $method ) {
			register_rest_route(
				Rest::NS,
				'/admin/articles/(?P<id>\d+)/' . $path,
				[
					'methods'             => \WP_REST_Server::READABLE,
					'permission_callback' => $perm,
					'callback'            => [ __CLASS__, $method ],
				]
			);
		}
		register_rest_route(
			Rest::NS,
			'/admin/articles/(?P<id>\d+)/psi',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => static function ( \WP_REST_Request $r ) {
					$res = Psi::run( (int) $r['id'] );
					return is_wp_error( $res ) ? $res : new \WP_REST_Response( [ 'item' => Articles::item( get_post( (int) $r['id'] ) ) ] );
				},
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/articles/(?P<id>\d+)/trash',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => static function ( \WP_REST_Request $r ) {
					$res = Articles::trash( (int) $r['id'] );
					return is_wp_error( $res ) ? $res : new \WP_REST_Response( [ 'trashed' => true ] );
				},
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/articles/(?P<id>\d+)',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => static function ( \WP_REST_Request $r ) {
					$res = Articles::update( (int) $r['id'], (array) $r->get_json_params() );
					return is_wp_error( $res ) ? $res : new \WP_REST_Response( [ 'item' => $res ] );
				},
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/rebuild',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => [ __CLASS__, 'rebuild' ],
			]
		);
		register_rest_route(
			Rest::NS,
			'/admin/purge',
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'permission_callback' => $perm,
				'callback'            => [ __CLASS__, 'purge' ],
			]
		);
	}

	/** Everything the Deploy screen shows. Secrets are never sent, only whether one is set. */
	public static function deploy_state(): array {
		$line = Trigger::status_line();
		$last = Trigger::last_dispatch();

		$locked = [];
		foreach ( [ 'output_path', 'remote_origin', 'github_token', 'webhook_url' ] as $key ) {
			if ( Settings::is_locked( $key ) ) {
				$locked[ $key ] = (string) Settings::locked_constant( $key );
			}
		}

		return [
			'values'           => [
				'serve_mode'        => (string) Settings::get( 'serve_mode' ),
				'output_path'       => (string) Settings::get( 'output_path' ),
				'remote_origin'     => (string) Settings::get( 'remote_origin' ),
				'remote_ttl'        => (int) Settings::get( 'remote_ttl' ),
				'trigger_mode'      => (string) Settings::get( 'trigger_mode' ),
				'github_owner'      => (string) Settings::get( 'github_owner' ),
				'github_repo'       => (string) Settings::get( 'github_repo' ),
				'github_event_type' => (string) Settings::get( 'github_event_type' ),
				'webhook_url'       => (string) Settings::get( 'webhook_url' ),
				'astro_site'        => (string) Settings::get( 'astro_site' ),
			],
			'locked'           => (object) $locked,
			'netlify_site_id'  => (string) Settings::get( 'netlify_site_id' ),
			'suggested_name'   => Netlify::suggested_name(),
			'github_token_set' => '' !== (string) Settings::get( 'github_token' ),
			'purge_url'        => Settings::purge_url(),
			'build_status_url' => Settings::build_status_url(),
			'status'           => $line ? [
				'kind' => $line[0],
				'text' => $line[1],
			] : null,
			'last_dispatch'    => $last ? [
				'ago'     => human_time_diff( (int) $last['time'] ),
				'results' => $last['results'],
			] : null,
		];
	}

	public static function google_state(): array {
		return [
			'api_key_set' => '' !== (string) Settings::get( 'google_api_key' ),
			'locked'      => Settings::is_locked( 'google_api_key' ) ? Settings::locked_constant( 'google_api_key' ) : null,
		];
	}

	/**
	 * Save through the same sanitiser as the classic form. admin_init does not run for REST
	 * requests, so register the sanitiser ourselves; update_option() then cleans the input
	 * exactly like options.php does. Returns the warnings the sanitiser raised.
	 */
	private static function persist( array $in ): array {
		Settings::register();
		// add_settings_error() / get_settings_errors() live in an admin-only file.
		require_once ABSPATH . 'wp-admin/includes/template.php';
		global $wp_settings_errors;
		$wp_settings_errors = [];
		update_option( Settings::OPTION, wp_slash( $in ) );

		$warnings = array_map(
			static fn( $e ) => [
				'type'    => (string) $e['type'],
				'message' => (string) $e['message'],
			],
			get_settings_errors()
		);
		return array_values( array_filter( $warnings, static fn( $w ) => 'updated' !== $w['type'] && 'success' !== $w['type'] ) );
	}

	public static function save_deploy( \WP_REST_Request $req ): \WP_REST_Response {
		$p      = (array) $req->get_json_params();
		$values = is_array( $p['values'] ?? null ) ? $p['values'] : [];
		$allow  = [ 'serve_mode', 'output_path', 'remote_origin', 'remote_ttl', 'trigger_mode', 'github_owner', 'github_repo', 'github_event_type', 'webhook_url', 'astro_site' ];

		$in         = array_intersect_key( $values, array_flip( $allow ) );
		$in['_tab'] = 'deploy';
		if ( ! empty( $p['github_token'] ) ) {
			$in['github_token'] = (string) $p['github_token'];
		}
		if ( ! empty( $p['regen_token'] ) ) {
			$in['regen_token'] = '1';
		}

		return new \WP_REST_Response(
			[
				'warnings' => self::persist( $in ),
				'state'    => self::deploy_state(),
			]
		);
	}

	public static function save_google( \WP_REST_Request $req ): \WP_REST_Response {
		$p  = (array) $req->get_json_params();
		$in = [ '_tab' => 'google' ];
		if ( ! empty( $p['api_key'] ) ) {
			$in['google_api_key'] = (string) $p['api_key'];
		}
		if ( ! empty( $p['clear'] ) ) {
			$in['clear_google_key'] = '1';
		}
		return new \WP_REST_Response(
			[
				'warnings' => self::persist( $in ),
				'state'    => self::google_state(),
			]
		);
	}

	/**
	 * "Connect Netlify": create the site with the pasted token (not stored), then switch this
	 * WordPress to Netlify mode with that address, and to the GitHub trigger.
	 */
	public static function connect_netlify( \WP_REST_Request $req ) {
		$p      = (array) $req->get_json_params();
		$design = sanitize_key( (string) ( $p['astro_site'] ?? '' ) );
		if ( '' === $design ) {
			return new \WP_Error( 'wp_astro_design', __( 'Enter the site design folder, for example “dayo”.', 'wp-astro' ), [ 'status' => 400 ] );
		}
		$site = Netlify::create_site( (string) ( $p['token'] ?? '' ), (string) ( $p['name'] ?? '' ) );
		if ( is_wp_error( $site ) ) {
			return $site;
		}

		$in = [
			'_tab'            => 'deploy',
			'serve_mode'      => 'remote',
			'remote_origin'   => $site['url'],
			'netlify_site_id' => $site['id'],
			'astro_site'      => $design,
			'trigger_mode'    => 'github' === Settings::get( 'trigger_mode' ) || 'both' === Settings::get( 'trigger_mode' ) ? Settings::get( 'trigger_mode' ) : 'github',
		];
		// Keep every other deploy value as it is (sanitize() starts from the saved settings).
		foreach ( [ 'remote_ttl', 'github_owner', 'github_repo', 'github_event_type', 'webhook_url', 'output_path' ] as $k ) {
			$in[ $k ] = Settings::get( $k );
		}
		$warnings = self::persist( $in );

		return new \WP_REST_Response(
			[
				'site'     => $site,
				'warnings' => $warnings,
				'state'    => self::deploy_state(),
			]
		);
	}

	public static function get_edit( \WP_REST_Request $r ) {
		$p = self::faq_post( $r );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		return new \WP_REST_Response(
			[
				'article'    => Article_Edit::get( $p ),
				'categories' => array_map(
					static fn( $t ) => [
						'id'   => (int) $t->term_id,
						'name' => $t->name,
					],
					get_categories( [ 'hide_empty' => false ] )
				),
				'tags'       => array_map( static fn( $t ) => $t->name, get_tags( [ 'hide_empty' => false, 'number' => 500 ] ) ?: [] ),
				'articles'   => self::article_choices( $p->ID ),
			]
		);
	}

	/** Other published HTML articles — for the hand-picked "related articles" list. */
	private static function article_choices( int $exclude ): array {
		$q = new \WP_Query(
			[
				'post_type'      => Meta::post_types(),
				'post_status'    => 'publish',
				'meta_key'       => Meta::KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => Meta::ASTRO, // phpcs:ignore WordPress.DB.SlowDBQuery
				'post__not_in'   => [ $exclude ],
				'posts_per_page' => 200,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			]
		);
		$out = [];
		foreach ( $q->posts as $x ) {
			if ( Meta::ROLE_FRONT !== Meta::get_role( $x->ID ) ) {
				$out[] = [ 'id' => $x->ID, 'title' => html_entity_decode( get_the_title( $x ), ENT_QUOTES ) ];
			}
		}
		return $out;
	}

	public static function save_edit( \WP_REST_Request $r ) {
		$p = self::faq_post( $r );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$res = Article_Edit::save( $p->ID, (array) $r->get_json_params() );
		return is_wp_error( $res ) ? $res : new \WP_REST_Response( [ 'article' => Article_Edit::get( $res ) ] );
	}

	public static function preview_info( \WP_REST_Request $r ) {
		$p = self::faq_post( $r );
		return is_wp_error( $p ) ? $p : new \WP_REST_Response( Preview::info( $p ) );
	}

	public static function preview_schema( \WP_REST_Request $r ) {
		$p = self::faq_post( $r );
		return is_wp_error( $p ) ? $p : new \WP_REST_Response( Preview::schema( $p ) );
	}

	private static function faq_post( \WP_REST_Request $r ) {
		$p = get_post( (int) $r['id'] );
		if ( ! $p instanceof \WP_Post || ! in_array( $p->post_type, Meta::post_types(), true ) ) {
			return new \WP_Error( 'wp_astro_not_found', __( 'Article not found.', 'wp-astro' ), [ 'status' => 404 ] );
		}
		if ( ! current_user_can( 'edit_post', $p->ID ) ) {
			return new \WP_Error( 'wp_astro_forbidden', __( 'You cannot edit this article.', 'wp-astro' ), [ 'status' => 403 ] );
		}
		return $p;
	}

	private static function faq_payload( \WP_Post $p, array $f ): \WP_REST_Response {
		return new \WP_REST_Response(
			[
				'source'  => $f['source'],
				'enabled' => $f['enabled'],
				'items'   => $f['items'],
				'faq'     => Articles::faq_summary( $p ),
			]
		);
	}

	public static function get_faq( \WP_REST_Request $r ) {
		$p = self::faq_post( $r );
		return is_wp_error( $p ) ? $p : self::faq_payload( $p, Faq::effective( $p ) );
	}

	/** Body: { items: [ { q, a } ] } saves the list; { enabled: bool } switches the FAQ on/off; { reset: true } goes back to the article text. */
	public static function save_faq( \WP_REST_Request $r ) {
		$p = self::faq_post( $r );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$body = (array) $r->get_json_params();
		if ( ! empty( $body['reset'] ) ) {
			Faq::reset( $p->ID );
		} elseif ( isset( $body['items'] ) ) {
			Faq::save( $p->ID, (array) $body['items'] );
		}
		if ( array_key_exists( 'enabled', $body ) ) {
			Faq::set_enabled( $p->ID, (bool) $body['enabled'] );
		}
		return self::faq_payload( get_post( $p->ID ), Faq::effective( get_post( $p->ID ) ) );
	}

	public static function rebuild() {
		if ( 'none' === Settings::get( 'trigger_mode' ) ) {
			return new \WP_Error( 'wp_astro_no_trigger', __( 'Rebuild trigger is “None”. Choose GitHub Actions or Webhook first.', 'wp-astro' ), [ 'status' => 400 ] );
		}
		Trigger::dispatch();
		$last = Trigger::last_dispatch();
		foreach ( (array) ( $last['results'] ?? [] ) as $name => $r ) {
			if ( empty( $r['ok'] ) ) {
				return new \WP_Error( 'wp_astro_dispatch_failed', sprintf( '%s: %s', $name, (string) ( $r['message'] ?? __( 'request failed', 'wp-astro' ) ) ), [ 'status' => 502 ] );
			}
		}
		return new \WP_REST_Response(
			[
				'state'  => self::deploy_state(),
				'notice' => __( 'Rebuild requested.', 'wp-astro' ),
			]
		);
	}

	public static function purge(): \WP_REST_Response {
		$n = Serve::purge_all();
		return new \WP_REST_Response(
			[
				'state'  => self::deploy_state(),
				/* translators: %d: number of cached pages */
				'notice' => sprintf( _n( 'Purged %d cached page.', 'Purged %d cached pages.', $n, 'wp-astro' ), $n ),
			]
		);
	}
}
