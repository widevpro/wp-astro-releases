<?php
/**
 * Serve — on the front end, hand an Astro-flagged post its pre-built page
 * instead of letting WordPress/the theme render it.
 *
 *   disk    read {output_path}/{path}/index.html from this server (build rsynced here)
 *   remote  fetch {remote_origin}{path} (e.g. the Netlify site), cache it in a
 *           transient for remote_ttl seconds, stream it. WordPress keeps the domain.
 *
 * Falls straight through to normal WordPress if serving is disabled, the post isn't
 * flagged, the file/URL is missing, or the request isn't a plain GET of the post URL.
 * The "Blog front" post additionally serves its paginated URLs {path}page/N/.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Serve {

	private const T_PREFIX = 'wp_astro_page_';
	private const MISS_TTL = 120; // how long to remember "remote has no such page"

	public static function init(): void {
		add_action( 'template_redirect', [ __CLASS__, 'maybe_serve' ], 1 );
		add_action( 'admin_post_wp_astro_purge', [ __CLASS__, 'handle_manual_purge' ] );
		add_action( 'update_option_' . Settings::OPTION, [ __CLASS__, 'purge_all' ] );
	}

	/* ---------------------------------------------------------------- serving */

	public static function maybe_serve(): void {
		if ( is_admin() || is_preview() || is_embed() || is_feed() || is_404() || is_trackback() || is_robots() ) {
			return;
		}
		if ( ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', [ 'GET', 'HEAD' ], true ) ) {
			return;
		}
		if ( ! Settings::get( 'serve_enabled' ) ) {
			return;
		}
		if ( ! is_singular( Meta::post_types() ) ) {
			return;
		}

		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) {
			return;
		}
		if ( Meta::ASTRO !== Meta::get( $post->ID ) ) {
			return;
		}

		$path = self::request_path();
		if ( null === $path || ! self::path_belongs_to( $path, $post ) ) {
			return; // /slug/feed/, /slug/2/, odd URLs: let WordPress decide
		}

		$mode = (string) Settings::get( 'serve_mode' );
		$html = 'remote' === $mode ? self::from_remote( $path, $source ) : self::from_disk( $path, $source );
		if ( null === $html ) {
			return; // nothing built (yet) for this URL — WordPress renders it
		}

		header_remove( 'X-Pingback' );
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
		header( 'X-WP-Astro: ' . $source );
		header( 'Cache-Control: public, max-age=60' );
		header( 'ec-cdn-cache-control: public, max-age=60, s-maxage=300' ); // hosts with an edge cache (Elementor Cloud): keep copies short so edits show within minutes
		header( 'Vary: Accept-Encoding' );

		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- complete pre-built document
		exit;
	}

	/** Request path relative to the WP home, normalised to /a/b/ form. Null if unsafe. */
	public static function request_path(): ?string {
		$uri  = (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
		$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( '' !== $home && str_starts_with( $uri, $home ) ) {
			$uri = substr( $uri, strlen( $home ) );
		}
		$uri = '/' . trim( rawurldecode( $uri ), '/' );
		$uri = '/' === $uri ? '/' : $uri . '/';
		if ( str_contains( $uri, '..' ) || ! preg_match( '#^[A-Za-z0-9._~%/\-]*$#', $uri ) ) {
			return null;
		}
		return $uri;
	}

	/**
	 * The exact post URL, plus {url}page/N/ for the Blog front's pagination.
	 * No custom rewrite rule is needed for that second form: every WordPress
	 * permalink structure already adds a `page/(\d+)/` "old-style pagination"
	 * endpoint (the one `<!--nextpage-->` uses) to every singular post/page,
	 * so `/blog/page/2/` already resolves to the front post with is_singular()
	 * true — we only need to recognise the URL shape below.
	 */
	private static function path_belongs_to( string $path, \WP_Post $post ): bool {
		$own = wp_make_link_relative( get_permalink( $post ) );
		$own = '/' . trim( (string) wp_parse_url( $own, PHP_URL_PATH ), '/' );
		$own = '/' === $own ? '/' : $own . '/';
		if ( $path === $own ) {
			return true;
		}
		return Meta::is_front( $post->ID ) && (bool) preg_match( '#^' . preg_quote( $own, '#' ) . 'page/[1-9][0-9]*/$#', $path );
	}

	private static function from_disk( string $path, ?string &$source ): ?string {
		$configured = (string) Settings::get( 'output_path' );
		if ( '' === $configured ) {
			return null;
		}
		$root = realpath( $configured );
		if ( false === $root ) {
			return null;
		}
		$real = realpath( $root . $path . 'index.html' );
		if ( false === $real || ! str_starts_with( $real, $root . DIRECTORY_SEPARATOR ) ) {
			return null; // missing, or resolved outside the output directory
		}
		$source = 'disk';
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', (int) filemtime( $real ) ) . ' GMT' );
		$html = file_get_contents( $real ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return false === $html ? null : $html;
	}

	private static function from_remote( string $path, ?string &$source ): ?string {
		$origin = rtrim( (string) Settings::get( 'remote_origin' ), '/' );
		if ( '' === $origin ) {
			return null;
		}
		$key    = self::T_PREFIX . md5( $path );
		$cached = get_transient( $key );
		if ( is_string( $cached ) ) {
			if ( '' === $cached ) {
				return null; // remembered miss
			}
			$source = 'remote-cache';
			return $cached;
		}

		$res = wp_remote_get(
			$origin . $path,
			[
				'timeout'     => 10,
				'redirection' => 2,
				'headers'     => [
					'Accept'           => 'text/html',
					'User-Agent'       => 'wp-astro/' . WP_ASTRO_VERSION . ' (+' . home_url( '/' ) . ')',
					'X-WP-Astro-Proxy' => '1',
				],
			]
		);
		if ( is_wp_error( $res ) ) {
			return null; // don't cache network errors — try again next request
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = (string) wp_remote_retrieve_body( $res );
		if ( 200 !== $code || '' === $body ) {
			set_transient( $key, '', self::MISS_TTL );
			return null;
		}
		set_transient( $key, $body, max( 60, (int) Settings::get( 'remote_ttl' ) ) );
		$source = 'remote';
		return $body;
	}

	/* ------------------------------------------------------------------ cache */

	/** Drop every cached remote page. Called on settings save, bulk actions, and the /purge endpoint. */
	public static function purge_all(): int {
		global $wpdb;
		$like = $wpdb->esc_like( '_transient_' . self::T_PREFIX ) . '%';
		$tout = $wpdb->esc_like( '_transient_timeout_' . self::T_PREFIX ) . '%';
		$n    = (int) $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $like, $tout )
		);
		if ( wp_using_ext_object_cache() ) {
			wp_cache_flush();
		}
		return (int) floor( $n / 2 );
	}

	public static function handle_manual_purge(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wp_astro_purge' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wp-astro' ) );
		}
		$n = self::purge_all();
		wp_safe_redirect(
			add_query_arg( 'wp_astro_purged', $n, wp_get_referer() ?: Settings::page_url( [ 'tab' => 'deploy' ] ) )
		);
		exit;
	}

}
