<?php
/**
 * Preview — what the Edit article screen needs to show the live page: the page address, where the
 * latest build is, and the structured data (JSON-LD) that page really contains. Drafts never build,
 * so they only get WordPress's own preview link.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Preview {

	/** @return array<string,mixed> */
	public static function info( \WP_Post $p ): array {
		$published = 'publish' === $p->post_status;
		$url       = $published ? (string) get_permalink( $p ) : '';
		$st        = Trigger::status();
		return [
			'published'  => $published,
			'url'        => $url,
			'wp_preview' => (string) get_preview_post_link( $p ),
			'rich_url'   => $url ? 'https://search.google.com/test/rich-results?url=' . rawurlencode( $url ) : '',
			'build'      => $st ? [
				'state'   => (string) $st['state'],
				'time'    => (int) $st['time'],
				'message' => (string) ( $st['message'] ?? '' ),
			] : null,
			'queued'     => Trigger::is_queued(),
			'now'        => time(),
			'modified'   => (int) get_post_modified_time( 'U', true, $p ),
		];
	}

	/**
	 * Fetch the live page and list its JSON-LD blocks.
	 *
	 * @return array{ok:bool,url:string,error:string,nodes:array<int,array{type:string,id:string,name:string,json:mixed}>,notes:string[]}
	 */
	public static function schema( \WP_Post $p ): array {
		$out = [
			'ok'    => false,
			'url'   => '',
			'error' => '',
			'nodes' => [],
			'notes' => [],
		];
		if ( 'publish' !== $p->post_status ) {
			$out['error'] = __( 'Only published pages have structured data — drafts are not built.', 'wp-astro' );
			return $out;
		}
		$url        = add_query_arg( 'wa_schema', (string) time(), (string) get_permalink( $p ) );
		$out['url'] = (string) get_permalink( $p );
		$res        = wp_remote_get( $url, [ 'timeout' => 15, 'redirection' => 3, 'sslverify' => 'local' !== wp_get_environment_type() ] );
		if ( is_wp_error( $res ) ) {
			$out['error'] = $res->get_error_message();
			return $out;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 200 !== $code ) {
			/* translators: %d: HTTP status */
			$out['error'] = sprintf( __( 'The page answered with HTTP %d.', 'wp-astro' ), $code );
			return $out;
		}
		$html = (string) wp_remote_retrieve_body( $res );
		if ( ! preg_match_all( '#<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#si', $html, $m ) ) {
			$out['error'] = __( 'This page has no structured data. It may be served by WordPress, not built as HTML yet.', 'wp-astro' );
			return $out;
		}
		foreach ( $m[1] as $block ) {
			$data = json_decode( trim( html_entity_decode( $block ) ), true );
			if ( ! is_array( $data ) ) {
				$out['notes'][] = __( 'A structured-data block could not be read (invalid JSON).', 'wp-astro' );
				continue;
			}
			$graph = isset( $data['@graph'] ) && is_array( $data['@graph'] ) ? $data['@graph'] : [ $data ];
			foreach ( $graph as $node ) {
				if ( ! is_array( $node ) ) {
					continue;
				}
				$type = $node['@type'] ?? '';
				$out['nodes'][] = [
					'type' => is_array( $type ) ? implode( ' + ', array_map( 'strval', $type ) ) : (string) $type,
					'id'   => (string) ( $node['@id'] ?? '' ),
					'name' => (string) ( $node['name'] ?? $node['headline'] ?? '' ),
					'json' => $node,
				];
			}
		}
		$types = [];
		foreach ( array_column( $out['nodes'], 'type' ) as $t ) {
			$types = array_merge( $types, explode( ' + ', $t ) );
		}
		$all = (string) wp_json_encode( array_column( $out['nodes'], 'json' ) ); // types can also be nested (breadcrumb inside the page)
		foreach ( [ 'Article' => [ 'Article', 'BlogPosting' ], 'WebPage' => [ 'WebPage' ], 'BreadcrumbList' => [ 'BreadcrumbList' ] ] as $label => $any ) {
			if ( ! array_intersect( $any, $types ) && false === strpos( $all, '"@type":"' . $any[0] . '"' ) ) {
				/* translators: %s: schema type */
				$out['notes'][] = sprintf( __( 'No %s found in the structured data.', 'wp-astro' ), $label );
			}
		}
		$out['ok'] = (bool) $out['nodes'];
		return $out;
	}
}
