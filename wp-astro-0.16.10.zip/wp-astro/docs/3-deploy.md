# How deploy works

There are three different things that get "deployed", and each has its own path: a **content change** (an editor saves something), a **code change** (the front end or the admin screens), and a **plugin release** (what sites install). None of them can break a live page: if a build fails, visitors keep seeing the last good page or the normal WordPress page.

## 1. A content change (an editor saves)

1. The editor saves in W-Blog (an article, the Content tab, the Styles tab, a menu). The save is instant and is stored in WordPress.
2. The change is marked as **pending**. Every W-Blog screen shows "N changes saved — going live …" with a **Publish now** button.
3. When it goes out depends on **Deploy → Changes go live**: 10 minutes after your last edit (the default, so one rebuild covers a whole editing session), only when you click **Publish now**, or a minute after every save.
4. The plugin sends the rebuild request. **Deploy → Rebuild trigger** chooses how: a Netlify build hook (webhook), a GitHub Actions request, or both. The open admin screens drive this, so it does not depend on WordPress's own scheduler.
5. The build reads the post list (`manifest`), the posts, and the site settings (`config`) from WordPress, makes the HTML and the optimised images, and publishes them.
6. When the deploy finishes, the plugin's page cache is emptied (the **Purge URL**) and **Last build** on Deploy shows the result.
7. The next visitor gets the new page.

It takes about 2–3 minutes from the click to the live page. If a publish fails, your changes stay pending and nothing is lost.

## 2. A code change (front end or admin screens)

1. Work on a branch and open a pull request. There are no direct pushes to `main`.
2. The checks run: lint, build, HTML validation, and the design-variable list check.
3. Merge to `main`.
4. **Git-connected Netlify sites** build automatically on the merge. **GitHub Actions sites** do not; they rebuild the next time WordPress asks, or when you click **Rebuild now**.
5. If the change touched the admin screens or PHP, it only reaches sites through a plugin release (below).

Each Netlify build costs credits, and every pull request also builds a preview. Test locally first.

## 3. A plugin release

1. Raise the version in `plugin/wp-astro.php` in both places and merge.
2. Tag the merge `vX.Y.Z` and push the tag.
3. `release-plugin.yml` builds the zip and updates `latest.json` in the public releases repository. Old zips stay there.
4. On a site, open **W-Blog → Settings → Check for updates**, then **Update**.
5. Publish a rebuild if the release changed how pages look.

An older version can be reinstalled from its zip in the releases repository if something goes wrong.

## Installing the plugin on a site (first time)

Requirements: WordPress 6.4 or newer and PHP 8.1 or newer.

1. Build the zip with `scripts/build-plugin-zip.sh` (it writes `build/wp-astro-<version>.zip`), or take one from the releases repository.
2. In WordPress open **Plugins → Add New → Upload Plugin**, choose the zip, install and activate. When replacing an installed copy, tick **Replace current with uploaded**. Settings and flagged posts are kept.
3. A top-level menu **W-Blog** appears, with **Articles** and **Settings**.

After the first install, updates arrive from the releases repository, so there is no need to upload again. You are running version {{version}}.

## The three workflows

| File | Runs when | What it does |
| --- | --- | --- |
| `deploy.yml` | A push to `main` that touches `plugin/` or `frontend/`; or by hand | The checks, and copying the plugin to the servers in its list |
| `build-blog.yml` | The plugin sends a rebuild request; or by hand | Builds one site and publishes it, then reports the result and clears the WordPress cache. With a Netlify site ID in the request it deploys to Netlify; without one it copies the build to the site's own server over rsync |
| `release-plugin.yml` | A tag `v*` is pushed | Writes the release history, builds the zip and publishes it with `latest.json` |
## Optional: copying the plugin to a server

`deploy.yml` can copy the plugin to listed WordPress servers over SSH when `plugin/**` changes on `main`. Each server has its own GitHub Environment with its secrets. Most sites use the in-admin updater instead.

## Self-hosted sites: publishing by rsync

A site in **Self-hosted** mode needs no Netlify. `build-blog.yml` builds the pages and copies them to the server with `rsync`. It finds its settings in a GitHub Environment named after the website address, with dots turned into dashes (`https://widev.pro` → `widev-pro`):

| Where | Name | What |
| --- | --- | --- |
| Secret | `SSH_PRIVATE_KEY` | A key that is allowed to run `rsync` and nothing else |
| Variable | `SSH_HOST`, `SSH_USER` | The server and the user the key belongs to |
| Variable | `SSH_KNOWN_HOSTS` | The server's fingerprint (`ssh-keyscan -t ed25519 HOST`), so a fake server cannot take its place |
| Variable | `BUILD_PATH` | Optional. Where the build goes, default `/astro/` |
| Variable | `PLUGIN_PATH`, `SITE_URL` | Used by `deploy.yml` to copy the plugin and test the site |

Limit the Environment to the `main` branch. On the server, restrict the key in `authorized_keys` with `restrict,command="rrsync /path/to/site"`, so it cannot open a shell. Because that key cannot run WP-CLI, activate the plugin once in WordPress → Plugins; later updates arrive by rsync.

## Checking that a deploy worked

- **Last build** on the Deploy tab shows the state and time of the latest build.
- Open an article and look at the response header `X-WP-Astro: remote` (pages from Netlify) or `disk` (pages from the server folder).
- Add `?x=1` to the address to skip any CDN cache while checking.
- After a plugin update, the version line at the top of the W-Blog screens shows the new number.

## If a build fails

- Read the run in GitHub → Actions (GitHub route) or Netlify → Deploys (Netlify route).
- Your edits are still pending and safe. Fix the cause and click **Publish now** or **Rebuild now**.
- Meanwhile visitors see the last built page. If an article's address changed before a rebuild, they see the last built copy from the old address.
- To go back to an earlier version of the site, publish an earlier deploy in Netlify.
