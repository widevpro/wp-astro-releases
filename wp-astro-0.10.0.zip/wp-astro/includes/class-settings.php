<?php
/**
 * Settings — the admin options page (Settings → WP-Astro) and the get() accessor
 * every other class reads. A wp-config.php constant always overrides a stored value.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {

	public const OPTION = 'wp_astro_settings';
	public const GROUP  = 'wp_astro';

	/** Admin pages under the top-level "Astro" menu. */
	public const PAGE          = 'wp-astro';
	public const ARTICLES_PAGE = 'wp-astro-articles';
	public const EDIT_PAGE     = 'wp-astro-edit';

	private const DEFAULTS = [
		'post_types'        => [ 'post' ],
		'output_path'       => '',
		'serve_enabled'     => true,
		'serve_mode'        => 'disk',  // disk | remote
		'remote_origin'     => '',      // e.g. https://dayo-blog.netlify.app
		'remote_ttl'        => DAY_IN_SECONDS,
		'purge_token'       => '',      // auto-generated on first save
		'trigger_mode'      => 'none', // none | github | webhook | both
		'github_owner'      => '',
		'github_repo'       => '',
		'github_event_type' => 'wp-astro-rebuild',
		'github_token'      => '',
		'webhook_url'       => '',
		'astro_site'        => '',      // frontend/src/sites/<name> design the GitHub build uses
		'netlify_site_id'   => '',
		'google_api_key'    => '',
		'shared_head'       => '',
		'shared_body'       => '',
	];

	/** setting key => wp-config constant that overrides it */
	private const CONSTANTS = [
		'output_path'   => 'WP_ASTRO_OUTPUT_PATH',
		'remote_origin' => 'WP_ASTRO_REMOTE_ORIGIN',
		'purge_token'   => 'WP_ASTRO_PURGE_TOKEN',
		'github_token'  => 'WP_ASTRO_GITHUB_TOKEN',
		'webhook_url'   => 'WP_ASTRO_WEBHOOK_URL',
		'google_api_key' => 'WP_ASTRO_GOOGLE_API_KEY',
	];

	public static function init(): void {
		add_filter( 'wp_astro_post_types', [ __CLASS__, 'filter_post_types' ] );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_init', [ __CLASS__, 'register' ] );
		add_action( 'admin_menu', [ __CLASS__, 'redirect_old_url' ], 0 ); // before WP checks page access
		add_filter( 'plugin_action_links_' . plugin_basename( WP_ASTRO_FILE ), [ __CLASS__, 'action_links' ] );
	}

	/** "Settings" link on the plugins list row (Settings | Deactivate). */
	public static function action_links( array $links ): array {
		array_unshift( $links, sprintf( '<a href="%s">%s</a>', esc_url( self::page_url() ), esc_html__( 'Settings', 'wp-astro' ) ) );
		return $links;
	}

	/** All settings, defaults merged in. */
	public static function all(): array {
		$saved = get_option( self::OPTION, [] );
		return wp_parse_args( is_array( $saved ) ? $saved : [], self::DEFAULTS );
	}

	/** One setting. A defined wp-config constant wins over the stored value. */
	public static function get( string $key ) {
		if ( self::is_locked( $key ) ) {
			return constant( self::CONSTANTS[ $key ] );
		}
		$all = self::all();
		return $all[ $key ] ?? ( self::DEFAULTS[ $key ] ?? null );
	}

	/** The URL Netlify (or any CI) calls after a deploy to drop cached remote pages. */
	public static function purge_url(): string {
		$token = (string) self::get( 'purge_token' );
		return '' === $token ? '' : add_query_arg( 'token', $token, rest_url( Rest::NS . '/purge' ) );
	}

	/** The URL Netlify / CI calls with the build result (building, ready, error). */
	public static function build_status_url(): string {
		$token = (string) self::get( 'purge_token' );
		return '' === $token ? '' : add_query_arg( 'token', $token, rest_url( Rest::NS . '/build-status' ) );
	}

	/** Name of the wp-config.php constant that fixes a setting, if it has one. */
	public static function locked_constant( string $key ): ?string {
		return self::CONSTANTS[ $key ] ?? null;
	}

	public static function is_locked( string $key ): bool {
		return isset( self::CONSTANTS[ $key ] ) && defined( self::CONSTANTS[ $key ] );
	}

	/** Feeds Meta::post_types() — the toggle appears only on the configured types. */
	public static function filter_post_types( $types ) {
		$configured = (array) self::get( 'post_types' );
		return $configured ?: $types;
	}

	public static function menu(): void {
		add_menu_page(
			__( 'W-Blog', 'wp-astro' ),
			__( 'W-Blog', 'wp-astro' ),
			'manage_options',
			self::ARTICLES_PAGE,
			[ Admin_Api::class, 'render_articles' ],
			self::menu_icon(),
			58
		);
		add_submenu_page( self::ARTICLES_PAGE, __( 'Articles', 'wp-astro' ), __( 'Articles', 'wp-astro' ), 'manage_options', self::ARTICLES_PAGE, [ Admin_Api::class, 'render_articles' ] );
		$edit_hook = add_submenu_page( null, __( 'Edit article', 'wp-astro' ), '', 'manage_options', self::EDIT_PAGE, [ Admin_Api::class, 'render_edit' ] ); // hidden: opened from the Articles list
		if ( $edit_hook ) {
			add_action( 'load-' . $edit_hook, static function () {
				$GLOBALS['title'] = __( 'Edit article', 'wp-astro' ); // browser tab title for a page without a menu entry
			} );
		}
		add_submenu_page( self::ARTICLES_PAGE, __( 'W-Blog settings', 'wp-astro' ), __( 'Settings', 'wp-astro' ), 'manage_options', self::PAGE, [ __CLASS__, 'render_page' ] );
	}

	/**
	 * The sidebar icon: assets/menu-icon.svg as a data URI, which WordPress recolours to match the
	 * admin colour scheme. Falls back to a dashicon if the file is missing.
	 */
	private static function menu_icon(): string {
		$file = WP_ASTRO_DIR . 'assets/menu-icon.svg';
		$svg  = is_readable( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return '' === $svg ? 'dashicons-cloud' : 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/** Address of the Astro settings page (optionally on a tab). */
	public static function page_url( array $args = [] ): string {
		return add_query_arg( array_merge( [ 'page' => self::PAGE ], $args ), admin_url( 'admin.php' ) );
	}

	/** Which of our screens is open: 'settings' | 'articles' | 'edit' | null. */
	public static function screen(): ?string {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( self::PAGE === $page ) {
			return 'settings';
		}
		if ( self::EDIT_PAGE === $page ) {
			return 'edit';
		}
		return self::ARTICLES_PAGE === $page ? 'articles' : null;
	}

	/** The settings used to live at Settings → WP-Astro; keep old bookmarks working. */
	public static function redirect_old_url(): void {
		global $pagenow;
		if ( 'options-general.php' !== $pagenow || self::screen() !== 'settings' ) {
			return;
		}
		$args = [];
		foreach ( [ 'tab', 'doc', 'legacy' ] as $k ) {
			if ( isset( $_GET[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$args[ $k ] = sanitize_key( wp_unslash( $_GET[ $k ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}
		wp_safe_redirect( self::page_url( $args ) );
		exit;
	}

	public static function register(): void {
		register_setting(
			self::GROUP,
			self::OPTION,
			[ 'sanitize_callback' => [ __CLASS__, 'sanitize' ] ]
		);
	}

	/**
	 * Post types that make sense as Astro pages: public, in the REST API, with a title.
	 * Internal types (Media, Elementor templates / floating elements) are left out;
	 * filter `wp_astro_excluded_post_types` to change that.
	 */
	public static function selectable_post_types(): array {
		$excluded = (array) apply_filters( 'wp_astro_excluded_post_types', [ 'attachment', 'elementor_library', 'e-floating-buttons' ] );
		$out      = [];
		foreach ( get_post_types( [ 'public' => true, 'show_in_rest' => true ], 'objects' ) as $obj ) {
			if ( ! in_array( $obj->name, $excluded, true ) && post_type_supports( $obj->name, 'title' ) ) {
				$out[ $obj->name ] = $obj;
			}
		}
		return $out;
	}

	/** How many posts of a type are flagged Astro (any status except trash). */
	public static function astro_count( string $type ): int {
		$q = new \WP_Query(
			[
				'post_type'      => $type,
				'post_status'    => 'any',
				'meta_key'       => Meta::KEY,
				'meta_value'     => Meta::ASTRO,
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
			]
		);
		return (int) $q->found_posts;
	}

	/** Types that cannot be switched off because Astro pages still depend on them. */
	public static function locked_post_types(): array {
		$all = array_unique( array_merge( array_keys( self::selectable_post_types() ), (array) self::all()['post_types'] ) );
		return array_values( array_filter( $all, static fn( $t ) => post_type_exists( $t ) && self::astro_count( $t ) > 0 ) );
	}

	/** Tabs backed by this option (Content and Styles have their own options). */
	public static function tabs(): array {
		return [
			'general' => __( 'General', 'wp-astro' ),
			'deploy'  => __( 'Deploy', 'wp-astro' ),
			'content' => __( 'Content', 'wp-astro' ),
			'styles'  => __( 'Styles', 'wp-astro' ),
			'google'  => __( 'Google', 'wp-astro' ),
			'guide'   => __( 'Guide', 'wp-astro' ),
		];
	}

	public static function current_tab(): string {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return isset( self::tabs()[ $tab ] ) ? $tab : 'general';
	}

	/**
	 * Each form posts a hidden `_tab`; only that tab's keys are touched, so saving
	 * General never resets Deploy (checkboxes and blanks would otherwise be lost).
	 */
	public static function sanitize( $input ): array {
		$in  = is_array( $input ) ? wp_unslash( $input ) : [];
		$out = self::all(); // start from current, so locked / unsubmitted keys keep their value
		// No `_tab` (a form opened before tabs existed, or update_option() from code) = every key.
		$tab = $in['_tab'] ?? 'all';

		if ( in_array( $tab, [ 'general', 'all' ], true ) ) {
			$allowed = array_unique( array_merge( array_keys( self::selectable_post_types() ), (array) $out['post_types'] ) );
			$pt      = array_values( array_intersect( (array) ( $in['post_types'] ?? [] ), $allowed ) );

			// A type with Astro pages stays on: dropping it would make those pages vanish from the build.
			$locked = self::locked_post_types();
			if ( array_diff( $locked, $pt ) ) {
				add_settings_error(
					self::OPTION,
					'wp_astro_locked_types',
					sprintf(
						/* translators: %s: post type names */
						__( 'Kept enabled: %s still has HTML pages. Switch them back to WordPress first.', 'wp-astro' ),
						implode( ', ', array_diff( $locked, $pt ) )
					),
					'warning'
				);
			}
			$out['post_types'] = array_values( array_unique( array_merge( $pt, $locked ) ) ) ?: [ 'post' ];

			// The Blog front: the one page rendered as the article list.
			if ( array_key_exists( 'front_post', $in ) ) {
				$new = absint( $in['front_post'] );
				$cur = Meta::front_post();
				if ( ( $cur ? $cur->ID : 0 ) !== $new ) {
					if ( $cur ) {
						Meta::set( $cur->ID, Meta::WORDPRESS, Meta::ROLE_ARTICLE );
					}
					if ( $new && in_array( get_post_type( $new ), Meta::post_types(), true ) ) {
						Meta::set( $new, Meta::ASTRO, Meta::ROLE_FRONT );
					}
				}
			}

			// Shared markup is raw tracking HTML/JS by design — not escaped. manage_options only.
			$out['shared_head'] = (string) ( $in['shared_head'] ?? '' );
			$out['shared_body'] = (string) ( $in['shared_body'] ?? '' );
		}

		if ( in_array( $tab, [ 'deploy', 'all' ], true ) ) {
			if ( ! self::is_locked( 'output_path' ) ) {
				$out['output_path'] = isset( $in['output_path'] ) ? trim( sanitize_text_field( $in['output_path'] ) ) : '';
			}
			if ( ! self::is_locked( 'webhook_url' ) ) {
				$out['webhook_url'] = esc_url_raw( $in['webhook_url'] ?? '' );
			}

			$out['serve_mode']    = 'remote' === ( $in['serve_mode'] ?? 'disk' ) ? 'remote' : 'disk';
			if ( ! self::is_locked( 'remote_origin' ) ) {
				$out['remote_origin'] = rtrim( esc_url_raw( $in['remote_origin'] ?? '' ), '/' );
			}
			$out['remote_ttl'] = max( 60, (int) ( $in['remote_ttl'] ?? DAY_IN_SECONDS ) );
			if ( ! self::is_locked( 'purge_token' ) && ( '' === (string) $out['purge_token'] || ! empty( $in['regen_token'] ) ) ) {
				$out['purge_token'] = wp_generate_password( 32, false );
			}

			$out['astro_site']      = sanitize_key( (string) ( $in['astro_site'] ?? $out['astro_site'] ) );
			$out['netlify_site_id'] = sanitize_text_field( (string) ( $in['netlify_site_id'] ?? $out['netlify_site_id'] ) );

			$mode                = $in['trigger_mode'] ?? 'none';
			$out['trigger_mode'] = in_array( $mode, [ 'none', 'github', 'webhook', 'both' ], true ) ? $mode : 'none';

			$out['github_owner']      = sanitize_text_field( $in['github_owner'] ?? '' );
			$out['github_repo']       = sanitize_text_field( $in['github_repo'] ?? '' );
			$out['github_event_type'] = sanitize_text_field( $in['github_event_type'] ?? '' ) ?: 'wp-astro-rebuild';

			// Token: password field renders empty; only overwrite when something was typed.
			if ( ! self::is_locked( 'github_token' ) ) {
				$token = trim( (string) ( $in['github_token'] ?? '' ) );
				if ( '' !== $token ) {
					$out['github_token'] = $token;
				}
			}
		}

		if ( in_array( $tab, [ 'google', 'all' ], true ) && ! self::is_locked( 'google_api_key' ) ) {
			$key = trim( (string) ( $in['google_api_key'] ?? '' ) );
			if ( '' !== $key ) {
				$out['google_api_key'] = $key;
			} elseif ( ! empty( $in['clear_google_key'] ) ) {
				$out['google_api_key'] = '';
			}
		}

		return $out;
	}

	/** The pill navigation shared by every W-Blog screen (Articles first, then the settings tabs). */
	public static function render_tabs( string $active ): void {
		$items = [ 'articles' => [ __( 'Articles', 'wp-astro' ), add_query_arg( [ 'page' => self::ARTICLES_PAGE ], admin_url( 'admin.php' ) ) ] ];
		foreach ( self::tabs() as $slug => $label ) {
			$items[ $slug ] = [ $label, self::page_url( [ 'tab' => $slug ] ) ];
		}
		?>
		<style>
			.wpa-tabs{display:flex;flex-wrap:wrap;gap:4px;width:fit-content;max-width:100%;margin:14px 0 6px;padding:4px;background:#fff;border:1px solid #dcdcde;border-radius:12px;box-shadow:0 1px 1px rgba(0,0,0,.03)}
			.wpa-tabs a{padding:7px 16px;border-radius:9px;color:#3c434a;font-weight:500;text-decoration:none;transition:background .15s,color .15s}
			.wpa-tabs a:hover{background:#f3f4f8;color:#1d2327}
			.wpa-tabs a:focus-visible{outline:2px solid var(--wp-admin-theme-color,#2271b1);outline-offset:1px}
			.wpa-tabs a.is-active{background:var(--wp-admin-theme-color,#2271b1);color:#fff;box-shadow:0 1px 2px rgba(0,0,0,.18)}
		</style>
		<nav class="wpa-tabs" aria-label="<?php esc_attr_e( 'W-Blog sections', 'wp-astro' ); ?>">
			<?php foreach ( $items as $slug => [ $label, $url ] ) : ?>
				<a href="<?php echo esc_url( $url ); ?>" class="<?php echo $slug === $active ? 'is-active' : ''; ?>"<?php echo $slug === $active ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
		<?php
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tab = self::current_tab();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'W-Blog', 'wp-astro' ); ?></h1>
<?php self::render_tabs( $tab ); ?>
			<?php settings_errors(); ?>
			<?php
			switch ( $tab ) {
				case 'deploy':
					Admin_Api::handles( 'deploy' ) ? Admin_Api::render_mount() : self::render_deploy();
					break;
				case 'content':
					Admin_Api::handles( 'content' ) ? Admin_Api::render_mount() : Content::render();
					break;
				case 'styles':
					Admin_Api::handles( 'styles' ) ? Admin_Api::render_mount() : Style::render();
					break;
				case 'google':
					Admin_Api::handles( 'google' ) ? Admin_Api::render_mount() : self::render_google();
					break;
				case 'guide':
					Docs::render();
					break;
				default:
					Admin_Api::handles( 'general' ) ? Admin_Api::render_mount() : self::render_general();
			}
			?>
		</div>
		<?php
	}

	private static function render_general(): void {
		$s = self::all();
		$o = esc_attr( self::OPTION );
		?>
		<form method="post" action="options.php">
			<?php settings_fields( self::GROUP ); ?>
			<input type="hidden" name="<?php echo $o; ?>[_tab]" value="general">
			<table class="form-table" role="presentation">

					<tr>
						<th scope="row"><?php esc_html_e( 'Post types', 'wp-astro' ); ?></th>
						<td>
							<?php
							$locked = self::locked_post_types();
							foreach ( self::selectable_post_types() as $obj ) :
								$is_locked = in_array( $obj->name, $locked, true );
								?>
								<label style="margin-right:1.2em;">
									<input type="checkbox" name="<?php echo $o; ?>[post_types][]" value="<?php echo esc_attr( $obj->name ); ?>"
										<?php checked( $is_locked || in_array( $obj->name, (array) $s['post_types'], true ) ); ?>
										<?php disabled( $is_locked ); ?>>
									<?php if ( $is_locked ) : ?>
										<input type="hidden" name="<?php echo $o; ?>[post_types][]" value="<?php echo esc_attr( $obj->name ); ?>">
									<?php endif; ?>
									<?php echo esc_html( $obj->labels->name ); ?>
									<?php if ( $is_locked ) : ?>
										<small>(<?php echo esc_html( sprintf( /* translators: %d: number of Astro pages */ _n( '%d Astro page — locked', '%d Astro pages — locked', self::astro_count( $obj->name ), 'wp-astro' ), self::astro_count( $obj->name ) ) ); ?>)</small>
									<?php endif; ?>
								</label>
							<?php endforeach; ?>
							<p class="description"><?php esc_html_e( 'Which post types show the Render Engine toggle. A type with HTML pages is locked on; set those pages back to WordPress to unlock it.', 'wp-astro' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="wpa-front"><?php esc_html_e( 'Blog front', 'wp-astro' ); ?></label></th>
						<td>
							<?php
							$front      = Meta::front_post();
							$candidates = get_posts(
								[
									'post_type'        => Meta::post_types(),
									'post_status'      => 'publish',
									'numberposts'      => 300,
									'orderby'          => 'title',
									'order'            => 'ASC',
									'suppress_filters' => false,
								]
							);
							?>
							<select id="wpa-front" name="<?php echo $o; ?>[front_post]">
								<option value="0"><?php esc_html_e( '— None —', 'wp-astro' ); ?></option>
								<?php foreach ( $candidates as $c ) : ?>
									<option value="<?php echo (int) $c->ID; ?>" <?php selected( $front && $front->ID === $c->ID ); ?>>
										<?php echo esc_html( get_the_title( $c ) . ' (' . wp_make_link_relative( get_permalink( $c ) ) . ')' ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'The page that becomes the article list, built at its own URL (plus /page/N/ for pagination). Only published pages of the enabled post types are listed.', 'wp-astro' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="wpa-head"><?php esc_html_e( 'Shared <head> markup', 'wp-astro' ); ?></label></th>
						<td>
							<textarea id="wpa-head" class="large-text code" rows="6" placeholder="&lt;script&gt;console.log(&quot;Hello, head!&quot;);&lt;/script&gt;" name="<?php echo $o; ?>[shared_head]"><?php echo esc_textarea( $s['shared_head'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'GTM / analytics / verification tags — injected as-is into every HTML page <head>. Include the <script> tags.', 'wp-astro' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="wpa-body"><?php esc_html_e( 'Shared end-of-<body> markup', 'wp-astro' ); ?></label></th>
						<td>
							<textarea id="wpa-body" class="large-text code" rows="6" placeholder="&lt;script&gt;console.log(&quot;Hello, body end&quot;);&lt;/script&gt;" name="<?php echo $o; ?>[shared_body]"><?php echo esc_textarea( $s['shared_body'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Chat widgets / GTM noscript / etc. — injected as-is at the end of every HTML page <body>. Include the <script> tags.', 'wp-astro' ); ?></p>
						</td>
					</tr>

			</table>
			<?php submit_button(); ?>
		</form>

			<hr>
			<h2><?php esc_html_e( 'SEO settings', 'wp-astro' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Coming soon.', 'wp-astro' ); ?></p>

		<?php
	}

	private static function render_deploy(): void {
		$s = self::all();
		$o = esc_attr( self::OPTION );
		?>
		<form method="post" action="options.php">
			<?php settings_fields( self::GROUP ); ?>
			<input type="hidden" name="<?php echo $o; ?>[_tab]" value="deploy">
			<h2><?php esc_html_e( 'Hosting', 'wp-astro' ); ?></h2>
			<table class="form-table" role="presentation">

					<tr>
						<th scope="row"><label for="wpa-serve-mode"><?php esc_html_e( 'Mode', 'wp-astro' ); ?></label></th>
						<td>
							<select id="wpa-serve-mode" name="<?php echo $o; ?>[serve_mode]">
								<option value="disk" <?php selected( $s['serve_mode'], 'disk' ); ?>><?php esc_html_e( 'Self-hosted', 'wp-astro' ); ?></option>
								<option value="remote" <?php selected( $s['serve_mode'], 'remote' ); ?>><?php esc_html_e( 'Netlify', 'wp-astro' ); ?></option>
							</select>
						</td>
					</tr>

					<?php if ( ! self::is_locked( 'output_path' ) ) : // set in wp-config.php? then it is shown on the Guide tab instead ?>
					<tr class="wpa-mode-row" data-mode="disk">
						<th scope="row"><label for="wpa-output"><?php esc_html_e( 'Build folder', 'wp-astro' ); ?></label></th>
						<td>
							<input type="text" id="wpa-output" class="regular-text code" name="<?php echo $o; ?>[output_path]"
								value="<?php echo esc_attr( self::get( 'output_path' ) ); ?>">
							<p class="description"><?php esc_html_e( 'Absolute server path of the HTML build (one folder per URL, each with index.html).', 'wp-astro' ); ?></p>
						</td>
					</tr>
					<?php endif; ?>

					<tr class="wpa-mode-row" data-mode="remote">
						<th scope="row"><label for="wpa-remote"><?php esc_html_e( 'Netlify address', 'wp-astro' ); ?></label></th>
						<td>
							<input type="url" id="wpa-remote" class="regular-text code" placeholder="https://my-blog.netlify.app" name="<?php echo $o; ?>[remote_origin]"
								value="<?php echo esc_attr( self::get( 'remote_origin' ) ); ?>" <?php disabled( self::is_locked( 'remote_origin' ) ); ?>>
							<?php self::lock_note( 'remote_origin' ); ?>
						</td>
					</tr>

					<tr class="wpa-mode-row" data-mode="remote">
						<th scope="row"><label for="wpa-ttl"><?php esc_html_e( 'Cache time, sec', 'wp-astro' ); ?></label></th>
						<td><input type="number" id="wpa-ttl" min="60" step="60" class="small-text" style="width:7em" name="<?php echo $o; ?>[remote_ttl]" value="<?php echo esc_attr( (string) $s['remote_ttl'] ); ?>"></td>
					</tr>

					<tr class="wpa-mode-row" data-mode="remote">
						<th scope="row"><?php esc_html_e( 'Purge URL', 'wp-astro' ); ?></th>
						<td>
							<?php if ( self::purge_url() ) : ?>
								<input type="text" class="large-text code" readonly onclick="this.select()" value="<?php echo esc_attr( self::purge_url() ); ?>">
								<label><input type="checkbox" name="<?php echo $o; ?>[regen_token]" value="1"> <?php esc_html_e( 'Generate a new token on save', 'wp-astro' ); ?></label>
							<?php else : ?>
								<em><?php esc_html_e( 'Save settings once to generate the token.', 'wp-astro' ); ?></em>
							<?php endif; ?>
						</td>
					</tr>

			</table>

			<h2><?php esc_html_e( 'Rebuilds', 'wp-astro' ); ?></h2>
			<table class="form-table" role="presentation">

					<tr>
						<th scope="row"><label for="wpa-mode"><?php esc_html_e( 'Rebuild trigger', 'wp-astro' ); ?></label></th>
						<td>
							<select id="wpa-mode" name="<?php echo $o; ?>[trigger_mode]">
								<?php foreach ( [
									'none'    => __( 'None (manual only)', 'wp-astro' ),
									'github'  => __( 'GitHub Actions', 'wp-astro' ),
									'webhook' => __( 'Webhook URL', 'wp-astro' ),
									'both'    => __( 'Both', 'wp-astro' ),
								] as $val => $label ) : ?>
									<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $s['trigger_mode'], $val ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'GitHub repository', 'wp-astro' ); ?></th>
						<td>
							<input type="text" placeholder="owner" name="<?php echo $o; ?>[github_owner]" value="<?php echo esc_attr( $s['github_owner'] ); ?>">
							&nbsp;/&nbsp;
							<input type="text" placeholder="repo" name="<?php echo $o; ?>[github_repo]" value="<?php echo esc_attr( $s['github_repo'] ); ?>">
							<p class="description">
								<?php esc_html_e( 'Dispatch event type:', 'wp-astro' ); ?>
								<input type="text" name="<?php echo $o; ?>[github_event_type]" value="<?php echo esc_attr( $s['github_event_type'] ); ?>">
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="wpa-token"><?php esc_html_e( 'GitHub token', 'wp-astro' ); ?></label></th>
						<td>
							<?php if ( self::is_locked( 'github_token' ) ) : ?>
								<em><?php esc_html_e( 'Set via the WP_ASTRO_GITHUB_TOKEN constant.', 'wp-astro' ); ?></em>
							<?php else : ?>
								<input type="password" id="wpa-token" class="regular-text" autocomplete="new-password"
									name="<?php echo $o; ?>[github_token]" value=""
									placeholder="<?php echo $s['github_token'] ? esc_attr__( '•••••••• (blank = keep current)', 'wp-astro' ) : ''; ?>">
								<p class="description"><?php esc_html_e( 'Fine-grained PAT (Contents: read, Actions: write). Prefer the WP_ASTRO_GITHUB_TOKEN constant in wp-config.php.', 'wp-astro' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="wpa-webhook"><?php esc_html_e( 'Webhook URL', 'wp-astro' ); ?></label></th>
						<td>
							<input type="url" id="wpa-webhook" class="regular-text code" name="<?php echo $o; ?>[webhook_url]"
								value="<?php echo esc_attr( self::get( 'webhook_url' ) ); ?>" <?php disabled( self::is_locked( 'webhook_url' ) ); ?>>
							<?php self::lock_note( 'webhook_url' ); ?>
						</td>
					</tr>

			</table>
			<?php submit_button(); ?>
		</form>

			<hr>
			<h2><?php esc_html_e( 'Rebuild & cache', 'wp-astro' ); ?></h2>
			<?php $line = Trigger::status_line(); ?>
			<p>
				<strong><?php esc_html_e( 'Build status:', 'wp-astro' ); ?></strong>
				<?php echo $line ? esc_html( $line[1] ) : esc_html__( 'No build recorded yet.', 'wp-astro' ); ?>
			</p>
			<?php if ( self::build_status_url() ) : ?>
				<p class="description"><?php esc_html_e( 'To show build results here, add this URL in Netlify → Notifications → Outgoing webhook, for the events “Deploy started”, “Deploy succeeded” and “Deploy failed” (POST):', 'wp-astro' ); ?></p>
				<input type="text" class="large-text code" readonly onclick="this.select()" value="<?php echo esc_attr( self::build_status_url() ); ?>">
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:1em">
				<input type="hidden" name="action" value="wp_astro_rebuild">
				<?php wp_nonce_field( 'wp_astro_rebuild' ); ?>
				<?php submit_button( __( 'Rebuild now', 'wp-astro' ), 'secondary', 'submit', false ); ?>
			</form>
			<span class="wpa-mode-row" data-mode="remote">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
					<input type="hidden" name="action" value="wp_astro_purge">
					<?php wp_nonce_field( 'wp_astro_purge' ); ?>
					<?php submit_button( __( 'Purge page cache', 'wp-astro' ), 'secondary', 'submit', false ); ?>
				</form>
			</span>
			<?php if ( isset( $_GET['wp_astro_purged'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<p class="description"><?php printf( esc_html__( 'Purged %d cached page(s).', 'wp-astro' ), (int) $_GET['wp_astro_purged'] ); // phpcs:ignore WordPress.Security.NonceVerification ?></p>
			<?php endif; ?>
			<?php
			$last = Trigger::last_dispatch();
			if ( $last ) :
				?>
				<p class="description">
					<?php
					printf(
						/* translators: %s: human time diff */
						esc_html__( 'Last dispatch: %s ago', 'wp-astro' ),
						esc_html( human_time_diff( (int) $last['time'] ) )
					);
					?>
					&nbsp;—&nbsp;
					<code><?php echo esc_html( wp_json_encode( $last['results'] ) ); ?></code>
				</p>
			<?php endif; ?>
			<script>
			(function () {
				var mode = document.getElementById('wpa-serve-mode');
				function apply() {
					document.querySelectorAll('.wpa-mode-row').forEach(function (el) {
						el.style.display = el.dataset.mode === mode.value ? '' : 'none';
					});
				}
				mode.addEventListener('change', apply);
				apply();
			})();
			</script>
		<?php
	}

	private static function render_google(): void {
		$o = esc_attr( self::OPTION );
		?>
		<form method="post" action="options.php">
			<?php settings_fields( self::GROUP ); ?>
			<input type="hidden" name="<?php echo $o; ?>[_tab]" value="google">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="wpa-gkey"><?php esc_html_e( 'Google API key', 'wp-astro' ); ?></label></th>
					<td>
						<?php if ( self::is_locked( 'google_api_key' ) ) : ?>
							<em><?php esc_html_e( 'Set via the WP_ASTRO_GOOGLE_API_KEY constant.', 'wp-astro' ); ?></em>
						<?php else : ?>
							<input type="password" id="wpa-gkey" class="regular-text" autocomplete="new-password" name="<?php echo $o; ?>[google_api_key]" value=""
								placeholder="<?php echo self::get( 'google_api_key' ) ? esc_attr__( '•••••••• (blank = keep current)', 'wp-astro' ) : ''; ?>">
							<p class="description"><?php esc_html_e( 'Used for PageSpeed Insights checks. Enable the PageSpeed Insights API for the key in Google Cloud Console.', 'wp-astro' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	private static function lock_note( string $key ): void {
		if ( self::is_locked( $key ) ) {
			printf(
				' <em>%s</em>',
				esc_html( sprintf( __( 'locked by %s', 'wp-astro' ), self::CONSTANTS[ $key ] ) )
			);
		}
	}
}
