# W-Blog guide

This plugin lets you pick individual WordPress posts and pages and have them delivered as fast, pre-built static HTML pages. Visitors still use your normal WordPress address.

## How it works

1. You flag a post or page: **Render Engine → HTML** (on its edit screen).
2. The plugin publishes the list of flagged posts at `/wp-json/wp-astro/v1/manifest`.
3. The site build reads that list and the post content, and builds static HTML pages.
4. When a visitor opens a flagged post, the plugin shows the built page instead of rendering it with the theme.

If a built page is missing for any reason, WordPress shows the normal page, so nothing breaks.

## Flagging a post or page

On the edit screen, find the **Render Engine** box:

- **Render Engine** — `WordPress` (default) or `HTML`.
- **HTML Template** — `With sidebar` or `Full width`. You can also change it in the **W-Blog → Articles** table.

The article list (blog index) is not set per post: pick the page in **W-Blog → Settings → General → Blog front**. There is only one per site. The full-width layout is saved, but its design is still being built in the frontend.

## The settings tabs

| Tab | What it holds |
| --- | --- |
| General | Which post types can be HTML pages, the Blog front, shared `<head>` and end-of-`<body>` markup |
| Deploy | How built pages are served, rebuild trigger, build status, purge and rebuild buttons |
| Content | Site-wide text used on every page, in groups: Site & search, Business, Address & map, Hours & areas served, Header, Button & sidebar, Footer, Article list |
| Styles | Brand colours and optional custom CSS |
| Guide | This page |

A blank field in **Content** or **Styles** keeps the default from the site's project. Saving these tabs triggers a rebuild. Visitors never wait on them: the values are baked into the static pages.

**Styles apply to this website only.** Each WordPress site keeps its own Styles, so changing one here never touches another client's site. Examples: **Header logo width** (Layout) makes the logo smaller or larger, for instance `120px`. For a dark article hero set **Hero background** (a dark colour or gradient), **Hero text colour** (white), **Hero button colour** (a light colour) and **Hero button text colour** (dark).

The Content tab has a section list on the left (with how many fields are filled in) and a **More options** fold in each group for rarely needed fields. The click-to-call phone number is worked out from the displayed phone for US/Canada numbers; type it yourself for other countries. Unsaved changes are flagged and guarded when you leave the page.

### Descriptions and variables

Meta descriptions (what Google and AI search show) can use `{variables}`, for example:

```
Dental tourism in Mexico - {site_name}. Call us - {phone}.
```

The build fills them in. Which text a page uses, most specific first:

1. the post's own **SEO description** (in its Render Engine box on the edit screen),
2. the Yoast SEO description, if Yoast is installed,
3. **Default article description** from the Content tab,
4. the post's excerpt.

Leave a field blank to fall through to the next one. The full variable list is under the **Default article description** field on the Content tab.

### Edit article

Click an article's **Title** in **W-Blog → Articles** to open its own edit screen. It follows the page from top to bottom:

- **Header:** title (H1), address (slug), category, tags, template, featured image with alt text.
- **Summary (TL;DR):** the short answer at the top of the page, with a switch.
- **Body:** WordPress's own editor with a **Visual** and an **HTML** tab. Use H2 for sections (they build the contents list) and H3 inside them.
- **FAQ** and **Sources:** each with its own on/off switch.
- **SEO:** meta title and description (with live length guides and a Google preview), index/noindex, follow/nofollow, exclude from the XML sitemap, canonical URL, social title, description and image.

The text is only written back when you change it, so saving a title never rewrites the body. The **WordPress editor** button opens the standard editor instead.

### Author, review and page elements

- **Top bar** — the first card of the edit screen is the strip above the menu, edited the way it looks: free text on the left (a line, a list, links; variables like `{address}` and `{phone}` work) and the phone line on the right. Both start with the values from the Content tab; type to change them for this page only, or click “Use the site text / phone” to go back. The phone's call link is worked out from the number you type (US/Canada style).
- **Categories** — drag the category chips into order. The first one is shown above the title (and in the breadcrumb data).
- **No hero image** — the header becomes one centred column on desktop (title, then the button and the author side by side); mobile is unchanged.
- **Author** — pick any WordPress user. Their photo, job title, credentials, bio and links come from their profile (Users → Profile → “W-Blog author profile”); tick **Public author**, otherwise the site's default author is shown.
- **Practice block** — switch it on or off per article; its content (address, hours, map) is set once in the Content tab.
- **Services / products / treatments** — up to three cards (picture and title), in one row (one card is full width, two share the row, three fill it), linking to the services, products or treatments this page talks about. No heading unless you type one. Automatic picks up to three articles that share this article's tags, then its category (newest first, skipping the ones already in “Keep reading”); or pick up to three by hand.
- **Page elements** — table of contents, breadcrumbs, share buttons, reading time, call-to-action (with its own label and link) and related articles (automatic, hand-picked up to three, or off).
- **Structured data type** — Article, BlogPosting or MedicalWebPage. Sources become `citation` automatically.
- **Primary category** — which category is shown above the title when an article has several.
- **Publish date / Minor edit** — a minor edit keeps the “Updated” date, so typo fixes do not pretend to be updates.

### Hero video

The **Hero video** card on the edit screen puts a looping video in the hero, where the featured image is. Each article has its own.

- **Files:** choose a **WebM** and an **MP4 (H.264)** from the media library. Add both: WebM is smaller, MP4 plays everywhere, including Safari and iPhone.
- **Poster image:** shown at once and used as the main image for speed. Empty = the featured image. Use a still frame of the video, same shape. The site makes AVIF and WebP copies automatically.
- **Switches:** *Autoplay* (on = silent autoplay with a small pause button; off = the visitor presses play), *Loop*, *Muted* (always on with autoplay) and *Preload* (metadata only, or nothing). `playsinline` is always set.
- **What visitors get:** the poster loads first. The video is added after the page has loaded, on screens about 768 px and wider only. Phones, visitors who asked for reduced motion and data-saver visitors see just the poster and download no video.
- **Prepare the files** in your own tool: a 6–10 second seamless loop, 1280×720 or 1920×1080, 24–30 fps, no audio, under 2 MB each. The card shows an ffmpeg example.
- **Cloudflare:** `.mp4` and `.webm` files are cached by default. For a long cache, add a Cache Rule: URI path starts with `/wp-content/uploads/` and ends with `.mp4` or `.webm` → Eligible for cache, Edge TTL 1 month, Browser TTL 1 year.
- **Videos in the text:** add them in the body editor. They load only when played (a poster picture means nothing downloads first) and play in place on phones. YouTube links become a click-to-play picture.

### Body, summary and descriptions

Text pasted from a chat assistant, Google Docs, Word or a page builder is cleaned when the page is built: wrapper boxes, tracking attributes, empty tags, inline styles and stray line breaks are removed, so headings, paragraphs, lists, tables, pictures and videos sit directly in the column. Spacing between them follows one set of rules that every site shares and that scales with the text size: a normal gap between paragraphs and lists, more air around pictures, videos, tables and quotes, more above a heading than below it. A table wider than the column scrolls sideways, with a soft shadow on the side that has more to show.

- **Body editor** — headings H2–H6, bold, italic, underline, bullet and numbered lists, links, and an **Insert table** button (columns, rows, header row). There is no alignment, quote or horizontal line. On a phone a table keeps its layout and scrolls sideways.
- **Summary (TL;DR)** — WordPress's standard summary (excerpt) field, shown as a block at the top. Empty = no block. The box has two buttons, **B** (bold) and a bulleted list. **Enter** starts a new paragraph; inside a list it starts a new bullet, and **Enter** twice leaves the list. Pasted text loses its formatting. Nothing else is kept (no links, headings or colours). It is never used as the meta description.
- **Meta description** — separate from the summary: this page's own text (SEO card, 70–160 characters counts for the score), else the **Default article description** mask in Content (with variables like `{title}`, `{category}`, `{phone}`), else nothing is written.
- **Template** — *With sidebar* or *Full width* (one wide column, the widgets in a row above the text).
- **Menu** — the header menu comes only from Content → Header → Menu. Empty = no menu.

### Moving articles from another site

Export the posts from the old WordPress (Tools → Export) and import them here (Tools → Import). A "Posts" export does not carry the pictures. Then use **W-Blog → General → Import missing images**: enter the old site address, **Scan articles**, then **Copy images**. It copies the pictures the articles use into the media library, fixes the links in the text and sets the featured images. It works in small steps, can be repeated safely, and changes neither "Updated on" dates nor the live pages until you publish. The old site must stay online while you copy.

### Live page and structured data

- **Live page** (right column of the Edit article screen) tells you whether your last save is on the public page: **Saved — updating the page** while the rebuild runs (about a minute), **Almost there** while the cached copy refreshes, then **Live**. It checks the page itself, so it needs no build notifications, and it clears the plugin's cached copy as soon as the build has your change. **Preview here** opens the published page in a side panel, desktop or mobile. Drafts are never built, so they only get WordPress's own preview. Saving rebuilds automatically; the Rebuild button in the Deploy tab is only for rare cases.
- **Structured data** reads the schema.org (JSON-LD) from the live page itself and lists each block (WebPage, Article, FAQPage …) with its JSON, plus notes when something expected is missing. The **Google Rich Results Test** link needs a public address — it cannot open a local site.
- **Not updated in 12 months** (a popular search in the Articles table) lists published pages that have not been edited for a year.

### FAQ

Each article can have an FAQ section with schema.org `FAQPage` markup (what Google and AI search read). It is managed separately from the article text, in **W-Blog → Articles → FAQ** (or the **Edit FAQ** link in the article's Render Engine box):

- **Add / edit / delete questions.** A question becomes a heading (H3) on the page, the answer sits under it. Drag order with the ↑ ↓ buttons.
- **Switch** the FAQ on or off. Off keeps the questions but removes the section and its markup from the page.
- **Starting point.** If an article already has an “FAQ” section (H2) with questions in its text, that is used until you save the list here; after that the list here wins and the text section is hidden on the page.

### Shared markup

The two boxes on **General** are inserted exactly as typed. Include the `<script>` tags, for example `<script>console.log("hi");</script>`.

### Post types

A post type that already has HTML pages is locked on. To unlock it, set those pages back to **WordPress** first.

## Serving the built pages

**Mode** (on **Deploy**) decides where the built pages come from:

- **Self-hosted** — the build is copied to a folder on this server and the plugin reads it from there.
- **Netlify** — the plugin fetches pages from the hosted Netlify build and keeps them in a cache. Use the purge URL so a new deploy empties the cache immediately.

### Setting up Netlify mode (about 10 minutes, once per site)

The HTML pages are built by GitHub Actions and hosted on Netlify; this WordPress shows them at your own addresses.

1. **W-Blog → Settings → Deploy**, set **Mode** to **Netlify**.
2. In **Connect Netlify**, paste a Netlify personal access token (Netlify → User settings → Applications → Personal access tokens, signed in as the account that should own the site), choose a site name and the **Design** folder (for example `dayo`), and click **Create Netlify site**. The token is used once and is not stored.
3. Under **Rebuilds**, enter the GitHub **owner / repo** that holds this project and a GitHub token with “Contents: read” and “Actions: write”. Save.
4. In that GitHub repository add a secret **NETLIFY_AUTH_TOKEN** (Settings → Secrets and variables → Actions), with the same Netlify token. The workflow file `.github/workflows/build-blog.yml` must be on the repository’s `main` branch.
5. Click **Rebuild now**. When the run in GitHub → Actions finishes, the article addresses on your WordPress domain show the HTML pages. The **Last build** line on Deploy shows the result.

From then on, publishing or updating an HTML article rebuilds the site automatically about a minute later.

### Purge URL (Netlify)

In Netlify mode the plugin keeps each fetched page in a cache for the **Cache time**. The **Purge URL** empties that cache the moment a deploy finishes, so visitors never get an old page.

In Netlify open **Site configuration → Notifications → Deploy notifications**, add an **Outgoing webhook** for **Deploy succeeded**, and paste the Purge URL (POST). Any CI system can call it the same way. The token inside the URL is a secret: if it leaks, tick **Generate a new token on save** and update the webhook. In Self-hosted mode nothing is cached, so the field is hidden.

### The build folder (self-hosted)

The folder is a path on the server, so it is set once in `wp-config.php` rather than in this screen. When it is set that way, the field is hidden on **Deploy** and shown in the **Current setup** box above instead.

```php
define( 'WP_ASTRO_OUTPUT_PATH', '/var/www/astro-dist' );
```

The folder must contain one directory per page, each with an `index.html`, for example `astro-dist/my-post/index.html`.

### Settings that can be fixed in wp-config.php

A constant always wins over the stored value, and the matching field is locked.

| Constant | Setting |
| --- | --- |
| `WP_ASTRO_OUTPUT_PATH` | Build folder (self-hosted) |
| `WP_ASTRO_REMOTE_ORIGIN` | Netlify build address |
| `WP_ASTRO_PURGE_TOKEN` | Token for the purge and build-status URLs |
| `WP_ASTRO_GITHUB_TOKEN` | GitHub token for rebuilds |
| `WP_ASTRO_WEBHOOK_URL` | Rebuild webhook (for example a Netlify build hook) |
| `WP_ASTRO_CONFIG_TOKEN` | Optional token required to read `/wp-json/wp-astro/v1/config` |

## Rebuilds

**When do saved changes go live?** Saving is always instant; the public pages are rebuilt separately, and a rebuild takes 2–3 minutes. Choose how in **Deploy → Rebuilds → Changes go live**:

- **10 minutes after my last edit** (default) — edits are collected, then one rebuild covers the whole session.
- **When I click “Publish now”** — nothing goes out until you say so.
- **A minute after every save** — the old behaviour.

While edits are waiting, every W-Blog screen shows “N changes saved — going live …” with a **Publish now** button, and the Live page card on the edit screen says “Saved — not live yet” with the same button. A failed publish keeps your changes waiting. If you rename an article's address before the rebuild finishes, visitors see the last built copy from the old address instead of the theme page.

Publishing, updating or unpublishing a flagged post, editing a menu, or saving settings queues one rebuild about a minute later. Several edits in a row become a single rebuild. Choose how it is triggered under **Rebuild trigger** on **Deploy**: GitHub Actions, a webhook, or both. **Rebuild now** skips the wait.

## Troubleshooting

- **I still see the normal WordPress page.** Check that the post is published, flagged HTML, and that a built page exists for that address.
- **My change is not on the page.** The page only changes after a rebuild. Check the build status on **Deploy**.
- **My shared script does not run.** It needs the `<script>` tags.
- **A setting is greyed out.** It is fixed by a constant in `wp-config.php`.
