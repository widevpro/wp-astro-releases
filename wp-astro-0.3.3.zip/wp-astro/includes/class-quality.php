<?php
/**
 * Quality — the Content Quality Score (CQS, 0–100) of an Astro article: how complete it is
 * for Google and for AI search. Each check awards points and, when it falls short, says
 * what to improve. Computed from the post as stored in WordPress, so it needs no network.
 *
 * Points: title 10 · description 10 · depth 15 · images 10 · headings 15 · FAQ 15 ·
 *         links & sources 10 · answer paragraph & taxonomy 10 · readability 5.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Quality {

	/** @return array{score:int,grade:string,checks:array<int,array{label:string,points:int,max:int,tip:string}>} */
	public static function score( \WP_Post $p ): array {
		$html  = (string) $p->post_content;
		$text  = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $html ) ) ?? '' );
		$words = '' === $text ? 0 : count( preg_split( '/\s+/', $text ) ?: [] );

		$checks   = [];
		$add      = static function ( string $label, int $points, int $max, string $tip ) use ( &$checks ): void {
			$checks[] = [
				'label'  => $label,
				'points' => $points,
				'max'    => $max,
				'tip'    => $points < $max ? $tip : '',
			];
		};
		$tier     = static fn( int $v, array $steps ): int => array_reduce( array_keys( $steps ), static fn( $c, $min ) => $v >= $min ? $steps[ $min ] : $c, 0 );

		// 1. Title length.
		$tl = mb_strlen( html_entity_decode( get_the_title( $p ), ENT_QUOTES ) );
		$add( __( 'Title length', 'wp-astro' ), $tl >= 30 && $tl <= 65 ? 10 : ( $tl >= 20 && $tl <= 80 ? 5 : 0 ), 10, __( 'Aim for a title of 30–65 characters.', 'wp-astro' ) );

		// 2. Meta description (own SEO description, Yoast, or the excerpt).
		$desc = trim( (string) get_post_meta( $p->ID, Meta::DESC_KEY, true ) );
		if ( '' === $desc ) {
			$desc = trim( (string) get_post_meta( $p->ID, '_yoast_wpseo_metadesc', true ) );
		}
		$excerpt = trim( wp_strip_all_tags( (string) $p->post_excerpt ) );
		if ( '' === $desc ) {
			$desc = $excerpt;
		}
		$dl = mb_strlen( $desc );
		$add( __( 'Meta description', 'wp-astro' ), $dl >= 70 && $dl <= 160 ? 10 : ( $dl >= 40 && $dl <= 200 ? 5 : 0 ), 10, __( 'Write a 70–160 character description (SEO description box or excerpt).', 'wp-astro' ) );

		// 3. Depth.
		$add( __( 'Content depth', 'wp-astro' ), $tier( $words, [ 300 => 4, 500 => 8, 800 => 12, 1200 => 15 ] ), 15, sprintf( /* translators: %d: words */ __( '%d words — long-form answers (1,200+) rank and get cited more.', 'wp-astro' ), $words ) );

		// 4. Images: a featured image, and alt text on every image in the body.
		preg_match_all( '/<img\b[^>]*>/i', $html, $imgs );
		$no_alt = 0;
		foreach ( $imgs[0] as $img ) {
			if ( ! preg_match( '/\balt=("|\')\s*[^"\']+\1/i', $img ) ) {
				++$no_alt;
			}
		}
		$img_points = ( has_post_thumbnail( $p ) ? 5 : 0 ) + ( 0 === $no_alt ? ( $imgs[0] ? 5 : 2 ) : 0 );
		$add( __( 'Images & alt text', 'wp-astro' ), $img_points, 10, $no_alt ? sprintf( /* translators: %d: images */ __( '%d image(s) in the text have no alt text.', 'wp-astro' ), $no_alt ) : __( 'Set a featured image and add images with alt text.', 'wp-astro' ) );

		// 5. Heading structure.
		$h2 = preg_match_all( '/<h2\b/i', $html );
		$h1 = preg_match( '/<h1\b/i', $html );
		$add( __( 'Heading structure', 'wp-astro' ), ( $h2 >= 3 ? 10 : ( $h2 >= 1 ? 5 : 0 ) ) + ( $h1 ? 0 : 5 ), 15, $h1 ? __( 'Remove H1 headings from the text — the title is the H1.', 'wp-astro' ) : __( 'Use at least three H2 sections.', 'wp-astro' ) );

		// 6. FAQ: a custom list or the FAQ section of the text (see Faq).
		$faq_n      = count( Faq::effective( $p )['items'] );
		$faq_points = $faq_n >= 3 ? 15 : ( $faq_n >= 1 ? 8 : 0 );
		$add( __( 'FAQ section', 'wp-astro' ), $faq_points, 15, __( 'Add at least three FAQ questions (the FAQ column in the Articles table) — they become FAQ structured data.', 'wp-astro' ) );

		// 7. Links & sources.
		$home     = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$internal = 0;
		if ( preg_match_all( '/<a\b[^>]*href=("|\')([^"\']+)\1/i', $html, $links ) ) {
			foreach ( $links[2] as $href ) {
				$host = wp_parse_url( $href, PHP_URL_HOST );
				if ( null === $host || $host === $home ) {
					++$internal;
				}
			}
		}
		$has_sources = (bool) preg_match( '/(?:Sources Cited From|Sources|References)\s*:?\s*<\/(?:p|h[23]|strong|b)>/i', $html );
		$add( __( 'Links & sources', 'wp-astro' ), ( $internal >= 2 ? 5 : 0 ) + ( $has_sources ? 5 : 0 ), 10, __( 'Link to at least two related pages, and end with a “Sources Cited From” list.', 'wp-astro' ) );

		// 8. A short answer paragraph (the TL;DR box) and taxonomy.
		$el   = mb_strlen( $excerpt );
		$tax  = ( has_category( '', $p ) || has_tag( '', $p ) ) && ! ( 1 === count( wp_get_post_categories( $p->ID ) ) && in_array( (int) get_option( 'default_category' ), wp_get_post_categories( $p->ID ), true ) && ! has_tag( '', $p ) );
		$add( __( 'Answer paragraph & topics', 'wp-astro' ), ( $el >= 120 && $el <= 320 ? 5 : ( $el > 0 ? 2 : 0 ) ) + ( $tax ? 5 : 0 ), 10, __( 'Write a 120–320 character excerpt (shown as the TL;DR answer) and set a category or tags.', 'wp-astro' ) );

		// 9. Readability: no wall-of-text paragraphs.
		$long = 0;
		if ( preg_match_all( '/<p\b[^>]*>([\s\S]*?)<\/p>/i', $html, $paras ) ) {
			foreach ( $paras[1] as $para ) {
				if ( str_word_count( wp_strip_all_tags( $para ) ) > 150 ) {
					++$long;
				}
			}
		}
		$add( __( 'Readability', 'wp-astro' ), 0 === $long ? 5 : 0, 5, __( 'Split paragraphs longer than 150 words.', 'wp-astro' ) );

		$total = (int) array_sum( array_column( $checks, 'points' ) );
		return [
			'score'  => $total,
			'grade'  => $total >= 90 ? 'great' : ( $total >= 75 ? 'good' : ( $total >= 50 ? 'average' : 'poor' ) ),
			'checks' => $checks,
		];
	}
}
