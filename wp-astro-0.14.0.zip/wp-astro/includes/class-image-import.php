<?php
/**
 * Image_Import — after posts were imported from another site (WordPress export/import without the
 * media), copy the images they use into this site's media library, fix the links in the text and set
 * the featured images. Works in small steps so it never hits a time limit; safe to run again.
 *
 * Flow: scan() lists what is missing → run() copies a few at a time (the admin screen calls it in a loop).
 * Links are fixed straight in the database, so "Updated on" dates do not change and no rebuild is queued.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Image_Import {

	public const OPT_SOURCE = 'wp_astro_import_source';
	public const OPT_QUEUE  = 'wp_astro_import_queue';
	public const OPT_DONE   = 'wp_astro_import_done';
	private const META_SRC  = '_wp_astro_source_url';

	public static function source(): string {
		return rtrim( (string) get_option( self::OPT_SOURCE, '' ), '/' );
	}

	public static function set_source( string $url ): void {
		$url = esc_url_raw( trim( $url ) );
		update_option( self::OPT_SOURCE, preg_match( '#^https?://#i', $url ) ? rtrim( $url, '/' ) : '', false );
	}

	/** @return array{source:string,queue:int,copied:int,failed:array<int,array{what:string,reason:string}>,scanned:int} */
	public static function state(): array {
		$d = get_option( self::OPT_DONE );
		$d = is_array( $d ) ? $d : [];
		return [
			'source'  => self::source(),
			'queue'   => count( (array) get_option( self::OPT_QUEUE, [] ) ),
			'copied'  => (int) ( $d['copied'] ?? 0 ),
			'failed'  => array_slice( (array) ( $d['failed'] ?? [] ), -50 ),
			'scanned' => (int) ( $d['scanned'] ?? 0 ),
		];
	}

	/* ------------------------------------------------------------------ scan */

	/** Find every image the articles use that is not in this site's uploads folder. */
	public static function scan(): array {
		$ids   = get_posts(
			[
				'post_type'        => Meta::post_types(),
				'post_status'      => [ 'publish', 'draft', 'pending', 'private', 'future' ],
				'numberposts'      => -1,
				'fields'           => 'ids',
				'suppress_filters' => true,
			]
		);
		$queue = [];
		$body  = 0;
		foreach ( $ids as $id ) {
			$content = (string) get_post_field( 'post_content', $id );
			if ( preg_match_all( '/<img\b[^>]*>/i', $content, $m ) ) {
				$seen = [];
				foreach ( $m[0] as $tag ) {
					if ( ! preg_match( '/\ssrc=("|\')(.*?)\1/i', $tag, $s ) ) {
						continue;
					}
					$url = html_entity_decode( $s[2] );
					if ( isset( $seen[ $url ] ) || ! self::is_upload_url( $url ) || self::exists_locally( $url ) ) {
						continue;
					}
					$seen[ $url ] = true;
					$queue[]      = [ 'post' => (int) $id, 'kind' => 'body', 'url' => $url ];
					++$body;
				}
			}
			if ( ! self::has_featured( (int) $id ) ) {
				$queue[] = [ 'post' => (int) $id, 'kind' => 'featured', 'url' => '' ];
			}
		}
		update_option( self::OPT_QUEUE, $queue, false );
		update_option( self::OPT_DONE, [ 'copied' => 0, 'failed' => [], 'scanned' => count( $ids ) ], false );
		return [ 'posts' => count( $ids ), 'body' => $body, 'featured' => count( $queue ) - $body ];
	}

	private static function is_upload_url( string $url ): bool {
		return (bool) preg_match( '#^https?://[^/]+/(?:wp-content/)?uploads/#i', $url );
	}

	/** Path inside the uploads folder, e.g. "2026/10/photo.png". */
	private static function upload_path( string $url ): string {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return rawurldecode( (string) preg_replace( '#^/(?:wp-content/)?uploads/#i', '', $path ) );
	}

	private static function exists_locally( string $url ): bool {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		if ( $host !== (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) {
			return false; // another site's address: the file is not ours yet
		}
		$up   = wp_get_upload_dir();
		$file = $up['basedir'] . '/' . self::upload_path( $url );
		return is_file( $file ) && false === strpos( self::upload_path( $url ), '..' );
	}

	private static function has_featured( int $post_id ): bool {
		$tid = (int) get_post_thumbnail_id( $post_id );
		if ( $tid <= 0 ) {
			return false;
		}
		$file = get_attached_file( $tid );
		return $file && is_file( $file );
	}

	/* ------------------------------------------------------------------- run */

	/** Copy images for up to $seconds seconds. @return array{remaining:int,copied:int,failed:int} */
	public static function run( int $seconds = 18 ): array {
		$queue = (array) get_option( self::OPT_QUEUE, [] );
		$done  = get_option( self::OPT_DONE );
		$done  = is_array( $done ) ? $done : [ 'copied' => 0, 'failed' => [], 'scanned' => 0 ];
		$start = microtime( true );
		$n_ok  = 0;
		$n_bad = 0;

		while ( $queue && ( microtime( true ) - $start ) < $seconds ) {
			$item = array_shift( $queue );
			$res  = 'featured' === $item['kind'] ? self::do_featured( (int) $item['post'] ) : self::do_body( (int) $item['post'], (string) $item['url'] );
			if ( true === $res ) {
				++$n_ok;
			} elseif ( null !== $res ) { // null = nothing to do for this item
				++$n_bad;
				$done['failed'][] = [
					'what'   => 'featured' === $item['kind'] ? 'Featured image of “' . get_the_title( (int) $item['post'] ) . '”' : $item['url'],
					'reason' => (string) $res,
				];
			}
		}
		$done['copied'] = (int) ( $done['copied'] ?? 0 ) + $n_ok;
		$done['failed'] = array_slice( (array) $done['failed'], -200 );
		update_option( self::OPT_QUEUE, $queue, false );
		update_option( self::OPT_DONE, $done, false );
		return [ 'remaining' => count( $queue ), 'copied' => $n_ok, 'failed' => $n_bad ];
	}

	/** @return true|string|null  true = copied, string = why it failed, null = nothing to do */
	private static function do_body( int $post_id, string $url ) {
		$src = self::source_url( $url );
		if ( '' === $src ) {
			return 'Set the address of the old site first.';
		}
		$att = self::fetch_original( $src, $post_id );
		if ( is_wp_error( $att ) ) {
			return self::reason( $att );
		}
		global $wpdb;
		$content = (string) get_post_field( 'post_content', $post_id );
		$new     = (string) wp_get_attachment_url( $att );
		$alt     = '';
		$content = (string) preg_replace_callback(
			'/<img\b[^>]*>/i',
			static function ( $m ) use ( $url, $new, $att, &$alt ) {
				$tag = $m[0];
				if ( false === strpos( html_entity_decode( $tag ), $url ) ) {
					return $tag;
				}
				if ( preg_match( '/\salt=("|\')(.*?)\1/i', $tag, $a ) ) {
					$alt = html_entity_decode( $a[2] );
				}
				// the size the editor chose, from "-1024x567" in the old file name
				if ( preg_match( '/-(\d+)x(\d+)\.[a-z0-9]+$/i', (string) wp_parse_url( $url, PHP_URL_PATH ), $d ) && ! preg_match( '/\swidth=/i', $tag ) ) {
					$tag = (string) preg_replace( '/<img\b/i', '<img width="' . (int) $d[1] . '" height="' . (int) $d[2] . '"', $tag, 1 );
				}
				$tag = str_replace( [ htmlspecialchars( $url ), $url ], $new, $tag );
				$tag = (string) preg_replace( '/\s(?:srcset|sizes)=("|\').*?\1/i', '', $tag );
				return (string) preg_replace( '/wp-image-\d+/', 'wp-image-' . $att, $tag );
			},
			$content
		);
		$content = str_replace( [ 'href="' . $url . '"', "href='" . $url . "'" ], 'href="' . $new . '"', $content ); // a link around the picture
		if ( '' !== $alt && '' === (string) get_post_meta( $att, '_wp_attachment_image_alt', true ) ) {
			update_post_meta( $att, '_wp_attachment_image_alt', wp_slash( sanitize_text_field( $alt ) ) );
		}
		// straight to the database: no "Updated" date change, no rebuild queued by save_post
		$wpdb->update( $wpdb->posts, [ 'post_content' => $content ], [ 'ID' => $post_id ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		clean_post_cache( $post_id );
		return true;
	}

	/** @return true|string|null */
	private static function do_featured( int $post_id ) {
		$source = self::source();
		$slug   = (string) get_post_field( 'post_name', $post_id );
		if ( '' === $source || '' === $slug ) {
			return null;
		}
		$res = wp_safe_remote_get( $source . '/wp-json/wp/v2/posts?slug=' . rawurlencode( $slug ) . '&_fields=featured_media', [ 'timeout' => 20 ] );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return null; // the old site does not answer for this article: nothing to copy
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$mid  = (int) ( $data[0]['featured_media'] ?? 0 );
		if ( $mid <= 0 ) {
			return null; // the article had no featured image
		}
		$res = wp_safe_remote_get( $source . '/wp-json/wp/v2/media/' . $mid . '?_fields=source_url,alt_text', [ 'timeout' => 20 ] );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return 'The old site did not give the featured image (media ' . $mid . ').';
		}
		$media = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $media ) || empty( $media['source_url'] ) ) {
			return 'The old site did not give the featured image (media ' . $mid . ').';
		}
		$att = self::fetch_original( (string) $media['source_url'], $post_id );
		if ( is_wp_error( $att ) ) {
			return self::reason( $att );
		}
		if ( ! empty( $media['alt_text'] ) ) {
			update_post_meta( $att, '_wp_attachment_image_alt', wp_slash( sanitize_text_field( (string) $media['alt_text'] ) ) );
		}
		set_post_thumbnail( $post_id, $att );
		return true;
	}

	/** A short, readable reason for the report. */
	private static function reason( \WP_Error $e ): string {
		$m = $e->get_error_message();
		if ( false !== stripos( $m, 'valid URL' ) || false !== stripos( $m, 'could not resolve' ) || false !== stripos( $m, 'name or service' ) ) {
			return 'The old site could not be reached.';
		}
		return $m;
	}

	/** Where to download a link found in an article: the same path on the old site. */
	private static function source_url( string $url ): string {
		$source = self::source();
		if ( '' === $source ) {
			return '';
		}
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		if ( $host === (string) wp_parse_url( $source, PHP_URL_HOST ) ) {
			return $url; // it already points at the old site
		}
		return $source . '/uploads/' . str_replace( '%2F', '/', rawurlencode( self::upload_path( $url ) ) );
	}

	/**
	 * Download the full-size original (a "-1024x567" size suffix is removed first; the sized file is the
	 * fallback) into the media library. The same file is never copied twice.
	 *
	 * @return int|\WP_Error attachment id
	 */
	private static function fetch_original( string $src, int $post_id ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$orig = (string) preg_replace( '/-\d+x\d+(\.[a-z0-9]+)(\?.*)?$/i', '$1', $src );
		foreach ( array_unique( [ $orig, $src ] ) as $try ) {
			$known = get_posts( [ 'post_type' => 'attachment', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => self::META_SRC, 'meta_value' => $try ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
			if ( $known ) {
				return (int) $known[0];
			}
		}
		$last = new \WP_Error( 'wp_astro_img', 'download failed' );
		foreach ( array_unique( [ $orig, $src ] ) as $try ) {
			$tmp = download_url( $try, 40 );
			if ( is_wp_error( $tmp ) ) {
				$last = $tmp;
				continue;
			}
			$name = sanitize_file_name( rawurldecode( basename( (string) wp_parse_url( $try, PHP_URL_PATH ) ) ) );
			$id   = media_handle_sideload( [ 'name' => $name, 'tmp_name' => $tmp ], $post_id );
			if ( is_wp_error( $id ) ) {
				@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
				$last = $id;
				continue;
			}
			update_post_meta( $id, self::META_SRC, wp_slash( $try ) );
			return (int) $id;
		}
		return $last;
	}
}
