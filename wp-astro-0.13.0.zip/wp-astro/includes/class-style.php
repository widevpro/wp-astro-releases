<?php
/**
 * Style — the "Styles" settings tab: brand colours (→ CSS custom properties, same
 * keys as the frontend's theme.json), the browser theme colour, and an optional
 * block of custom CSS. Served inside GET /wp-astro/v1/config as `style`; the build
 * merges the colours over theme.json and inlines the CSS in <head>. A blank colour
 * keeps the theme.json default. Fonts stay in theme.json (they drive the preloads
 * that keep the Lighthouse score at 100).
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Style {

	public const OPTION = 'wp_astro_style';
	public const GROUP  = 'wp_astro_style_group';

	private const MAX_CSS = 20000;

	public static function init(): void {
		add_action( 'admin_init', [ __CLASS__, 'register' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
	}

	public static function register(): void {
		register_setting(
			self::GROUP,
			self::OPTION,
			[
				'sanitize_callback' => [ __CLASS__, 'sanitize' ],
				'default'           => [],
			]
		);
	}

	public static function enqueue( string $hook ): void {
		if ( 'settings' !== Settings::screen() || 'styles' !== Settings::current_tab() ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".wpa-color").wpColorPicker();});' );
	}

	/** Colour keys = theme.json `colors` keys. */
	public static function colors(): array {
		return [
			'base'     => __( 'Base (text, dark surfaces)', 'wp-astro' ),
			'cta'      => __( 'Button', 'wp-astro' ),
			'ctaHover' => __( 'Button hover', 'wp-astro' ),
			'ctaInk'   => __( 'Button colour used as text/links', 'wp-astro' ),
			'ctaText'  => __( 'Text on buttons', 'wp-astro' ),
			'accent'   => __( 'Accent', 'wp-astro' ),
		];
	}

	/** Saved values: [ 'colors' => [...], 'headerGradient' => '', 'themeColor' => '', 'css' => '' ] (blanks dropped). */
	public static function stored(): array {
		$v = get_option( self::OPTION, [] );
		return is_array( $v ) ? $v : [];
	}

	public static function sanitize( $input ): array {
		$in  = is_array( $input ) ? wp_unslash( $input ) : [];
		$out = [];

		foreach ( array_keys( self::colors() ) as $key ) {
			$hex = sanitize_hex_color( trim( (string) ( $in['colors'][ $key ] ?? '' ) ) );
			if ( $hex ) {
				$out['colors'][ $key ] = $hex;
			}
		}

		$grad = trim( (string) ( $in['headerGradient'] ?? '' ) );
		if ( '' !== $grad && strlen( $grad ) <= 300 && preg_match( '/^(linear|radial)-gradient\([#0-9a-zA-Z%.,()\s\-]+\)$/', $grad ) ) {
			$out['colors']['headerGradient'] = $grad;
		} elseif ( '' !== $grad ) {
			add_settings_error( self::OPTION, 'wp_astro_gradient', __( 'Header gradient ignored: use a CSS linear-gradient(…) or radial-gradient(…) with colours only.', 'wp-astro' ), 'warning' );
		}

		$theme = sanitize_hex_color( trim( (string) ( $in['themeColor'] ?? '' ) ) );
		if ( $theme ) {
			$out['themeColor'] = $theme;
		}

		$css = wp_strip_all_tags( (string) ( $in['css'] ?? '' ) );
		$css = preg_replace( '/@import[^;]*;?/i', '', $css ) ?? '';
		$css = preg_replace( '/expression\s*\(|behavior\s*:/i', '', $css ) ?? '';
		$css = trim( function_exists( 'mb_substr' ) ? mb_substr( $css, 0, self::MAX_CSS ) : substr( $css, 0, self::MAX_CSS ) );
		if ( '' !== $css ) {
			$out['css'] = $css;
		}

		self::contrast_warnings( $out['colors'] ?? [] );

		return $out;
	}

	/** Non-blocking WCAG AA (4.5:1) checks for the pairs the templates actually use. */
	private static function contrast_warnings( array $c ): void {
		$pairs = [
			[ 'ctaInk', '#ffffff', __( 'Button-as-text colour on white', 'wp-astro' ) ],
			[ 'base', '#ffffff', __( 'Base colour on white', 'wp-astro' ) ],
		];
		foreach ( $pairs as [ $key, $bg, $label ] ) {
			if ( isset( $c[ $key ] ) && self::contrast( $c[ $key ], $bg ) < 4.5 ) {
				self::warn( $label, self::contrast( $c[ $key ], $bg ) );
			}
		}
		if ( isset( $c['ctaText'], $c['cta'] ) && self::contrast( $c['ctaText'], $c['cta'] ) < 4.5 ) {
			self::warn( __( 'Text on buttons vs button colour', 'wp-astro' ), self::contrast( $c['ctaText'], $c['cta'] ) );
		}
	}

	private static function warn( string $label, float $ratio ): void {
		add_settings_error(
			self::OPTION,
			'wp_astro_contrast_' . sanitize_key( $label ),
			sprintf(
				/* translators: 1: colour pair, 2: contrast ratio */
				__( 'Low contrast — %1$s is %2$s:1 (WCAG AA needs 4.5:1; this can lower the accessibility score).', 'wp-astro' ),
				$label,
				number_format_i18n( $ratio, 2 )
			),
			'warning'
		);
	}

	/** WCAG contrast ratio of two #rgb / #rrggbb colours. */
	private static function contrast( string $a, string $b ): float {
		$la = self::luminance( $a );
		$lb = self::luminance( $b );
		return ( max( $la, $lb ) + 0.05 ) / ( min( $la, $lb ) + 0.05 );
	}

	private static function luminance( string $hex ): float {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$rgb = array_map(
			static function ( $v ) {
				$v = hexdec( $v ) / 255;
				return $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
			},
			str_split( $hex, 2 )
		);
		return 0.2126 * $rgb[0] + 0.7152 * $rgb[1] + 0.0722 * $rgb[2];
	}

	public static function render(): void {
		$s = self::stored();
		$o = esc_attr( self::OPTION );
		?>
		<form method="post" action="options.php">
			<?php settings_fields( self::GROUP ); ?>
			<p class="description" style="max-width:60em">
				<?php esc_html_e( 'Brand colours become CSS variables on every HTML page. A blank colour keeps the default from the site’s theme.json. Saving triggers a rebuild; there is no runtime cost.', 'wp-astro' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<?php foreach ( self::colors() as $key => $label ) : ?>
					<tr>
						<th scope="row"><label for="wpa-c-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td><input type="text" class="wpa-color" id="wpa-c-<?php echo esc_attr( $key ); ?>" name="<?php echo $o; ?>[colors][<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $s['colors'][ $key ] ?? '' ); ?>"></td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th scope="row"><label for="wpa-grad"><?php esc_html_e( 'Header gradient', 'wp-astro' ); ?></label></th>
					<td>
						<input type="text" id="wpa-grad" class="large-text code" name="<?php echo $o; ?>[headerGradient]" value="<?php echo esc_attr( $s['colors']['headerGradient'] ?? '' ); ?>" placeholder="linear-gradient(135deg, #0b3450 0%, #0b5da5 100%)">
						<p class="description"><?php esc_html_e( 'A CSS linear-gradient(…) or radial-gradient(…).', 'wp-astro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="wpa-theme"><?php esc_html_e( 'Browser theme colour', 'wp-astro' ); ?></label></th>
					<td><input type="text" class="wpa-color" id="wpa-theme" name="<?php echo $o; ?>[themeColor]" value="<?php echo esc_attr( $s['themeColor'] ?? '' ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="wpa-css"><?php esc_html_e( 'Custom CSS', 'wp-astro' ); ?></label></th>
					<td>
						<textarea id="wpa-css" class="large-text code" rows="10" name="<?php echo $o; ?>[css]"><?php echo esc_textarea( $s['css'] ?? '' ); ?></textarea>
						<p class="description"><?php printf( /* translators: %s: max characters */ esc_html__( 'Plain CSS, inlined in <head> after the theme variables. Max %s characters; @import is removed (an extra request would cost speed).', 'wp-astro' ), esc_html( number_format_i18n( self::MAX_CSS ) ) ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}
}
