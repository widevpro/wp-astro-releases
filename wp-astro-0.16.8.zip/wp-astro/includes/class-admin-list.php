<?php
/**
 * Admin_List — the posts list screen: a "Render" column showing WordPress /
 * Astro / Astro · Front / Astro · Full-width, and bulk actions to switch a
 * selection between engines.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin_List {

	private const COL = 'wp_astro';

	public static function init(): void {
		add_action( 'admin_init', [ __CLASS__, 'hook_post_types' ] );
		add_action( 'admin_notices', [ __CLASS__, 'bulk_notice' ] );
		add_filter( 'removable_query_args', [ __CLASS__, 'removable_args' ] );
	}

	public static function hook_post_types(): void {
		foreach ( Meta::post_types() as $type ) {
			add_filter( "manage_{$type}_posts_columns", [ __CLASS__, 'add_column' ] );
			add_action( "manage_{$type}_posts_custom_column", [ __CLASS__, 'render_column' ], 10, 2 );
			add_filter( "bulk_actions-edit-{$type}", [ __CLASS__, 'bulk_actions' ] );
			add_filter( "handle_bulk_actions-edit-{$type}", [ __CLASS__, 'handle_bulk' ], 10, 3 );
		}
	}

	public static function add_column( array $cols ): array {
		$out = [];
		foreach ( $cols as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'title' === $key ) {
				$out[ self::COL ] = __( 'Render', 'wp-astro' );
			}
		}
		return $out;
	}

	public static function render_column( string $col, int $post_id ): void {
		if ( self::COL !== $col ) {
			return;
		}
		if ( Meta::ASTRO !== Meta::get( $post_id ) ) {
			echo '<span style="color:#787c82">' . esc_html__( 'WordPress', 'wp-astro' ) . '</span>';
			return;
		}
		echo '<strong>' . esc_html__( 'HTML', 'wp-astro' ) . '</strong>';
		$role = Meta::get_role( $post_id );
		if ( Meta::ROLE_FRONT === $role ) {
			echo ' · <span style="color:#2271b1">' . esc_html__( 'Front', 'wp-astro' ) . '</span>';
		} elseif ( Meta::ROLE_FULL_WIDTH === $role ) {
			echo ' · <span style="color:#2271b1">' . esc_html__( 'Full-width', 'wp-astro' ) . '</span>';
		}
	}

	public static function bulk_actions( array $actions ): array {
		$actions['wp_astro_astro']     = __( 'Render with HTML', 'wp-astro' );
		$actions['wp_astro_wordpress'] = __( 'Render with WordPress', 'wp-astro' );
		return $actions;
	}

	public static function handle_bulk( string $redirect, string $action, array $ids ): string {
		if ( ! in_array( $action, [ 'wp_astro_astro', 'wp_astro_wordpress' ], true ) ) {
			return $redirect;
		}
		$engine = 'wp_astro_astro' === $action ? Meta::ASTRO : Meta::WORDPRESS;
		$done   = 0;
		foreach ( $ids as $id ) {
			if ( current_user_can( 'edit_post', $id ) ) {
				Meta::set( (int) $id, $engine );
				++$done;
			}
		}
		if ( $done ) {
			Trigger::queue();
			Serve::purge_all();
		}
		return add_query_arg( [ 'wp_astro_bulk' => $engine, 'wp_astro_n' => $done ], $redirect );
	}

	public static function bulk_notice(): void {
		if ( empty( $_GET['wp_astro_bulk'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$engine = sanitize_key( wp_unslash( $_GET['wp_astro_bulk'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$n      = (int) ( $_GET['wp_astro_n'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: 1: number of posts, 2: engine name */
					_n( '%1$d post now rendered with %2$s.', '%1$d posts now rendered with %2$s.', $n, 'wp-astro' ),
					$n,
					Meta::ASTRO === $engine ? 'Astro' : 'WordPress'
				)
			)
		);
	}

	public static function removable_args( array $args ): array {
		$args[] = 'wp_astro_bulk';
		$args[] = 'wp_astro_n';
		return $args;
	}
}
