<?php
/**
 * Netlify — creates the Netlify site for this WordPress site ("Connect Netlify").
 * The access token is used for this one request and never stored: the build itself runs
 * in GitHub Actions (.github/workflows/build-blog.yml), which holds its own token as a
 * repository secret, so Netlify needs no access to the GitHub repository.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Netlify {

	private const API = 'https://api.netlify.com/api/v1';

	/** A sensible default site name from this site's address, e.g. "sdaajodv-blog". */
	public static function suggested_name(): string {
		$host  = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$first = explode( '.', $host )[0] ?? 'site';
		$name  = trim( sanitize_title( $first ) . '-blog', '-' );
		return substr( $name, 0, 50 );
	}

	/**
	 * Create (or find) the site on the account the token belongs to.
	 *
	 * @return array{id:string,name:string,url:string,admin_url:string,account:string}|\WP_Error
	 */
	public static function create_site( string $token, string $name ) {
		$token = trim( $token );
		$name  = sanitize_title( $name );
		if ( '' === $token ) {
			return new \WP_Error( 'wp_astro_netlify_token', __( 'Paste a Netlify access token first.', 'wp-astro' ), [ 'status' => 400 ] );
		}
		if ( '' === $name ) {
			return new \WP_Error( 'wp_astro_netlify_name', __( 'Choose a site name (letters, numbers and dashes).', 'wp-astro' ), [ 'status' => 400 ] );
		}

		$accounts = self::request( 'GET', '/accounts', $token );
		if ( is_wp_error( $accounts ) ) {
			return $accounts;
		}
		$slug = (string) ( $accounts[0]['slug'] ?? '' );
		if ( '' === $slug ) {
			return new \WP_Error( 'wp_astro_netlify_account', __( 'This token has no Netlify team. Create the token while signed in to the right account.', 'wp-astro' ), [ 'status' => 400 ] );
		}

		// A name is global on Netlify; if it is taken, retry once with a short suffix.
		foreach ( [ $name, $name . '-' . strtolower( wp_generate_password( 4, false ) ) ] as $try ) {
			$site = self::request( 'POST', '/' . rawurlencode( $slug ) . '/sites', $token, [ 'name' => $try ] );
			if ( ! is_wp_error( $site ) ) {
				return [
					'id'        => (string) $site['id'],
					'name'      => (string) ( $site['name'] ?? $try ),
					'url'       => rtrim( (string) ( $site['ssl_url'] ?? $site['url'] ?? "https://$try.netlify.app" ), '/' ),
					'admin_url' => (string) ( $site['admin_url'] ?? '' ),
					'account'   => $slug,
				];
			}
			if ( 422 !== (int) ( $site->get_error_data()['status'] ?? 0 ) ) {
				return $site; // not a "name taken" problem
			}
		}
		return new \WP_Error( 'wp_astro_netlify_taken', __( 'That site name is taken on Netlify. Try another one.', 'wp-astro' ), [ 'status' => 409 ] );
	}

	/** @return array|\WP_Error decoded JSON */
	private static function request( string $method, string $path, string $token, ?array $body = null ) {
		$res = wp_remote_request(
			self::API . $path,
			[
				'method'  => $method,
				'timeout' => 30,
				'headers' => [
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
					'User-Agent'    => 'wp-astro',
				],
				'body'    => null === $body ? null : wp_json_encode( $body ),
			]
		);
		if ( is_wp_error( $res ) ) {
			return new \WP_Error( 'wp_astro_netlify_http', $res->get_error_message(), [ 'status' => 502 ] );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( $code >= 200 && $code < 300 && is_array( $data ) ) {
			return $data;
		}
		if ( 401 === $code ) {
			return new \WP_Error( 'wp_astro_netlify_auth', __( 'Netlify did not accept this token. Create a new one under User settings → Applications → Personal access tokens.', 'wp-astro' ), [ 'status' => 401 ] );
		}
		$msg = is_array( $data ) ? (string) ( $data['message'] ?? wp_json_encode( $data['errors'] ?? $data ) ) : "HTTP $code";
		return new \WP_Error( 'wp_astro_netlify_api', $msg, [ 'status' => $code ?: 502 ] );
	}
}
