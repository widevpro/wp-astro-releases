<?php
/**
 * Updater — plugin updates without uploading zips. The release workflow publishes
 * `latest.json` and the installable zip to a public GitHub repo (default
 * widevpro/wp-astro-releases); this class tells WordPress about newer versions, so the
 * Plugins page shows "Update available" (and auto-updates work), and it powers the
 * "Update now" button on the Astro screens. Updating runs WordPress's own plugin upgrader,
 * which replaces the plugin files and leaves every saved setting and post untouched.
 *
 * Another source: define( 'WP_ASTRO_UPDATE_REPO', 'owner/repo' ) in wp-config.php.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Updater {

	private const DEFAULT_REPO = 'widevpro/wp-astro-releases';
	private const CACHE        = 'wp_astro_latest_release';

	public static function init(): void {
		add_filter( 'pre_set_site_transient_update_plugins', [ __CLASS__, 'inject' ] );
		add_filter( 'plugins_api', [ __CLASS__, 'details' ], 10, 3 );
		add_filter( 'plugin_action_links_' . plugin_basename( WP_ASTRO_FILE ), [ __CLASS__, 'row_link' ] );
		add_action( 'admin_post_wp_astro_check_update', [ __CLASS__, 'handle_check' ] );
		add_action( 'admin_notices', [ __CLASS__, 'checked_notice' ] );
	}

	public static function repo(): string {
		$repo = defined( 'WP_ASTRO_UPDATE_REPO' ) ? (string) constant( 'WP_ASTRO_UPDATE_REPO' ) : self::DEFAULT_REPO;
		return (string) apply_filters( 'wp_astro_update_repo', $repo );
	}

	public static function basename(): string {
		return plugin_basename( WP_ASTRO_FILE );
	}

	/**
	 * The newest published release: [ version, zip, released, changelog ] or null.
	 * Cached 6 hours (30 minutes after a failed check, so a GitHub hiccup is not retried on every page).
	 */
	public static function latest( bool $force = false ): ?array {
		if ( $force ) {
			delete_transient( self::CACHE );
		}
		$cached = get_transient( self::CACHE );
		if ( is_array( $cached ) ) {
			return empty( $cached['version'] ) ? null : $cached;
		}

		$repo = self::repo();
		$res  = wp_remote_get(
			"https://raw.githubusercontent.com/$repo/main/latest.json",
			[
				'timeout' => 10,
				'headers' => [ 'Accept' => 'application/json' ],
			]
		);
		$data = is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ? null : json_decode( (string) wp_remote_retrieve_body( $res ), true );

		$ok = is_array( $data )
			&& isset( $data['version'], $data['zip'] )
			&& preg_match( '/^\d+\.\d+\.\d+$/', (string) $data['version'] )
			&& 0 === strpos( (string) $data['zip'], "https://raw.githubusercontent.com/$repo/" ); // only ever download from the release repo

		if ( ! $ok ) {
			set_transient( self::CACHE, [ 'failed' => time() ], 30 * MINUTE_IN_SECONDS );
			return null;
		}
		$latest = [
			'version'   => (string) $data['version'],
			'zip'       => (string) $data['zip'],
			'released'  => (string) ( $data['released'] ?? '' ),
			'changelog' => (string) ( $data['changelog'] ?? '' ),
			'checked'   => time(),
		];
		set_transient( self::CACHE, $latest, 6 * HOUR_IN_SECONDS );
		return $latest;
	}

	/** @return array{current:string,latest:?string,available:bool,released:string,changelog:string,checked:int} */
	public static function status( bool $force = false ): array {
		$l = self::latest( $force );
		return [
			'current'   => WP_ASTRO_VERSION,
			'latest'    => $l['version'] ?? null,
			'available' => $l && version_compare( $l['version'], WP_ASTRO_VERSION, '>' ),
			'released'  => (string) ( $l['released'] ?? '' ),
			'changelog' => (string) ( $l['changelog'] ?? '' ),
			'checked'   => (int) ( $l['checked'] ?? 0 ),
		];
	}

	/** Tell WordPress's update system (Plugins page, auto-updates) about the new version. */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$base   = self::basename();
		$latest = self::latest();
		$item   = (object) [
			'id'           => 'github.com/' . self::repo(),
			'slug'         => 'wp-astro',
			'plugin'       => $base,
			'new_version'  => $latest['version'] ?? WP_ASTRO_VERSION,
			'url'          => 'https://github.com/' . self::repo(),
			'package'      => $latest['zip'] ?? '',
			'requires'     => '6.4',
			'requires_php' => '8.1',
		];
		if ( $latest && version_compare( $latest['version'], WP_ASTRO_VERSION, '>' ) ) {
			$transient->response[ $base ] = $item;
		} else {
			$item->new_version           = WP_ASTRO_VERSION;
			$item->package               = '';
			$transient->no_update[ $base ] = $item; // lets the Plugins page offer the auto-update toggle
		}
		return $transient;
	}

	/** The "View details" pop-up on the Plugins page. */
	public static function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ( $args->slug ?? '' ) !== 'wp-astro' ) {
			return $result;
		}
		$l = self::latest();
		return (object) [
			'name'          => 'W-Blog',
			'slug'          => 'wp-astro',
			'version'       => $l['version'] ?? WP_ASTRO_VERSION,
			'author'        => 'webim',
			'homepage'      => 'https://github.com/' . self::repo(),
			'requires'      => '6.4',
			'requires_php'  => '8.1',
			'download_link' => $l['zip'] ?? '',
			'last_updated'  => $l['released'] ?? '',
			'sections'      => [
				'description' => esc_html__( 'Hands flagged WordPress posts to a static HTML build and serves them from your own domain.', 'wp-astro' ),
				'changelog'   => '<pre>' . esc_html( (string) ( $l['changelog'] ?? '' ) ) . '</pre>',
			],
		];
	}

	/** "Check for updates" next to Settings / Deactivate on the Plugins page. */
	public static function row_link( array $links ): array {
		$url     = wp_nonce_url( admin_url( 'admin-post.php?action=wp_astro_check_update' ), 'wp_astro_check_update' );
		$links[] = sprintf( '<a href="%s">%s</a>', esc_url( $url ), esc_html__( 'Check for updates', 'wp-astro' ) );
		return $links;
	}

	public static function handle_check(): void {
		if ( ! current_user_can( 'update_plugins' ) || ! check_admin_referer( 'wp_astro_check_update' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wp-astro' ) );
		}
		self::refresh();
		wp_safe_redirect( add_query_arg( 'wp_astro_checked', '1', wp_get_referer() ?: admin_url( 'plugins.php' ) ) );
		exit;
	}

	/** Forget the cache and let WordPress re-run its plugin update check. */
	public static function refresh(): array {
		self::latest( true );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
		return self::status();
	}

	public static function checked_notice(): void {
		if ( ! isset( $_GET['wp_astro_checked'] ) || ! current_user_can( 'update_plugins' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$s = self::status();
		if ( null === $s['latest'] ) {
			$msg  = __( 'W-Blog plugin: could not reach the update server. Try again later.', 'wp-astro' );
			$type = 'warning';
		} elseif ( $s['available'] ) {
			/* translators: 1: new version, 2: current version */
			$msg  = sprintf( __( 'W-Blog plugin %1$s is available (you have %2$s). Use “Update now” on the Plugins page or on the W-Blog screens.', 'wp-astro' ), $s['latest'], $s['current'] );
			$type = 'info';
		} else {
			/* translators: %s: version */
			$msg  = sprintf( __( 'W-Blog plugin is up to date (%s).', 'wp-astro' ), $s['current'] );
			$type = 'success';
		}
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), esc_html( $msg ) );
	}

	/**
	 * "Update now" from the Astro screens: the same upgrader the Plugins page uses.
	 * Settings, flagged posts and the active state all stay as they were.
	 *
	 * @return array{version:string}|\WP_Error
	 */
	public static function run() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return new \WP_Error( 'wp_astro_forbidden', __( 'You are not allowed to update plugins.', 'wp-astro' ), [ 'status' => 403 ] );
		}
		$status = self::status( true );
		if ( ! $status['available'] ) {
			return new \WP_Error( 'wp_astro_no_update', __( 'There is no newer version.', 'wp-astro' ), [ 'status' => 400 ] );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/update.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		if ( 'direct' !== get_filesystem_method() ) {
			return new \WP_Error( 'wp_astro_fs', __( 'This server asks for FTP details to change files. Update from the Plugins page instead.', 'wp-astro' ), [ 'status' => 400 ] );
		}
		self::refresh();

		$base     = self::basename();
		$was_on   = is_plugin_active( $base );
		$skin     = new \WP_Ajax_Upgrader_Skin();
		$upgrader = new \Plugin_Upgrader( $skin );
		$result   = $upgrader->upgrade( $base );

		// The upgrader switches the plugin off before it installs; success or failure, put it back.
		if ( $was_on && ! is_plugin_active( $base ) && file_exists( WP_PLUGIN_DIR . '/' . $base ) ) {
			activate_plugin( $base, '', false, true );
		}

		if ( is_wp_error( $result ) ) {
			return new \WP_Error( 'wp_astro_upgrade', $result->get_error_message(), [ 'status' => 500 ] );
		}
		if ( ! $result ) {
			$errors = $skin->get_errors();
			$msg    = is_wp_error( $errors ) && $errors->has_errors() ? $errors->get_error_message() : __( 'The update did not complete.', 'wp-astro' );
			return new \WP_Error( 'wp_astro_upgrade', $msg, [ 'status' => 500 ] );
		}
		return [ 'version' => (string) $status['latest'] ];
	}
}
