<?php
/**
 * Trigger — asks the build pipeline to rebuild the static site when content that
 * affects it changes. Debounced: a burst of edits collapses into one build.
 *
 * Modes (Settings): none | github (repository_dispatch) | webhook (POST a URL) | both.
 * When it fires (Settings → publish_mode): auto = a minute after a save; idle = 10 minutes after the
 * last edit; manual = only when someone clicks Publish. Edits are collected as "pending" until then.
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Trigger {

	public const CRON     = 'wp_astro_do_rebuild';
	public const LAST_OPT = 'wp_astro_last_dispatch';
	public const QUEUED_T = 'wp_astro_rebuild_queued';
	public const STATUS   = 'wp_astro_build_status';
	public const PENDING  = 'wp_astro_pending';

	private const IDLE_SECONDS = 10 * MINUTE_IN_SECONDS;

	/** A "building" status older than this with no callback is shown as unconfirmed. */
	private const STALE_AFTER = 30 * MINUTE_IN_SECONDS;

	public static function init(): void {
		add_action( 'transition_post_status', [ __CLASS__, 'on_transition' ], 10, 3 );
		add_action( 'save_post', [ __CLASS__, 'on_save' ], 20, 2 );
		add_action( 'wp_update_nav_menu', [ __CLASS__, 'queue_site' ] );
		add_action( 'updated_post_meta', [ __CLASS__, 'on_meta' ], 10, 3 );
		add_action( 'added_post_meta', [ __CLASS__, 'on_meta' ], 10, 3 );
		// Settings and the Content / Styles tabs all change the built pages.
		foreach ( [ Settings::OPTION, Content::OPTION, Style::OPTION ] as $opt ) {
			add_action( 'update_option_' . $opt, [ __CLASS__, 'queue_site' ] );
			add_action( 'add_option_' . $opt, [ __CLASS__, 'queue_site' ] );
		}

		add_action( self::CRON, [ __CLASS__, 'dispatch' ] );
		// WP-Cron only runs when WordPress itself serves a page, which cached hosts rarely do —
		// so any admin screen also starts a rebuild that is due.
		add_action( 'admin_init', [ __CLASS__, 'dispatch_if_due' ] );

		add_action( 'admin_post_wp_astro_rebuild', [ __CLASS__, 'handle_manual' ] );
		add_action( 'admin_notices', [ __CLASS__, 'maybe_notice' ] );
	}

	private static function debounce_seconds(): int {
		return (int) apply_filters( 'wp_astro_debounce_seconds', 60 );
	}

	public static function on_transition( $new_status, $old_status, $post ): void {
		if ( ! $post instanceof \WP_Post || ! in_array( $post->post_type, Meta::post_types(), true ) ) {
			return;
		}
		// Publishing or unpublishing an Astro post changes the static site.
		if ( ( 'publish' === $new_status || 'publish' === $old_status ) && Meta::ASTRO === Meta::get( $post->ID ) ) {
			self::queue( $post->ID );
		}
	}

	public static function on_save( $post_id, $post ): void {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( ! $post instanceof \WP_Post || ! in_array( $post->post_type, Meta::post_types(), true ) ) {
			return;
		}
		if ( 'publish' === $post->post_status && Meta::ASTRO === Meta::get( $post_id ) ) {
			self::queue( (int) $post_id );
		}
	}

	/** Flipping the engine/role of a published post changes the static site. */
	public static function on_meta( $meta_id, $post_id, $meta_key ): void {
		if ( ! in_array( $meta_key, [ Meta::KEY, Meta::ROLE_KEY ], true ) ) {
			return;
		}
		if ( 'publish' === get_post_status( (int) $post_id ) ) {
			self::queue( (int) $post_id );
		}
	}

	/** auto | idle | manual — when saved edits go live. */
	public static function publish_mode(): string {
		$m = (string) Settings::get( 'publish_mode' );
		return in_array( $m, [ 'auto', 'idle', 'manual' ], true ) ? $m : 'idle';
	}

	/**
	 * Start the rebuild if the waiting edits are due: idle = 10 minutes after the last edit,
	 * auto = a minute after it. Never in manual mode. Retries are spaced out when a request fails.
	 */
	public static function dispatch_if_due(): void {
		if ( 'none' === Settings::get( 'trigger_mode' ) || get_transient( 'wp_astro_dispatch_lock' ) ) {
			return;
		}
		$mode = self::publish_mode();
		if ( 'manual' === $mode ) {
			return;
		}
		$p = get_option( self::PENDING );
		if ( ! is_array( $p ) || empty( $p['last'] ) ) {
			return;
		}
		$wait = 'idle' === $mode ? self::IDLE_SECONDS : self::debounce_seconds();
		if ( time() - (int) $p['last'] < $wait ) {
			return;
		}
		set_transient( 'wp_astro_dispatch_lock', 1, 2 * MINUTE_IN_SECONDS );
		self::dispatch();
	}

	/** A change to the whole site (menu, Content, Styles, settings) rather than one article. */
	public static function queue_site(): void {
		self::queue( null );
	}

	/**
	 * Note an edit and, depending on the publish mode, schedule the rebuild.
	 * auto: one a minute after the first save of a burst; idle: pushed back to 10 minutes after the
	 * latest edit; manual: nothing is scheduled — someone clicks Publish.
	 */
	public static function queue( ?int $post_id = null ): void {
		if ( 'none' === Settings::get( 'trigger_mode' ) ) {
			return;
		}
		self::note_pending( $post_id );

		$mode = self::publish_mode();
		if ( 'manual' === $mode ) {
			return;
		}
		if ( 'idle' === $mode ) {
			wp_clear_scheduled_hook( self::CRON );
			wp_schedule_single_event( time() + self::IDLE_SECONDS, self::CRON );
		} elseif ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_single_event( time() + self::debounce_seconds(), self::CRON );
		}
		set_transient( self::QUEUED_T, time(), 15 * MINUTE_IN_SECONDS );
	}

	private static function note_pending( ?int $post_id ): void {
		$p = get_option( self::PENDING );
		$p = is_array( $p ) ? $p : [ 'posts' => [], 'site' => false, 'since' => time() ];
		if ( null === $post_id ) {
			$p['site'] = true;
		} else {
			$p['posts'] = array_values( array_unique( array_merge( (array) ( $p['posts'] ?? [] ), [ $post_id ] ) ) );
		}
		$p['last'] = time();
		update_option( self::PENDING, $p, false );
	}

	/**
	 * What is waiting to go live.
	 *
	 * @return array{count:int,posts:int[],site:bool,mode:string,runs_at:?int,since:int,now:int}
	 */
	public static function pending(): array {
		$p     = get_option( self::PENDING );
		$p     = is_array( $p ) ? $p : [];
		$posts = array_map( 'intval', (array) ( $p['posts'] ?? [] ) );
		$next  = wp_next_scheduled( self::CRON );
		return [
			'count'   => count( $posts ) + ( ! empty( $p['site'] ) ? 1 : 0 ),
			'posts'   => $posts,
			'site'    => ! empty( $p['site'] ),
			'mode'    => self::publish_mode(),
			'runs_at' => $next ? (int) $next : null,
			'since'   => (int) ( $p['since'] ?? 0 ),
			'now'     => time(),
		];
	}

	public static function handle_manual(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wp_astro_rebuild' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wp-astro' ) );
		}
		self::dispatch(); // immediate — bypass the debounce
		wp_safe_redirect(
			add_query_arg( 'wp_astro_rebuilt', '1', wp_get_referer() ?: Settings::page_url( [ 'tab' => 'deploy' ] ) )
		);
		exit;
	}

	/** Fire the outbound call(s). Runs from cron, or immediately from "Rebuild now". */
	public static function dispatch(): void {
		$mode = Settings::get( 'trigger_mode' );
		if ( 'none' === $mode ) {
			return;
		}

		delete_transient( self::QUEUED_T );
		wp_clear_scheduled_hook( self::CRON );
		$results = [];

		if ( in_array( $mode, [ 'github', 'both' ], true ) ) {
			$results['github'] = self::dispatch_github();
		}
		if ( in_array( $mode, [ 'webhook', 'both' ], true ) ) {
			$results['webhook'] = self::dispatch_webhook();
		}

		update_option(
			self::LAST_OPT,
			[
				'time'    => time(),
				'results' => $results,
			],
			false
		);

		$failed = array_filter( $results, static fn( $r ) => empty( $r['ok'] ) );
		if ( ! $failed ) {
			delete_option( self::PENDING ); // everything waiting is going out with this build
		}
		if ( $failed ) {
			$first = reset( $failed );
			self::set_status( 'failed', (string) ( $first['message'] ?? 'Rebuild request failed' ) );
		} else {
			self::set_status( 'building', '' );
		}
	}

	/**
	 * Record where the build is: building | success | failed. Written when we fire the
	 * trigger and again by the CI / Netlify callback (POST /wp-astro/v1/build-status).
	 */
	public static function set_status( string $state, string $message = '', string $url = '' ): void {
		if ( ! in_array( $state, [ 'building', 'success', 'failed' ], true ) ) {
			return;
		}
		update_option(
			self::STATUS,
			[
				'state'   => $state,
				'time'    => time(),
				'message' => substr( $message, 0, 300 ),
				'url'     => esc_url_raw( $url ),
			],
			false
		);
	}

	public static function status(): ?array {
		$v = get_option( self::STATUS );
		return is_array( $v ) && isset( $v['state'], $v['time'] ) ? $v : null;
	}

	/** Human line for the current build state, plus a notice class. */
	public static function status_line(): ?array {
		$st = self::status();
		if ( ! $st ) {
			return null;
		}
		$ago = human_time_diff( (int) $st['time'] );
		switch ( $st['state'] ) {
			case 'success':
				/* translators: %s: human time diff */
				return [ 'success', sprintf( __( 'Last build succeeded %s ago — changes are live.', 'wp-astro' ), $ago ) ];
			case 'failed':
				/* translators: 1: human time diff, 2: error message */
				return [ 'error', trim( sprintf( __( 'Last build failed %1$s ago. %2$s', 'wp-astro' ), $ago, (string) $st['message'] ) ) ];
			default:
				if ( time() - (int) $st['time'] > self::STALE_AFTER ) {
					/* translators: %s: human time diff */
					return [ 'warning', sprintf( __( 'Rebuild requested %s ago, but no build result has been received. Check Netlify / GitHub.', 'wp-astro' ), $ago ) ];
				}
				/* translators: %s: human time diff */
				return [ 'info', sprintf( __( 'Build in progress (requested %s ago)…', 'wp-astro' ), $ago ) ];
		}
	}

	private static function dispatch_github(): array {
		$owner = (string) Settings::get( 'github_owner' );
		$repo  = (string) Settings::get( 'github_repo' );
		$token = (string) Settings::get( 'github_token' );
		$event = (string) Settings::get( 'github_event_type' ) ?: 'wp-astro-rebuild';

		if ( '' === $owner || '' === $repo || '' === $token ) {
			return [
				'ok'      => false,
				'message' => 'GitHub owner / repo / token not all configured',
			];
		}

		$res = wp_remote_post(
			sprintf( 'https://api.github.com/repos/%s/%s/dispatches', rawurlencode( $owner ), rawurlencode( $repo ) ),
			[
				'timeout' => 15,
				'headers' => [
					'Accept'               => 'application/vnd.github+json',
					'Authorization'        => 'Bearer ' . $token,
					'X-GitHub-Api-Version' => '2022-11-28',
					'Content-Type'         => 'application/json',
					'User-Agent'           => 'wp-astro',
				],
				'body'    => wp_json_encode(
					[
						'event_type'     => $event,
						'client_payload' => [
							'source'          => 'wp-astro',
							'site'            => home_url( '/' ),
							'at'              => gmdate( 'c' ),
							// Read by .github/workflows/build-blog.yml
							'wp_url'          => untrailingslashit( home_url() ),
							'astro_site'      => (string) Settings::get( 'astro_site' ),
							'netlify_site_id' => (string) Settings::get( 'netlify_site_id' ),
							'netlify_url'     => (string) Settings::get( 'remote_origin' ),
							'status_url'      => Settings::build_status_url(),
							'purge_url'       => Settings::purge_url(),
						],
					]
				),
			]
		);

		if ( is_wp_error( $res ) ) {
			return [ 'ok' => false, 'message' => $res->get_error_message() ];
		}

		$code = (int) wp_remote_retrieve_response_code( $res );
		return [
			'ok'      => 204 === $code,
			'code'    => $code,
			'message' => 204 === $code ? 'dispatched' : substr( (string) wp_remote_retrieve_body( $res ), 0, 300 ),
		];
	}

	private static function dispatch_webhook(): array {
		$url = (string) Settings::get( 'webhook_url' );
		if ( '' === $url ) {
			return [ 'ok' => false, 'message' => 'Webhook URL not configured' ];
		}

		$res = wp_remote_post(
			$url,
			[
				'timeout' => 15,
				'headers' => [
					'Content-Type' => 'application/json',
					'User-Agent'   => 'wp-astro',
				],
				'body'    => wp_json_encode(
					[
						'source' => 'wp-astro',
						'site'   => home_url( '/' ),
						'at'     => gmdate( 'c' ),
					]
				),
			]
		);

		if ( is_wp_error( $res ) ) {
			return [ 'ok' => false, 'message' => $res->get_error_message() ];
		}

		$code = (int) wp_remote_retrieve_response_code( $res );
		return [
			'ok'   => $code >= 200 && $code < 300,
			'code' => $code,
		];
	}

	public static function last_dispatch(): ?array {
		$v = get_option( self::LAST_OPT );
		return is_array( $v ) ? $v : null;
	}

	public static function is_queued(): bool {
		return (bool) get_transient( self::QUEUED_T ) || (bool) wp_next_scheduled( self::CRON );
	}

	public static function maybe_notice(): void {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		if ( isset( $_GET['wp_astro_rebuilt'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				esc_html__( 'W-Blog: rebuild triggered.', 'wp-astro' )
			);
			return;
		}
		$line = self::status_line();
		if ( $line && in_array( $line[0], [ 'error', 'warning', 'info' ], true ) && ! self::is_queued() ) {
			printf(
				'<div class="notice notice-%1$s is-dismissible"><p>W-Blog: %2$s</p></div>',
				esc_attr( $line[0] ),
				esc_html( $line[1] )
			);
			return;
		}
		if ( null !== Settings::screen() ) {
			return; // W-Blog screens show their own "waiting to go live" bar
		}
		$p = self::pending();
		if ( $p['count'] > 0 && 'none' !== Settings::get( 'trigger_mode' ) ) {
			$publish = wp_nonce_url( admin_url( 'admin-post.php?action=wp_astro_rebuild' ), 'wp_astro_rebuild' );
			if ( 'auto' === $p['mode'] ) {
				$text = esc_html__( 'W-Blog: a static rebuild is queued — the updated page(s) should be live within ~1 minute.', 'wp-astro' );
			} else {
				$when = 'idle' === $p['mode'] && $p['runs_at'] ? sprintf(
					/* translators: %s: human time */
					esc_html__( 'going live automatically in %s', 'wp-astro' ),
					esc_html( human_time_diff( time(), (int) $p['runs_at'] ) )
				) : esc_html__( 'waiting until you publish', 'wp-astro' );
				$text = sprintf(
					/* translators: 1: number of changes, 2: when, 3: link */
					esc_html( _n( 'W-Blog: %1$d change saved, %2$s.', 'W-Blog: %1$d changes saved, %2$s.', $p['count'], 'wp-astro' ) ),
					(int) $p['count'],
					$when
				) . ' <a href="' . esc_url( $publish ) . '">' . esc_html__( 'Publish now', 'wp-astro' ) . '</a>';
			}
			echo '<div class="notice notice-info is-dismissible"><p>' . wp_kses( $text, [ 'a' => [ 'href' => true ] ] ) . '</p></div>';
		}
	}
}
