# Development flow

For the developer who builds, tests and releases W-Blog. The repository is a monorepo: the WordPress plugin, the admin screens (Vue) and the Astro front end live together, so one change can touch all three and ships in one release.

## The repository

| Folder | What it is |
| --- | --- |
| `plugin/` | The WordPress plugin (PHP). It is zipped and released exactly as it is, including the compiled admin screens. |
| `admin-ui/` | Source of the admin screens (Vue 3, TypeScript, Vite, Naive UI). `npm run build` writes into `plugin/assets/admin/`, which is committed. |
| `frontend/` | The Astro project that builds the static pages. Netlify's base folder. |
| `frontend/src/sites/<name>/` | The only place a client's own values live: `config.ts`, `theme.json` and `assets/`. |
| `scripts/` | Helpers: Netlify site setup, test content, plugin zip, design-variable sync. |
| `.github/workflows/` | `deploy.yml` (checks and optional rsync), `build-blog.yml` (build and deploy to Netlify), `release-plugin.yml` (plugin releases). |

## The golden rules

1. **Nothing client-specific outside the client's own folder.** A client is a folder in `frontend/src/sites/`, chosen by the `PUBLIC_SITE` variable. Never fork, and never write `if (site === 'x')` in a component.
2. **WordPress is the source of truth.** Content and settings live in WordPress. Netlify only holds disposable build output.
3. **An empty field prints nothing.** No empty tags, no stray commas, no built-in heading text that the editor did not type.
4. **One admin look.** Admin screens use the kit in `admin-ui/src/style.css` (tokens named `--wpa-*`). Never type raw colours in a component.
5. **Skins change values, never structure.** Layout and alignment live in the CSS; colours, sizes, radius and fonts are variables.
6. **Speed is a feature.** The targets are Lighthouse 100, CLS 0 and TBT 0. Check them before every release.

## The daily loop

1. **Branch** from `main`. There are no direct pushes to `main`.
2. **Run it locally.** Start the Astro dev server and, for admin changes, rebuild the admin app.
3. **Test the change end to end** (see below).
4. **Commit.** A commit hook runs prettier, eslint and stylelint on the front end files, so do not hand-format against another style.
5. **Open a pull request and merge it.**
6. **Release** when the plugin changed (see "Releasing").

## Running it locally

Each client keeps a local WordPress copy as a sibling repository (Docker). It mounts `plugin/`, so PHP edits are live. Current copies: `../dayo-staging` on port 8097 and `../blyssdental-staging-blog` on port 8096.

```
cd frontend
PUBLIC_SITE=dayo PUBLIC_WP_API_BASE=http://localhost:8097 PUBLIC_WP_SITE_URL=http://localhost:8097 npm run dev
```

The preview is `http://localhost:4321/<slug>/` (the trailing slash is required). The admin screens are rebuilt with `cd admin-ui && npm run build`, then reload the WordPress screen. Nothing local uses Netlify credits.

## Testing before you commit

| Check | Command |
| --- | --- |
| Front end types | `cd frontend && npx astro check` |
| Front end style | `npm run lint` (eslint, stylelint, prettier) |
| HTML validity of a build | `npm run build` then `npm run validate` |
| Admin types | `cd admin-ui && npx vue-tsc --noEmit` |
| PHP syntax | `php -l` on each file (run it inside the Docker container) |
| Design-variable list is current | `node scripts/sync-tokens.mjs --check` |

For a full test, fill every field (Content tab and an article), build, and read the result. Then repeat with every optional field empty, because nothing empty may be printed. Check phone, tablet and desktop widths, then run Lighthouse on a production build, not on the dev server.

## Common changes

| I want to… | Edit |
| --- | --- |
| add a client | copy `frontend/src/sites/dayo/`, set `PUBLIC_SITE`, create its Netlify site |
| add a site-wide field | `Content::schema()` in PHP, `content-schema.ts`, and `SiteConfig` |
| add a per-article field | `Article_Edit`, `types.ts`, `EditPage.vue`, then `wp.ts` and `article.ts` in the front end |
| add a design variable | `tokens.css` and `tokens.meta.json`, then run `node scripts/sync-tokens.mjs` and commit the result |
| change how a page looks | `frontend/src/styles/*.css` and `frontend/src/components/*` |

## Releasing the plugin

1. Raise the version in `plugin/wp-astro.php` in **both** places: the `Version:` header and `WP_ASTRO_VERSION`. They must match the tag.
2. Merge the pull request to `main`.
3. Tag the merge as `vX.Y.Z` and push the tag.
4. `release-plugin.yml` builds the zip and updates `latest.json` in the public releases repository (about 30 seconds). GitHub can show the old version for a few minutes.
5. On each site, open **W-Blog → Settings** and use **Check for updates**, then **Update**.
6. Publish a rebuild if the release changed how pages look.

## Test checklist before a release

- Every field filled, then every optional field empty.
- Sidebar page and full-width page, with and without a hero picture.
- Phone (375 px), tablet (768 px), desktop (1280 px and 1920 px).
- Lighthouse on a production build: performance, accessibility, best practices, SEO.
- A real run on staging after the update: update, publish, open the live page.

## Repositories and accounts

| Repository | Visibility | Purpose |
| --- | --- | --- |
| `widevpro/wp-astro` | private | The working repository. Git remote name `widevpro`. |
| `webimdeveloper/wp-astro` | private | The original repository. Git remote name `origin`. |
| `widevpro/wp-astro-releases` | public | Only plugin zips and `latest.json`. Sites check it for updates. |

The GitHub command line can hold several logins: `gh auth status` and `gh auth switch --user <name>`. Pushing a workflow file needs the `workflow` scope: `gh auth refresh -h github.com -s workflow`.

## Where the documentation lives

| File | For whom | What it holds |
| --- | --- | --- |
| `README.md` | Whoever sets up a client | Install, Netlify setup, the workflows, releasing, PageSpeed, troubleshooting |
| `DEVELOPER.md` | A developer joining the project | The idea, how the parts talk, local development, where to change what, gotchas |
| `CLAUDE.md` | The project rules | The one rule that matters most, architecture notes, "don't re-debug this" |
| `plugin/docs/*.md` | Editors and admins, inside WordPress | These Guide pages |

**These Guide pages ship inside the plugin zip, so they always describe the version that is running** (this one is {{version}}). Keep them true:

- Change the guide in the **same pull request** as the change it describes.
- Never type a plugin version number in a page; write `{{version}}` and the plugin fills it in.
- The page "Release history" is generated from the git tags and commit messages when a release is built (`scripts/changelog.mjs`), so write clear commit messages.
- `node scripts/check-docs.mjs` fails when a page names a file that no longer exists or hard-codes a version. CI runs it.

## Things that cost hours once

- `update_post_meta()` removes slashes from its value. Always pass `wp_slash()`ed JSON or HTML, or a `\"` is lost and the value saves empty.
- `register_setting()` cleaners do not run in REST requests. Clean explicitly in the route.
- WordPress invents an excerpt when the summary is empty. The build reads the real one from `astro_summary`. The summary and the meta description are different fields and never fall back to each other.
- If `PUBLIC_SITE` is missing the build uses Blyss. A wrongly named variable builds the wrong client.
- The admin build empties `plugin/assets/admin/`. Keep vendor files in `plugin/assets/vendor/`.
- WP-Cron is unreliable on cached hosts. Timed publishing is driven by the open admin screens.
- The FAQ must be extracted after the References, or a half section is left in the page (`frontend/src/lib/article.ts`). Run `npm run validate` after touching it.
- Draft posts never build. There is no preview for an unpublished HTML article.

## Developer troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| Push rejected: "refusing to allow an OAuth App to create or update workflow" | `gh auth refresh -h github.com -s workflow` |
| Release workflow: "Tag does not match the plugin version" | Raise both version places in `plugin/wp-astro.php` to the tag's number |
| Content or Styles change not visible in `npm run dev` | Restart the dev server for theme changes; Content and Styles changes follow on reload |
| Admin says "the admin app is not built" | `cd admin-ui && npm run build`, or install the release zip |
| An old build looks cached | Add `?x=<random>` to the address; purge the host's cache if needed |
