<?php
/**
 * Fires when the plugin is deleted via the WordPress admin (not on deactivate).
 * Removes everything the plugin created.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wp_astro_settings' );
delete_option( 'wp_astro_content' );
delete_option( 'wp_astro_style' );
delete_option( 'wp_astro_build_status' );
delete_option( 'wp_astro_last_dispatch' );
delete_option( 'wp_astro_flush_rewrite' );
delete_post_meta_by_key( '_wp_astro_engine' );
delete_post_meta_by_key( '_wp_astro_role' );
delete_post_meta_by_key( '_wp_astro_psi' );
delete_post_meta_by_key( '_wp_astro_description' );
delete_transient( 'wp_astro_rebuild_queued' );
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_wp\_astro\_page\_%' OR option_name LIKE '\_transient\_timeout\_wp\_astro\_page\_%'" ); // phpcs:ignore
wp_clear_scheduled_hook( 'wp_astro_do_rebuild' );
