<?php
/**
 * Article_Edit — everything behind the "Edit article" screen (W-Blog → Articles → a title):
 * one payload with all the fields of the page, one save that applies them, and the
 * SEO / section-switch post meta the Astro build reads (they are exposed in REST `meta`).
 *
 * Meta written here (all optional; empty = default):
 *   _wp_astro_seo_title      page <title> (supports {variables}, see Content::variables())
 *   _wp_astro_noindex        '1' → robots noindex          _wp_astro_nofollow  '1' → nofollow
 *   _wp_astro_sitemap_off    '1' → left out of the XML sitemap (also when noindex)
 *   _wp_astro_canonical      canonical URL override
 *   _wp_astro_og_title / _wp_astro_og_description / _wp_astro_og_image (JSON {id,url,width,height,alt})
 *   _wp_astro_tldr_off       '1' → no TL;DR summary on the page
 *   _wp_astro_sources        Sources list (HTML)           _wp_astro_sources_on '0' → hidden
 * plus the existing description (Meta::DESC_KEY) and FAQ (Faq).
 */
namespace Wp_Astro;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Article_Edit {

	public const SEO_TITLE   = '_wp_astro_seo_title';
	public const NOINDEX     = '_wp_astro_noindex';
	public const NOFOLLOW    = '_wp_astro_nofollow';
	public const SITEMAP_OFF = '_wp_astro_sitemap_off';
	public const CANONICAL   = '_wp_astro_canonical';
	public const OG_TITLE    = '_wp_astro_og_title';
	public const OG_DESC     = '_wp_astro_og_description';
	public const OG_IMAGE    = '_wp_astro_og_image';
	public const TLDR_OFF    = '_wp_astro_tldr_off';
	public const SOURCES     = '_wp_astro_sources';
	public const SOURCES_ON  = '_wp_astro_sources_on';
	public const BLOCKS      = '_wp_astro_blocks';
	public const TREATMENTS  = '_wp_astro_treatments';
	public const REVIEW      = '_wp_astro_review';
	public const SCHEMA_TYPE = '_wp_astro_schema_type';
	public const PRIMARY_CAT = '_wp_astro_primary_cat';

	public const SCHEMA_TYPES = [ 'Article', 'BlogPosting', 'MedicalWebPage' ];

	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'register' ] );
		// Keep noindex / "exclude" pages out of the XML sitemap.
		add_filter( 'wp_sitemaps_posts_query_args', [ __CLASS__, 'sitemap_args' ], 10, 2 );
		add_filter( 'wpseo_exclude_from_sitemap_by_post_ids', [ __CLASS__, 'sitemap_ids' ] );
	}

	/** meta key => sanitiser */
	private static function fields(): array {
		return [
			self::SEO_TITLE   => 'sanitize_text_field',
			self::NOINDEX     => [ __CLASS__, 'flag' ],
			self::NOFOLLOW    => [ __CLASS__, 'flag' ],
			self::SITEMAP_OFF => [ __CLASS__, 'flag' ],
			self::CANONICAL   => 'esc_url_raw',
			self::OG_TITLE    => 'sanitize_text_field',
			self::OG_DESC     => 'sanitize_text_field',
			self::OG_IMAGE    => [ __CLASS__, 'image_json' ],
			self::TLDR_OFF    => [ __CLASS__, 'flag' ],
			self::SOURCES     => 'wp_kses_post',
			self::SOURCES_ON  => [ __CLASS__, 'flag_off' ],
			self::BLOCKS      => [ __CLASS__, 'blocks_json' ],
			self::TREATMENTS  => [ __CLASS__, 'treatments_json' ],
			self::REVIEW      => [ __CLASS__, 'review_json' ],
			self::SCHEMA_TYPE => [ __CLASS__, 'schema_type' ],
			self::PRIMARY_CAT => [ __CLASS__, 'int_string' ],
		];
	}

	public static function flag( $v ): string {
		return '1' === (string) $v || true === $v ? '1' : '';
	}

	/** '0' = switched off; anything else = on (stored as empty). */
	public static function flag_off( $v ): string {
		return '0' === (string) $v || false === $v ? '0' : '';
	}

	public static function image_json( $v ): string {
		$d = is_string( $v ) ? json_decode( $v, true ) : $v;
		if ( ! is_array( $d ) || empty( $d['url'] ) ) {
			return '';
		}
		return (string) wp_json_encode(
			[
				'id'     => (int) ( $d['id'] ?? 0 ),
				'url'    => esc_url_raw( (string) $d['url'] ),
				'width'  => (int) ( $d['width'] ?? 0 ),
				'height' => (int) ( $d['height'] ?? 0 ),
				'alt'    => sanitize_text_field( (string) ( $d['alt'] ?? '' ) ),
			]
		);
	}

	public static function register(): void {
		foreach ( Meta::post_types() as $type ) {
			foreach ( self::fields() as $key => $sanitize ) {
				register_post_meta(
					$type,
					$key,
					[
						'type'              => 'string',
						'single'            => true,
						'default'           => '',
						'show_in_rest'      => true,
						'sanitize_callback' => $sanitize,
						'auth_callback'     => static fn( $allowed, $k, $post_id ) => current_user_can( 'edit_post', $post_id ),
					]
				);
			}
		}
	}


	/* ------------------------------------------------ section settings */

	public static function int_string( $v ): string {
		$n = absint( $v );
		return $n ? (string) $n : '';
	}

	public static function schema_type( $v ): string {
		return in_array( (string) $v, self::SCHEMA_TYPES, true ) && 'Article' !== $v ? (string) $v : '';
	}

	/** Page elements that can be switched off per article; everything is on by default. */
	public static function blocks_defaults(): array {
		return [
			'toc'          => true,
			'breadcrumbs'  => true,
			'share'        => true,
			'reading_time' => true,
			'author'       => true,
			'practice'     => true,
			'cta'          => [
				'on'    => true,
				'label' => '',
				'href'  => '',
			],
			'related'      => [
				'mode' => 'auto', // auto | off | manual
				'ids'  => [],
			],
		];
	}

	public static function blocks_clean( $in ): array {
		$in  = is_array( $in ) ? $in : [];
		$def = self::blocks_defaults();
		$out = [];
		foreach ( [ 'toc', 'breadcrumbs', 'share', 'reading_time', 'author', 'practice' ] as $k ) {
			$out[ $k ] = array_key_exists( $k, $in ) ? (bool) $in[ $k ] : $def[ $k ];
		}
		$cta         = is_array( $in['cta'] ?? null ) ? $in['cta'] : [];
		$out['cta']  = [
			'on'    => array_key_exists( 'on', $cta ) ? (bool) $cta['on'] : true,
			'label' => sanitize_text_field( (string) ( $cta['label'] ?? '' ) ),
			'href'  => self::href( (string) ( $cta['href'] ?? '' ) ),
		];
		$rel         = is_array( $in['related'] ?? null ) ? $in['related'] : [];
		$mode        = (string) ( $rel['mode'] ?? 'auto' );
		$out['related'] = [
			'mode' => in_array( $mode, [ 'auto', 'off', 'manual' ], true ) ? $mode : 'auto',
			'ids'  => array_slice( array_values( array_unique( array_filter( array_map( 'absint', (array) ( $rel['ids'] ?? [] ) ) ) ) ), 0, 3 ),
		];
		return $out;
	}

	public static function blocks_json( $v ): string {
		$d = is_string( $v ) ? json_decode( $v, true ) : $v;
		return is_array( $d ) ? (string) wp_json_encode( self::blocks_clean( $d ) ) : '';
	}

	public static function blocks( int $id ): array {
		$d = json_decode( (string) get_post_meta( $id, self::BLOCKS, true ), true );
		return self::blocks_clean( is_array( $d ) ? $d : [] );
	}

	/** Site path, #anchor, @front or a full URL. */
	private static function href( string $raw ): string {
		$v = trim( $raw );
		if ( '' === $v ) {
			return '';
		}
		return preg_match( '#^[/\#?]#', $v ) ? sanitize_text_field( $v ) : esc_url_raw( $v );
	}

	/**
	 * "Treatments mentioned": { enabled, title, items: [ { title, url, desc, image } ] } or null
	 * when this article has none of its own (the site-wide list from config.ts is used).
	 */
	public static function treatments_clean( $in ): array {
		$in    = is_array( $in ) ? $in : [];
		$items = [];
		foreach ( array_slice( array_values( (array) ( $in['items'] ?? [] ) ), 0, 6 ) as $it ) {
			if ( ! is_array( $it ) ) {
				continue;
			}
			$title = sanitize_text_field( (string) ( $it['title'] ?? '' ) );
			$url   = self::href( (string) ( $it['url'] ?? '' ) );
			if ( '' === $title || '' === $url ) {
				continue;
			}
			$att = absint( $it['image']['id'] ?? 0 );
			$src = $att ? wp_get_attachment_image_src( $att, 'large' ) : false;
			$items[] = [
				'title' => mb_substr( $title, 0, 120 ),
				'url'   => $url,
				'desc'  => mb_substr( sanitize_text_field( (string) ( $it['desc'] ?? '' ) ), 0, 300 ),
				'image' => $src ? [
					'id'     => $att,
					'url'    => $src[0],
					'width'  => (int) $src[1],
					'height' => (int) $src[2],
				] : null,
			];
		}
		return [
			'enabled' => ! array_key_exists( 'enabled', $in ) || (bool) $in['enabled'],
			'title'   => sanitize_text_field( (string) ( $in['title'] ?? '' ) ),
			'items'   => $items,
		];
	}

	public static function treatments_json( $v ): string {
		$d = is_string( $v ) ? json_decode( $v, true ) : $v;
		return is_array( $d ) ? (string) wp_json_encode( self::treatments_clean( $d ) ) : '';
	}

	/** @return array{by:int,date:string} */
	public static function review( int $id ): array {
		$d = json_decode( (string) get_post_meta( $id, self::REVIEW, true ), true );
		$d = is_array( $d ) ? $d : [];
		return [
			'by'   => absint( $d['by'] ?? 0 ),
			'date' => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $d['date'] ?? '' ) ) ? (string) $d['date'] : '',
		];
	}

	public static function review_json( $v ): string {
		$d = is_string( $v ) ? json_decode( $v, true ) : $v;
		if ( ! is_array( $d ) ) {
			return '';
		}
		$by   = absint( $d['by'] ?? 0 );
		$date = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $d['date'] ?? '' ) ) ? (string) $d['date'] : '';
		return $by || $date ? (string) wp_json_encode( [ 'by' => $by, 'date' => $date ] ) : '';
	}

	/* ------------------------------------------------------------ sitemap */

	/** Post IDs that must not be in the sitemap: switched off there, or noindex. */
	public static function excluded_ids(): array {
		return array_map(
			'intval',
			get_posts(
				[
					'post_type'        => Meta::post_types(),
					'post_status'      => 'publish',
					'numberposts'      => -1,
					'fields'           => 'ids',
					'meta_query'       => [ // phpcs:ignore WordPress.DB.SlowDBQuery
						'relation' => 'OR',
						[ 'key' => self::SITEMAP_OFF, 'value' => '1' ],
						[ 'key' => self::NOINDEX, 'value' => '1' ],
					],
					'suppress_filters' => true,
				]
			)
		);
	}

	public static function sitemap_args( array $args, string $post_type ): array {
		if ( in_array( $post_type, Meta::post_types(), true ) ) {
			$args['post__not_in'] = array_merge( (array) ( $args['post__not_in'] ?? [] ), self::excluded_ids() );
		}
		return $args;
	}

	public static function sitemap_ids( $ids ): array {
		return array_merge( (array) $ids, self::excluded_ids() );
	}

	/* -------------------------------------------------------------- read */

	/** The "Sources Cited From" list inside the text (what the build lifts out today). */
	public static function sources_from_content( string $html ): string {
		if ( preg_match( '/<(?:p|h[23])>\s*(?:<(?:strong|b)>\s*)?(?:Sources Cited From|Sources|References)\s*:?\s*(?:<\/(?:strong|b)>\s*)?<\/(?:p|h[23])>\s*(<(ol|ul)\b[\s\S]*?<\/\2>)/i', $html, $m ) ) {
			return trim( $m[1] );
		}
		return '';
	}

	/** Every field of the page, for the edit screen. */
	public static function get( \WP_Post $p ): array {
		$id    = $p->ID;
		$meta  = static fn( string $k ): string => (string) get_post_meta( $id, $k, true );
		$thumb = (int) get_post_thumbnail_id( $id );
		$img   = $thumb ? wp_get_attachment_image_src( $thumb, 'large' ) : false;
		$full  = $thumb ? wp_get_attachment_image_src( $thumb, 'full' ) : false;
		$og    = json_decode( $meta( self::OG_IMAGE ), true );

		$src_custom = $meta( self::SOURCES );
		$src_text   = self::sources_from_content( (string) $p->post_content );
		$faq        = Faq::effective( $p );

		return [
			'id'         => $id,
			'status'     => $p->post_status,
			'title'      => html_entity_decode( get_the_title( $p ), ENT_QUOTES ),
			'slug'       => $p->post_name,
			'link'       => (string) get_permalink( $p ),
			'view_url'   => 'publish' === $p->post_status ? (string) get_permalink( $p ) : (string) get_preview_post_link( $p ),
			'edit_url'   => (string) get_edit_post_link( $id, 'raw' ),
			'type'       => $p->post_type,
			'role'       => Meta::get_role( $id ),
			'categories' => is_object_in_taxonomy( $p->post_type, 'category' ) ? array_map( 'intval', wp_get_post_categories( $id ) ) : [],
			'tags'       => is_object_in_taxonomy( $p->post_type, 'post_tag' ) ? array_values( (array) wp_get_post_tags( $id, [ 'fields' => 'names' ] ) ) : [],
			'has_taxonomies' => is_object_in_taxonomy( $p->post_type, 'category' ),
			'featured'   => $thumb && $img ? [
				'id'     => $thumb,
				'url'    => $img[0],
				'width'  => (int) ( $full[1] ?? 0 ),
				'height' => (int) ( $full[2] ?? 0 ),
				'alt'    => (string) get_post_meta( $thumb, '_wp_attachment_image_alt', true ),
			] : null,
			'tldr'       => [
				'enabled' => '1' !== $meta( self::TLDR_OFF ),
				'text'    => (string) $p->post_excerpt,
			],
			'body'       => (string) $p->post_content,
			'sources'    => [
				'enabled' => '0' !== $meta( self::SOURCES_ON ),
				'html'    => '' !== trim( $src_custom ) ? $src_custom : $src_text,
				'source'  => '' !== trim( $src_custom ) ? 'custom' : ( '' !== $src_text ? 'content' : 'none' ),
			],
			'faq'        => [
				'enabled' => $faq['enabled'],
				'source'  => $faq['source'],
				'items'   => $faq['items'],
			],
			'seo'        => [
				'title'       => $meta( self::SEO_TITLE ),
				'description' => $meta( Meta::DESC_KEY ),
				'noindex'     => '1' === $meta( self::NOINDEX ),
				'nofollow'    => '1' === $meta( self::NOFOLLOW ),
				'sitemap_off' => '1' === $meta( self::SITEMAP_OFF ),
				'canonical'   => $meta( self::CANONICAL ),
				'og_title'    => $meta( self::OG_TITLE ),
				'og_desc'     => $meta( self::OG_DESC ),
				'og_image'    => is_array( $og ) && ! empty( $og['url'] ) ? $og : null,
			],
			'author'     => [
				'id'   => (int) $p->post_author,
				'card' => Authors::card( (int) $p->post_author ),
			],
			'users'      => Authors::options(),
			'blocks'     => self::blocks( $id ),
			'treatments' => self::treatments_get( $id ),
			'review'     => self::review_get( $id ),
			'schema_type' => self::schema_type( $meta( self::SCHEMA_TYPE ) ) ?: 'Article',
			'primary_category' => (int) $meta( self::PRIMARY_CAT ),
			'date'       => get_post_time( 'Y-m-d\TH:i', false, $p ),
			'practice'   => [
				'name'    => (string) ( Content::stored()['practice']['name'] ?? '' ),
				'address' => (string) ( Content::stored()['practice']['address']['streetAddress'] ?? '' ),
			],
			'quality'    => Quality::score( $p ),
			'modified'   => get_post_modified_time( 'c', true, $p ),
			'ago'        => human_time_diff( (int) get_post_modified_time( 'U', true, $p ) ),
		];
	}

	/** @return array{enabled:bool,title:string,items:array<int,array>,custom:bool} */
	private static function treatments_get( int $id ): array {
		$raw = (string) get_post_meta( $id, self::TREATMENTS, true );
		$d   = '' === $raw ? null : json_decode( $raw, true );
		if ( ! is_array( $d ) ) {
			return [ 'enabled' => true, 'title' => '', 'items' => [], 'custom' => false ];
		}
		return self::treatments_clean( $d ) + [ 'custom' => true ];
	}

	/** @return array{by:int,date:string,card:?array} */
	private static function review_get( int $id ): array {
		$r = self::review( $id );
		return $r + [ 'card' => $r['by'] ? Authors::card( $r['by'] ) : null ];
	}

	/* -------------------------------------------------------------- save */

	/**
	 * Apply the fields that were sent (a missing key is left alone).
	 *
	 * @return \WP_Post|\WP_Error the fresh post
	 */
	public static function save( int $id, array $d ) {
		$p = get_post( $id );
		if ( ! $p instanceof \WP_Post || ! in_array( $p->post_type, Meta::post_types(), true ) ) {
			return new \WP_Error( 'wp_astro_not_found', __( 'Article not found.', 'wp-astro' ), [ 'status' => 404 ] );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new \WP_Error( 'wp_astro_forbidden', __( 'You cannot edit this article.', 'wp-astro' ), [ 'status' => 403 ] );
		}

		// 1. Core post fields (one update, so revisions and hooks behave as usual).
		$post = [ 'ID' => $id ];
		if ( isset( $d['title'] ) ) {
			$post['post_title'] = sanitize_text_field( (string) $d['title'] );
		}
		if ( isset( $d['slug'] ) && '' !== trim( (string) $d['slug'] ) ) {
			$post['post_name'] = sanitize_title( (string) $d['slug'] );
		}
		if ( isset( $d['body'] ) ) {
			$post['post_content'] = (string) $d['body'];
		}
		if ( isset( $d['tldr']['text'] ) ) {
			$post['post_excerpt'] = sanitize_textarea_field( (string) $d['tldr']['text'] );
		}
		if ( isset( $d['status'] ) && in_array( $d['status'], [ 'publish', 'draft' ], true ) && $d['status'] !== $p->post_status ) {
			if ( 'publish' === $d['status'] && ! current_user_can( 'publish_post', $id ) ) {
				return new \WP_Error( 'wp_astro_forbidden', __( 'You cannot publish this article.', 'wp-astro' ), [ 'status' => 403 ] );
			}
			$post['post_status'] = $d['status'];
		}
		if ( isset( $d['author_id'] ) && (int) $d['author_id'] > 0 && (int) $d['author_id'] !== (int) $p->post_author ) {
			$au = get_userdata( (int) $d['author_id'] );
			if ( $au && user_can( $au, 'edit_posts' ) ) {
				$post['post_author'] = $au->ID;
			}
		}
		if ( isset( $d['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', (string) $d['date'] ) && (string) $d['date'] !== get_post_time( 'Y-m-d\TH:i', false, $p ) ) {
			$post['post_date']     = str_replace( 'T', ' ', (string) $d['date'] ) . ':00';
			$post['post_date_gmt'] = get_gmt_from_date( $post['post_date'] );
			$post['edit_date']     = true;
		}
		// "Minor edit": a typo fix should not change the date shown as "Updated" on the page.
		$restore = null;
		if ( ! empty( $d['minor_edit'] ) ) {
			$keep    = [ $p->post_modified, $p->post_modified_gmt ];
			$restore = static function ( $data ) use ( $keep ) {
				$data['post_modified']     = $keep[0];
				$data['post_modified_gmt'] = $keep[1];
				return $data;
			};
			add_filter( 'wp_insert_post_data', $restore, 99 );
		}
		if ( count( $post ) > 1 ) {
			$res = wp_update_post( wp_slash( $post ), true );
			if ( $restore ) {
				remove_filter( 'wp_insert_post_data', $restore, 99 );
			}
			if ( is_wp_error( $res ) ) {
				return $res;
			}
		} elseif ( $restore ) {
			remove_filter( 'wp_insert_post_data', $restore, 99 );
		}

		// 2. Taxonomies and the template go through the table's own code.
		$tax = array_intersect_key( $d, array_flip( [ 'categories', 'tags' ] ) );
		if ( isset( $d['role'] ) ) {
			$tax['role'] = $d['role'];
		}
		if ( $tax ) {
			$r = Articles::update( $id, $tax );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}

		// 3. Featured image + its alt text.
		if ( array_key_exists( 'featured', $d ) ) {
			$f = $d['featured'];
			if ( is_array( $f ) && ! empty( $f['id'] ) ) {
				set_post_thumbnail( $id, (int) $f['id'] );
				if ( isset( $f['alt'] ) && current_user_can( 'edit_post', (int) $f['id'] ) ) {
					update_post_meta( (int) $f['id'], '_wp_attachment_image_alt', sanitize_text_field( (string) $f['alt'] ) );
				}
			} else {
				delete_post_thumbnail( $id );
			}
		}

		// 4. Sections with a switch.
		if ( isset( $d['tldr']['enabled'] ) ) {
			self::put( $id, self::TLDR_OFF, $d['tldr']['enabled'] ? '' : '1' );
		}
		if ( isset( $d['sources'] ) && is_array( $d['sources'] ) ) {
			if ( isset( $d['sources']['html'] ) ) { // absent when the Sources editor was not touched
				self::put( $id, self::SOURCES, wp_kses_post( (string) $d['sources']['html'] ) );
			}
			if ( isset( $d['sources']['enabled'] ) ) {
				self::put( $id, self::SOURCES_ON, $d['sources']['enabled'] ? '' : '0' );
			}
		}
		if ( isset( $d['faq'] ) && is_array( $d['faq'] ) ) {
			if ( isset( $d['faq']['items'] ) ) {
				Faq::save( $id, (array) $d['faq']['items'] );
			}
			if ( isset( $d['faq']['enabled'] ) ) {
				Faq::set_enabled( $id, (bool) $d['faq']['enabled'] );
			}
		}

		// 4b. Page elements, treatments, review, schema type, primary category.
		if ( isset( $d['blocks'] ) && is_array( $d['blocks'] ) ) {
			$b = self::blocks_clean( $d['blocks'] );
			self::put( $id, self::BLOCKS, $b === self::blocks_defaults() ? '' : (string) wp_json_encode( $b ) );
		}
		if ( array_key_exists( 'treatments', $d ) ) {
			$t = $d['treatments'];
			self::put( $id, self::TREATMENTS, is_array( $t ) && ! empty( $t['custom'] ) ? self::treatments_json( $t ) : '' );
		}
		if ( isset( $d['review'] ) && is_array( $d['review'] ) ) {
			self::put( $id, self::REVIEW, self::review_json( $d['review'] ) );
		}
		if ( isset( $d['schema_type'] ) ) {
			self::put( $id, self::SCHEMA_TYPE, self::schema_type( $d['schema_type'] ) );
		}
		if ( array_key_exists( 'primary_category', $d ) ) {
			$pc = absint( $d['primary_category'] );
			self::put( $id, self::PRIMARY_CAT, $pc && has_category( $pc, $id ) ? (string) $pc : '' );
		}

		// 5. SEO.
		if ( isset( $d['seo'] ) && is_array( $d['seo'] ) ) {
			$s = $d['seo'];
			if ( array_key_exists( 'title', $s ) ) {
				self::put( $id, self::SEO_TITLE, sanitize_text_field( (string) $s['title'] ) );
			}
			if ( array_key_exists( 'description', $s ) ) {
				self::put( $id, Meta::DESC_KEY, sanitize_text_field( (string) $s['description'] ) );
			}
			foreach ( [ 'noindex' => self::NOINDEX, 'nofollow' => self::NOFOLLOW, 'sitemap_off' => self::SITEMAP_OFF ] as $k => $meta_key ) {
				if ( array_key_exists( $k, $s ) ) {
					self::put( $id, $meta_key, ! empty( $s[ $k ] ) ? '1' : '' );
				}
			}
			if ( array_key_exists( 'canonical', $s ) ) {
				self::put( $id, self::CANONICAL, esc_url_raw( trim( (string) $s['canonical'] ) ) );
			}
			if ( array_key_exists( 'og_title', $s ) ) {
				self::put( $id, self::OG_TITLE, sanitize_text_field( (string) $s['og_title'] ) );
			}
			if ( array_key_exists( 'og_desc', $s ) ) {
				self::put( $id, self::OG_DESC, sanitize_text_field( (string) $s['og_desc'] ) );
			}
			if ( array_key_exists( 'og_image', $s ) ) {
				$img = $s['og_image'];
				$att = is_array( $img ) ? (int) ( $img['id'] ?? 0 ) : 0;
				$src = $att ? wp_get_attachment_image_src( $att, 'full' ) : false;
				self::put(
					$id,
					self::OG_IMAGE,
					$src ? (string) wp_json_encode(
						[
							'id'     => $att,
							'url'    => $src[0],
							'width'  => (int) $src[1],
							'height' => (int) $src[2],
							'alt'    => (string) get_post_meta( $att, '_wp_attachment_image_alt', true ),
						]
					) : ''
				);
			}
		}

		return get_post( $id );
	}

	/** Write a meta value; an empty value removes the row so defaults stay clean. */
	private static function put( int $id, string $key, string $value ): void {
		if ( '' === $value ) {
			delete_post_meta( $id, $key );
		} else {
			update_post_meta( $id, $key, $value );
		}
	}
}
