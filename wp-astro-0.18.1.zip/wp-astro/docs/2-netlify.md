# Netlify

Netlify builds and hosts the static pages. WordPress keeps the public address: when a visitor opens an article, the plugin fetches the built page from Netlify and prints it. If Netlify is down or a page is missing, WordPress shows the normal page, so nothing breaks.

## Two ways to connect

| | Git-connected (simple) | Build in GitHub Actions |
| --- | --- | --- |
| Who builds | Netlify | The workflow `build-blog.yml` |
| Netlify needs access to the repository | Yes (GitHub app) | No |
| Trigger from WordPress | Netlify build hook (webhook) | GitHub `repository_dispatch` |
| Needs | A Netlify site per client | One repository secret, `NETLIFY_AUTH_TOKEN` |
| Rebuilds on a code merge | Yes | No, only when WordPress asks |

Pick one per site in **Deploy → Rebuild trigger**. The plugin can also use both.

## Setting up a site (git-connected)

1. In Netlify choose **Add new project → Import from GitHub** and pick the repository.
2. Use these build settings (they are also in `netlify.toml`):

| Field | Value |
| --- | --- |
| Branch to deploy | `main` |
| Base directory | `frontend` |
| Build command | `npm run build` |
| Publish directory | `dist` |

3. Add the environment variables (same value for every context):

| Variable | Meaning |
| --- | --- |
| `PUBLIC_SITE` | The design folder, for example `dayo`. If it is missing, the build uses `blyss`. |
| `PUBLIC_WP_API_BASE` | The WordPress address, without a trailing slash |
| `PUBLIC_WP_SITE_URL` | The same address; pages use it as the canonical address |
| `PUBLIC_ASSET_BASE` | This Netlify site's own address; images and CSS are loaded from it |

4. In Netlify **make the site public**. A private site answers 401 and WordPress cannot fetch from it.
5. In WordPress, **Deploy → Mode = Netlify** and set **Netlify address** to the `.netlify.app` URL.
6. Add a **Build hook** in Netlify and paste it into WordPress as the **Webhook URL**.
7. In Netlify add a **Deploy succeeded** notification (HTTP POST) pointing at the **Purge URL** shown on the Deploy tab, so the page cache empties the moment a deploy finishes. Optionally point **Deploy started** and **Deploy failed** at the **Build-status URL**, so the Deploy tab shows the last build.
8. Click **Purge page cache** and open an article. The response header `X-WP-Astro: remote` confirms the page came from Netlify.

## Setting up a site (GitHub Actions)

1. On **Deploy**, use **Connect Netlify**: paste a Netlify personal access token, choose a site name and the design folder. The token is used once and is not stored.
2. Under **Rebuilds** enter the GitHub owner and repository, and a GitHub token (fine-grained, only this repository) with **Contents: Read and write**.
3. In the repository add the secret `NETLIFY_AUTH_TOKEN`.
4. The workflow file must be on `main`; GitHub only runs the copy on the default branch.
5. Click **Rebuild now** and watch the run under GitHub → Actions.

The plugin sends everything the workflow needs in the request, so no client value is stored in the repository.

## What triggers a build

| Event | Builds? |
| --- | --- |
| Publish or update a flagged article, edit a menu, save Content or Styles | Yes, after the "Changes go live" rule on Deploy |
| Merge to `main` (git-connected) | Yes, every connected site |
| A pull request | A deploy preview (also costs credits) |
| **Rebuild now** on Deploy | Yes, immediately |

A build takes about 20 seconds and a change is live in 2–3 minutes. Builds cost Netlify credits, so batch edits (the default waits 10 minutes after your last edit) and test locally first.

## What the Netlify copy looks like

The Netlify address is never meant to be indexed. `netlify.toml` sends `noindex` there and points the canonical address at WordPress. Hashed files under `/_astro/` are cached for a year, so a repeat visit is fast. Fonts and images load from the Netlify address, so those requests do not go through WordPress.

## Other ways to set a site up

- **From the command line:** `scripts/netlify-site.sh <site> <netlify-name> <wp-url> [purge-url]` creates and configures a site (log in with `netlify login` as the account that owns it).
- **Do not mix the two routes.** If you created the Netlify site by hand, do not also use **Connect Netlify** on the Deploy tab; it would create a second site.
- **Managed hosts with their own CDN** (for example Elementor Cloud) can hold the plain address in cache for a long time. Test with a random `?x=` and purge from the host.
## When something goes wrong

- **The page still looks old.** The page only changes after a rebuild; check **Last build** on Deploy, then purge the page cache.
- **WordPress shows 401 or an empty page.** The Netlify site is private; make it public.
- **A new environment variable has no effect.** Run **Trigger deploy → Clear cache and deploy** after changing variables.
- **"Repository not found".** The Netlify GitHub app is installed per GitHub account. Install it on the account that owns the repository, then link the repository again through Netlify's own picker.
- **The browser console shows a 404 for `/.netlify/scripts/hud`.** Netlify adds a small helper script to its pages; it only works on Netlify's own address. The plugin now removes it from the pages it prints. If you see it on an older plugin version, update the plugin, or switch off Netlify's drawer for the site (Site configuration → Collaboration).
- **A site shows another client's design.** `PUBLIC_SITE` is wrong or missing.
